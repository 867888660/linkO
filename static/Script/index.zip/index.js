let graph;
let domBlocks = [];
let SaveGraph=[];
let NowNode;
let fileList;
let FilePath='WorkFlow'
let CopyNodeTemp;
let FileName='';
let Callsign='';
let ProjectName='Temp';
let TemptNum=0;//临时使用的数据
let MemoryIndex=-1;
let passivityTriggerArray = [];
let ArrayTriggerArray = [];
let IsTriggerNode = true; // 假设这个变量在其他地方被定义
let IsRunningFunction = false;
let TempMessageNode;
let workflowFileList = [];
let draggedWorkflowNode = null;
//#region 浮窗栏
const tooltip = document.createElement('div');
tooltip.className = 'tooltip';
document.body.appendChild(tooltip);
//#endregion
// 请求所有节点信息 todo：如果需要更新的，建议发通知更新或者定时拉取
const requestNodeList = async () => {
  const res = await fetch('/get-python-files');
  return await res.json();
};

const refreshFileList = async () => {
  fileList = await requestNodeList();
  console.log('Updated file list:', fileList);
};

refreshFileList();
const History_project = async () => {
  const res = await fetch('/history-project', {
    method: 'POST'
  });
  return await res.json();
}

const getHistoryItem = async () => {
  const HistoryItem = await History_project();
  console.log('载入记录',HistoryItem);
  let name = HistoryItem.name;
  let path = HistoryItem.path;
  let HostPost=HistoryItem.host;
  Callsign=HistoryItem.callsign;
  FilePath = path;
  
  document.title = FileName.substring(FileName.lastIndexOf(':') + 1);
  ProjectName=name;
  if(Callsign!=null)
    document.title=Callsign+':'+name;
  // 去除路径
  // path = path.split('/').pop();
  // 去除后缀
  // name = name.split('.json')[0];

  fetch('/get-project-files', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ json_name: name ,json_path: path })
  })
  .then(response => response.json())
  .then(data => {
    console.log(data);
    LoadWorkFlow(data,name,HostPost,Callsign);
    // 在这里处理返回的JSON数据
  })
  .catch(error => {
    console.error('Error fetching the project file:', error);
  });
};

// 调用函数以执行请求
getHistoryItem();



// 请求节点详细信息
const requestNodeInfo = async (nodeName) => {
  const res = await fetch(`/get-node-details/${nodeName}`)
  return await res.json()
}

//删除节点
const removeNode = (item) => {
  graph.remove(item);
  RefreshEdge();
};
// 删除边
const removeEdge = (item) => {
  graph.remove(item);
  RefreshEdge();
};
const OpenCode = async (item) => {
  const n = item.name.split('.py')[0];
  const res = await fetch(`/open-code-editor`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ name: `${n}.py` }),
  });

  if (res.ok) {
    const data = await res.json();
    if (data.status === 'success') {
      console.log('File opened successfully in VSCode');
    } else {
      console.error('Failed to open file:', data.error);
    }
  } else {
    const errorData = await res.json();
    console.error('Error:', errorData.error);
  }
};

const runNode = (item) => {
  const isCheckMode = document.getElementById('runButton').textContent !== '运行';
  createSideWindow(item, isCheckMode);
};

const changeEdge = (item) => {
  console.log('改变连线', item);
  //改变变得颜色并重新渲染
  graph.updateItem(item, {
    style: {
      stroke: 'red',
    }
  });
};
// 手动添加节点
const addcombo = (item,x,y) => {

  graph.addItem('combo', {
    id: 'combo1'+Date.now(),
    label: 'Combo',
    x: x,
    y: y,
    width: 800,
    height: 600,
    size: [200, 200],
    padding: [20, 20, 20, 20],
    type: 'rect', // 确保是矩形
    style: {
      fill: 'rgba(255, 255, 255, 0.8)', // 设置透明度
      stroke: '#999',
      lineWidth: 3,
      radius: 4
    },
  }, [item._cfg.id]);
  const combo = {
    id: 'combo1'+Date.now(),
    label: 'Combo',
    x: x,
    y: y,
    width: 800,
    height: 600,
    size: [200, 200],
    padding: [20, 20, 20, 20],
    type: 'rect', // 确保是矩形
    style: {
      fill: 'rgba(255, 255, 255, 0.8)', // 设置透明度
      stroke: '#999',
      lineWidth: 3,
      radius: 4
    },

  }
  graph.addItem('combo', combo);
}
const copyNode = (node, x, y,hash) => {
  const n = node.name.split('.py')[0];

  requestNodeInfo(n).then((nodeInfo) => {
      const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
      const anchorPoints = node.Inputs.map((node, index) => {
        const anchorHeight = 60 + index * 20;
        return [0.05, anchorHeight / maxHeight]
      }).concat(node.Outputs.map((node, index) => {
        const anchorHeight = 60 + index * 20;
        return [0.95, anchorHeight / maxHeight]
      })).concat([[0, 0]]);
      const TempId=node.id;
      const TempNode1 = graph.save().nodes.find((node) => node.id === TempId);
      const TempId1=node.name + Date.now();
      let TempOutput=JSON.parse(JSON.stringify(TempNode1.Outputs))
      TempOutput.forEach((output) => {
        output.Link=0;
      });
      let TempInput=JSON.parse(JSON.stringify(TempNode1.Inputs))
      TempInput.forEach((input) => {
        input.Link=0;
      });
      const TempNode = {
        // 可以添加随机数或时间戳来达到重复导入的效果
        id: TempId1,
        name: node.name,
        label: node.name + graph.getNodes().length,
        hash: node.hash,
        x,
        IsHovor:false,
        y,
        TriggerLink:0,
        IsBlock:false,
        IsStartNode:false,
        IsRunning:false,
        IsError:false,
        isFinish:false,
        IsTrigger:false,
        OriginalTextSelector:node.OriginalTextSelector,
        ErrorContext:'',
        Kind: node.Kind,
        ReTryNum:node.ReTryNum,
        prompt: node.prompt,
        ExprotPrompt: node.ExprotPrompt,
        ExprotAfterPrompt: node.ExprotAfterPrompt,
        TempOutPuts:node.TempOutPuts,
        anchorPoints,
        temperature:node.temperature,
        Top_p:node.Top_p,
        OriginalTextArray:node.OriginalTextArray,
        frequency_penalty:node.frequency_penalty,
        presence_penalty:node.presence_penalty,
        max_tokens:node.max_tokens,
        IsLoadSuccess:node.IsLoadSuccess,
        ...nodeInfo,

        // 深拷贝Outputs和Inputs，以确保它们在TempNode中是独立的
        Outputs: TempOutput,
        Inputs: TempInput,
    };

      graph.addItem('node', TempNode);

  });


}
const addNode = (name, x, y, hash, Kind) => {
  const nodes = graph.save().nodes;
  const checkExistingNode = (nodeKind) => {
    return nodes.some(node => node.NodeKind.includes(nodeKind));
  };

  const handleExistingNode = (nodeKind) => {
    showMessage(`已经存在${nodeKind}节点`, '#ff0000');
    return true; // 表示存在重复节点
  };

  if (Kind.includes('passivityTrigger') && checkExistingNode('passivityTrigger')) {
    if (handleExistingNode('passivityTrigger')) return; // 直接终止函数执行
  }

  if (Kind.includes('ArrayTrigger') && checkExistingNode('ArrayTrigger')) {
    if (handleExistingNode('ArrayTrigger')) return; // 直接终止函数执行
  }

  const n = name.split('.py')[0];
  requestNodeInfo(n).then((nodeInfo) => {
    // ... 剩余的代码保持不变
    const maxHeight = Math.max(nodeInfo.Inputs.length, nodeInfo.Outputs.length) * 20 + 60;
    const anchorPoints = [
      ...nodeInfo.Inputs.map((_, index) => [0.05, (60 + index * 20) / maxHeight]),
      ...nodeInfo.Outputs.map((_, index) => [0.95, (60 + index * 20) / maxHeight]),
      [0, 0]
    ];

    const node = {
      id: `${name}_${Date.now()}`,
      name: name,
      label: `${name.replace('.py', '')}${graph.getNodes().length}`,
      hash: hash,
      x,
      y,
      TriggerLink: 0,
      IsHovor: false,
      IsStartNode: false,
      IsBlock: false,
      IsRunning: false,
      isFinish: false,
      IsError: false,
      IsTrigger: false,
      OriginalTextSelector: 'Json',
      ErrorContext: '',
      Kind: Kind,
      prompt: '',
      ExprotPrompt: '',
      ExprotAfterPrompt: '',
      ReTryNum: 0,
      anchorPoints,
      OriginalTextArray: [{
        'Num': null,
        'Kind': 'String',
        'Boolean': false,
        'Id': 'Output1',
        'Context': null,
        'name': 'OriginalText',
        'Link': 0,
        'Description': 'answer'
      }],
      TempOutPuts: [],
      Top_p: 0.9,
      temperature: 0.7,
      frequency_penalty: 0.0,
      presence_penalty: 0.0,
      max_tokens: 4096,
      ...nodeInfo
    };
    
    graph.addItem('node', node);
  }).catch(error => {
    console.error('Error adding node:', error);
    showMessage('添加节点时发生错误', '#ff0000');
  });
};

// 右键点击菜单实现
const contextMenu = new G6.Menu({
  getContent(evt) {
    let menu = '';
    if (evt.target && evt.target.isCanvas && evt.target.isCanvas()) {
      if (document.getElementById('runButton').textContent == '运行') {
        menu = `<div class="title">添加节点</div>`;
        refreshFileList();
        // 对 fileList 进行分组
        const groupedFiles = fileList.reduce((acc, file) => {
          // 只取 file.NodeKind 中 _ 前面的部分
          const key = file.NodeKind.split('_')[0];
        
          if (!acc[key]) {
            acc[key] = [];
          }
          acc[key].push(file);
          return acc;
        }, {});
        

        // 自定义样式设置
        const titleStyle = {
          fontSize: '20px',
          color: '#000',
          fontWeight: 'bold', // 'normal' or 'bold'
          fontFamily: 'Arial, sans-serif'
        };

        // 按分类生成菜单
        Object.keys(groupedFiles).forEach(kind => {
          menu += `<div class="node-kind" style="font-size: ${titleStyle.fontSize}; color: ${titleStyle.color}; font-weight: ${titleStyle.fontWeight}; font-family: ${titleStyle.fontFamily};"><strong>${kind}</strong></div>`;
          groupedFiles[kind].forEach(file => {
            const fileName = file.filename.replace(/\.py$/, ''); // 移除 .py 后缀
            menu += `<div class="menu-item" data-behavior="addNode" data-hash="${file.hash}" data-canvasx="${evt.canvasX}" data-canvasy="${evt.canvasY}" data-Kind="${file.NodeKind}">${fileName}</div>`;
          });
        });
      }
    } else if (evt.item) {
      const itemType = evt.item.getType();
      if (itemType === 'node') {
        if (document.getElementById('runButton').textContent == '运行') {
          menu = `
            <div class="menu-item" data-behavior="removeNode">删除节点</div>
            <div class="menu-item" data-behavior="copyNode" data-canvasx="${evt.canvasX}" data-canvasy="${evt.canvasY}">复制节点</div>
            <div class="menu-item" data-behavior="OpenCode">打开源代码</div>
            <div class="menu-item" data-behavior="runNode">运行单个节点</div>
          `;
        } else {
          menu = `
            <div class="menu-item" data-behavior="runNode">检查单个节点</div>
          `;
        }
      } else if (itemType === 'edge') {
        menu = `
          <div class="menu-item" data-behavior="removeEdge">删除连线</div>
          <div class="menu-item" data-behavior="changeEdge">改变连线</div>
        `;
      } else if (itemType === 'combo') {
        menu = `
          <div class="menu-item" data-behavior="removeNode">删除Combo</div>
        `;
      }
    }
    return `<div class="new-context-menu">${menu}</div>`;
  },
  handleMenuClick: (target, item) => {
    const targetText = target.dataset.behavior;
    switch (targetText) {
      case 'addNode':
        addNode(target.innerText, target.dataset.canvasx, target.dataset.canvasy, target.dataset.hash, target.dataset.Kind);
        break;
      case 'addCombo':
        addcombo(item, target.dataset.canvasx, target.dataset.canvasy);
        break;
      case 'removeNode':
        removeNode(item);
        break;
      case 'copyNode':
        copyNode(item.getModel(), target.dataset.canvasx, target.dataset.canvasy, target.dataset.hash);
        break;
      case 'removeEdge':
        removeEdge(item);
        break;
      case 'runNode':
        runNode(item.getModel());
        break;
      case 'OpenCode':
        OpenCode(item.getModel());
        break;
      case 'changeEdge':
        changeEdge(item);
        break;
      default:
        break;
    }
  },
  offsetX: 0,
  offsetY: 0,
  itemTypes: ['node', 'edge', 'canvas'],
});


// 实现自定义节点
G6.registerCombo('resizable-combo', {
  drawShape(cfg, group) {
    const { size } = cfg;
    const width = size[0];
    const height = size[1];
    const shape = group.addShape('rect', {
      attrs: {
        x: -width / 2,
        y: -height / 2,
        width,
        height,
        fill: cfg.style.fill,
        stroke: cfg.style.stroke,
      },
      draggable: true,
      name: 'combo-rect',
    });
    // 添加四个控制点
    const points = [
      [-width / 2, 0], // 左侧中点
      [width / 2, 0], // 右侧中点
      [0, -height / 2], // 上侧中点
      [0, height / 2], // 下侧中点
    ];
    points.forEach((point, index) => {
      group.addShape('circle', {
        attrs: {
          x: point[0],
          y: point[1],
          r: 5,
          fill: 'red',
        },
        name: `resize-handle-${index}`,
        draggable: true,
      });
    });
    return shape;
  },
});
G6.registerEdge('line-dash', {
  setState(name, value, edge) {
    if(name === 'linkRed' && value) {
      //变粗变红
      const shape = edge.getKeyShape();
      shape.attr('stroke', 'red');
      shape.attr('lineWidth', 6);
    } else if(name === 'linkRed' && !value) {
      const shape = edge.getKeyShape();
      shape.attr('stroke', '#000');
      shape.attr('lineWidth', 3);
    }
    if (name === 'linkBlue' && value) {
      //变粗变蓝
      const shape = edge.getKeyShape();
      shape.attr('stroke', '#00ccff');
      shape.attr('lineWidth', 6);
    }
    else if(name === 'linkBlue' && !value) {
      const shape = edge.getKeyShape();
      shape.attr('stroke', '#000');
      shape.attr('lineWidth', 3);
    }
    if (name === 'linkGreen' && value) {
      //变粗变蓝
      const shape = edge.getKeyShape();
      shape.attr('stroke', '#228B22');
      shape.attr('lineWidth', 6);
    }
    else if(name === 'linkGreen' && !value) {
      const shape = edge.getKeyShape();
      shape.attr('stroke', '#000');
      shape.attr('lineWidth', 3);
    }
    if (name === 'linked' && value) {
      const shape = edge.getKeyShape();
      let index = 0;
      console.log('linked');
      shape.animate(() => {
        index++;
        if (index > 9) {
          index = 0;
        }
        return {
          lineDash: [10, 5],
          lineDashOffset: -index
        };
      }, {
        repeat: true,
        duration: 10000
      });
    } else if (name === 'linked' && !value) {
      const shape = edge.getKeyShape();
      shape.stopAnimate();
      shape.attr('lineDash', [0, 0]);
      shape.attr('lineDashOffset', 0);
    }
  },
  getControlPoints(cfg) {
    const { startPoint, endPoint } = cfg;
    const midX = (startPoint.x + endPoint.x-100) / 2;
    const cp1 = { x: midX, y: startPoint.y };
    const segmentLength = 20; // 设置终点前直线段的长度
    const cp2 = { x: endPoint.x - 100, y: endPoint.y }; // 保持与终点同一y坐标，确保水平
    const cp3 = { x: endPoint.x - (segmentLength / 2), y: endPoint.y }; // 设置在cp2和终点之间
    return [cp1, cp2, cp3];
  }
}, 'cubic');
G6.registerNode('fileNode', {
  draw(cfg, group) {
    let maxHeight =1;
    maxHeight = Math.max(cfg.Inputs.length, cfg.Outputs.length)  
    let maxWidth = 0;
    cfg.draggable = false;
    cfg.Inputs.map((input, index) => {
      let Temp=''
      const maxDisplayLength = 50;
      if(input.IsLabel == true) {
          if(input.Kind .includes('String')) {
              Temp = ':' + truncateTextWithEllipsis(input.Context, maxDisplayLength);
          }
          if(input.Kind == 'Num') {
              Temp = ':' + input.Num;
          }
      }
      const textShape =group.addShape('text', {
        attrs: {
          x: 25,
          y: 54 + index * 20,
          text: input.name+':'+Temp, // 使用 input.Id 替代 name
          fill: '#000000',
          textBaseline: 'top',
          fontWeight: 600,
          fontSize: 14,
          fontFamily: 'Microsoft YaHei',
          textAlign: 'left',
        },
        capture: false,
        name: 'nameText',
      });
      const textWidth = textShape.getBBox().width;
      maxWidth = Math.max(maxWidth, textWidth);
      group.removeChild(textShape)
    }); // Inputs 标题文字
    cfg.Outputs.map((output, index) => {
      const textShape =group.addShape('text', {
        attrs: {
          x: 425,
          y: 54 + index * 20,
          text: output.name,
          fill: '#000000',
          textBaseline: 'top',
          fontWeight: 600,
          fontSize: 14,
          fontFamily: 'Microsoft YaHei',
          textAlign: 'right',
        },
        capture: false,
        name: 'nameText',
      });
      const textWidth = textShape.getBBox().width;
      maxWidth = Math.max(maxWidth, textWidth);
      group.removeChild(textShape)

    }); // Inputs 标题文字
    maxWidth = maxWidth+120;
    cfg.height = maxHeight* 20;
    cfg.width = maxWidth;
    if(cfg.IsHovor==true || cfg.IsBlock==true ||cfg.IsError==true)
    {
      let TempColor='#5a5a5a'
      if(cfg.isFinish==true && cfg.IsBlock==true )//为绿色
      {
        TempColor='#009f2a'
      }
      else if(cfg.IsRunning==true && cfg.IsBlock==true )//为蓝色
      {
        TempColor='#0062c3'
      }
      else if(cfg.IsTrigger==true && cfg.IsBlock==true )//为紫粉色
      {
        TempColor='#ff00ff'
      }
      if(cfg.IsError==true || cfg.IsLoadSuccess==false)//为红色
      {
        TempColor='#ff0000'
      }
      const selectionBorder = group.addShape('rect', {
        attrs: {
          x: -5,
          y: -5,
          width: maxWidth + 10,
          height: 70 + maxHeight * 20,
          stroke: TempColor, // 淡蓝色边框
          lineWidth: 3,
          radius: [10, 10],
          shadowColor: '#666', // 添加阴影颜色
          shadowBlur: 10, // 阴影的模糊级别
          shadowOffsetX: 2, // 阴影在X轴的偏移量
          shadowOffsetY: 2, // 阴影在Y轴的偏移量
          fill: 'transparent',
        },
        name: 'selection-border',
      });
    }
    const container = group.addShape('rect', {
      attrs: {
        x: 0,
        y: 0,
        width: maxWidth,
        height: 60 + maxHeight * 20,
        stroke: 'black',
        radius: [8, 8],
        fill: 'rgb(238,241,243)', // todo 节点背景框颜色
      },
      name: 'rect',
    });// 最外层灰色的框
    const shape = group.findById('rect'); // 通过 id 获取矩形图形
    let TitleColor = 'rgb(3,197,136)';
    if (cfg.IsLoadSuccess == false) {
      TitleColor = '#ff0000'; // Set TitleColor to red if IsLoadSuccess is false
    } else if (cfg.NodeKind.includes('LLm')) {
      TitleColor = '#009fcb';
    } else if (cfg.NodeKind == 'IfNode') {
      TitleColor = '#b300ff';
    } else if (cfg.NodeKind.includes('passivityTrigger')) {
      TitleColor = '#ff9100';
    } else if (cfg.NodeKind.includes('ArrayTrigger')) {
      TitleColor = '#e75500';
    }
    group.addShape('rect', {
      attrs: {
        x: 0,
        y: 0,
        width: maxWidth,
        height: 40,
        radius: [8, 8, 0, 0],
        fill: TitleColor, // todo 节点标题栏颜色
      },
      capture: false,
      name: 'rect',
    }); // 标题绿色的栏
    // If IsLoadSuccess is false, draw the black square with a red exclamation mark
    if (cfg.IsLoadSuccess == false) {
      group.addShape('rect', {
        attrs: {
          x: maxWidth - 35, // Moved slightly to the left
          y: 8, // Slightly moved upward
          width: 25, // Slightly wider
          height: 25, // Slightly taller
          fill: '#000000', // Black square
        },
        name: 'warningRect',
      });
    
      group.addShape('text', {
        attrs: {
          x: maxWidth - 22, // Adjusted to stay centered in the larger square
          y: 20, // Adjusted to stay vertically centered
          text: '!',
          fill: '#ff0000', // Red exclamation mark
          fontSize: 18, // Slightly larger font size
          fontWeight: 600,
          textAlign: 'center',
          textBaseline: 'middle',
        },
        name: 'warningText',
      });
    }
    
    group.addShape('text', {
      attrs: {
        x: 30,
        y: 20,
        //text: cfg.name.replace(".py", ""),
        text: cfg.label,
        fill: '#fff',
        textBaseline: 'middle',
        fontWeight: 600,
        fontSize: 16,
        fontFamily: 'Microsoft YaHei',
        textAlign: 'left',
      },
      capture: false,
      name: 'nameText',
    }); // 文件名的文字
    cfg.Inputs.map((input, index) => {
      let Temp=''
      // 定义每行显示的最大字符数
      const maxDisplayLength = 50;

    if(input.IsLabel == true) {
        if(input.Kind.includes('String')) {
            Temp = ':' + truncateTextWithEllipsis(input.Context, maxDisplayLength);
        }
        if(input.Kind == 'Num') {
            Temp = ':' + input.Num;
        }
        if(input.Kind == 'Boolean') {
            Temp = ':' + input.Boolean;
        }
    }

      group.addShape('text', {
        attrs: {
          x: 15,
          y: 54 + index * 20,
          text: input.name+Temp, // 使用 input.Id 替代 name
          fill: '#000000',
          textBaseline: 'top',
          fontWeight: 600,
          fontSize: 14,
          fontFamily: 'Microsoft YaHei',
          textAlign: 'left',
        },
        capture: false,
        name: 'nameText',
      });
    }); // Inputs 标题文字

    cfg.Outputs.map((output, index) => {
      group.addShape('text', {
        attrs: {
          x: maxWidth -15,
          y: 54 + index * 20,
          text: output.name,
          fill: '#000000',
          textBaseline: 'top',
          fontWeight: 600,
          fontSize: 14,
          fontFamily: 'Microsoft YaHei',
          textAlign: 'right',
        },
        capture: false,
        name: 'nameText',
      });
    }); // Inputs 标题文字
    const anchorPoints = this.getAnchorPoints(cfg);
    anchorPoints.forEach((anchorPos, i) => {
    let Kind=''
      if(i<cfg.Inputs.length )
      {
        if(cfg.Inputs[i].Kind == 'Num' || cfg.Inputs[i].Kind .includes('String')   || cfg.Inputs[i].Kind == 'Boolean' || cfg.Inputs[i].Kind == 'Trigger') {
          Kind = 'input';
          var strokecolor = ''; // 在使用之前定义变量
          if(cfg.Inputs[i].Kind .includes('String'))
              strokecolor = '#00c788';
          else if(cfg.Inputs[i].Kind == 'Num')
              strokecolor = '#5F95FF';
          else if(cfg.Inputs[i].Kind == 'Boolean')
              strokecolor = '#ff00ff';
              let circleColor = '#fff';
          
              if(cfg.Inputs[i].Link>0)
              {
                circleColor = '#78bbe5';
              }
              if(cfg.Inputs[i].IsLabel == false)
              {
                if(cfg.Inputs[i].Isnecessary==true)
                {
                  group.addShape('circle', {
                    attrs: {
                        r: 8, // 外圈的半径比内圈大，可以根据需要调整大小
                        x: 6, // 固定在左侧
                        y: (60 + maxHeight * 20) * anchorPos[1],
                        fill: 'none', // 通常外圈填充为透明
                        stroke: '#E80000', // 使用外圈的颜色
                        lineWidth: 2 // 设置外圈边框粗细为 2，可以根据需要调整
                    },
                });
                }
                  group.addShape('circle', {
                    attrs: {
                        r: 6,
                        x: 6, // 固定在左侧
                        y: (60 + maxHeight * 20) * anchorPos[1],

                        fill: circleColor,
                        stroke: strokecolor,
                        lineWidth: 3 // 设置边框粗细为 3

                        //外圈在设置一个边框

                    },
                    name: `anchor-point`, // the name, for searching by group.find(ele => ele.get('name') === 'anchor-point')
                    anchorPointIdx: i, // flag the idx of the anchor-point circle
                    links: cfg.Inputs[i].Link, // cache the number of edges connected to this shape
                    visible: true, // invisible by default, shows up when links > 1 or the node is in showAnchors state
                    draggable: true,
                    Kind: Kind,
                    Id:cfg.id,
                    AnChorKind:cfg.Inputs[i].Kind
                  });

              }
              else
              {
                let Temp=''
                if(cfg.Inputs[i].Kind .includes('String'))
                {
                  Temp=cfg.Inputs[i].Context
                }
                else if(cfg.Inputs[i].Kind == 'Num')
                {
                  Temp=cfg.Inputs[i].Num
                }
                group.addShape('circle', {
                  attrs: {
                      r: 0,
                      x: -3, // 固定在左侧
                      y: (60 + maxHeight * 20) * anchorPos[1],

                      fill: circleColor,
                      stroke: strokecolor,
                      lineWidth: 0 // 设置边框粗细为 3
                  },
                  name: `anchor-point`, // the name, for searching by group.find(ele => ele.get('name') === 'anchor-point')
                  anchorPointIdx: i, // flag the idx of the anchor-point circle
                  links: cfg.Inputs[i].Link, // cache the number of edges connected to this shape
                  visible: true, // invisible by default, shows up when links > 1 or the node is in showAnchors state
                  draggable: true,
                  Kind: Kind,
                  Id:cfg.id,
                  AnChorKind:cfg.Inputs[i].Kind
                  });
              }

      }
        if (cfg.Inputs[i].Kind == 'Label') {
          group.addShape('rect', { // 使用 rect 形状作为输入框的外观
            attrs: {
              width: 40, // 输入框的宽度
              height: 20, // 输入框的高度
              x: 10, // 位置 X
              y: (60 + maxHeight * 20) * anchorPos[1], // 位置 Y
              fill: '#fff', // 背景颜色
              stroke: '#5F95FF', // 边框颜色
            },
            name: 'num-input-box', // 名称，用于搜索
          });
          group.addShape('text', { // 使用 text 形状在输入框中显示默认值
            attrs: {
              text: '0', // 默认值
              x: 15, // 位置 X，稍微偏移以居中显示
              y: (60 + maxHeight * 20) * anchorPos[1] + 15, // 位置 Y，稍微偏移以居中显示
              fill: '#333', // 文本颜色
              textAlign: 'left', // 文本对齐方式
              textBaseline: 'middle', // 文本基线
              fontSize: 14, // 文本字体大小
            },
            name: 'num-input-text', // 名称，用于搜索
          });
        }


      }
      else if(i>=cfg.Inputs.length && i<cfg.Inputs.length+cfg.Outputs.length )
      {
          Kind='output'
              if(cfg.Outputs[i-cfg.Inputs.length].Kind=='Num' || cfg.Outputs[i-cfg.Inputs.length].Kind.includes('String')  || cfg.Outputs[i-cfg.Inputs.length].Kind=='Boolean' || cfg.Outputs[i-cfg.Inputs.length].Kind=='Trigger' )
                {
                  var strokecolor = ''; // 在使用之前定义变量
                  if(cfg.Outputs[i-cfg.Inputs.length].Kind .includes('String'))
                    strokecolor = '#00c788';
                  else if(cfg.Outputs[i-cfg.Inputs.length].Kind == 'Num')
                    strokecolor = '#5F95FF';
                  else if(cfg.Outputs[i-cfg.Inputs.length].Kind == 'Boolean')
                    strokecolor = '#ff00ff';
                  else if(cfg.Outputs[i-cfg.Inputs.length].Kind == 'Trigger')
                    strokecolor = '#ff9100';
                  let circleColor = '#fff';
                  if(cfg.Outputs[i-cfg.Inputs.length].Link>0)
                  {
                    circleColor = '#78bbe5';
                  }
                  group.addShape('circle', {
                    attrs: {
                      r: 6,
                      x: maxWidth - 7, // 固定在右侧
                      y: (60 + maxHeight * 20) * anchorPos[1],
                      fill: circleColor,
                      stroke: strokecolor,
                      lineWidth: 3 // 设置边框粗细为 3
                    },
                    name: `anchor-point`, // the name, for searching by group.find(ele => ele.get('name') === 'anchor-point')
                    anchorPointIdx: i, // flag the idx of the anchor-point circle
                    AnChorKind:cfg.Outputs[i-cfg.Inputs.length].Kind,
                    Description:cfg.Outputs[i-cfg.Inputs.length].Description,
                    links: cfg.Outputs[i-cfg.Inputs.length].Link, // cache the number of edges connected to this shape
                    visible: true, // invisible by default, shows up when links > 1 or the node is in showAnchors state
                    draggable: true,
                    Kind:Kind,
                    Id:cfg.id,
                });
              }
      }
      else if(i==cfg.Inputs.length+cfg.Outputs.length && cfg.NodeKind!='Trigger')
      {
              Kind='Trigger'
              var strokecolor = ''; // 在使用之前定义变量
              strokecolor = '#ff9100';
              let circleColor = '#fff';
              if(cfg.TriggerLink>0)
              {
                circleColor = '#78bbe5';
              }
              group.addShape('circle', {
                attrs: {
                  r: 6,
                  x: 10, // 固定在右侧
                  y: 10,
                  fill: circleColor,
                  stroke: strokecolor,
                  lineWidth: 3 // 设置边框粗细为 3
                },
                name: `Triggle-anchor-point`, // the name, for searching by group.find(ele => ele.get('name') === 'anchor-point')
                anchorPointIdx: i, // flag the idx of the anchor-point circle
                AnChorKind:'Trigger',
                Description:'Trigger',
                links: cfg.TriggerLink, // cache the number of edges connected to this shape
                visible: true, // invisible by default, shows up when links > 1 or the node is in showAnchors state
                draggable: true,
                Kind:Kind,
                Id:cfg.id,
            });

      }
    }) // 圆圈锚点
    //从新定义anchorPoints，位置为6/maxWidth与maxWidth - 7/maxWidth
    cfg.anchorPoints.forEach((anchorPos, i) => {
      if(i<cfg.Inputs.length)
      {

        anchorPos[0] = 6/maxWidth;
      }
      else if(i>=cfg.Inputs.length && i<cfg.Inputs.length+cfg.Outputs.length)
      {
        anchorPos[0]= (maxWidth - 7)/maxWidth;
      }
      else if(i==cfg.Inputs.length+cfg.Outputs.length)
      {
        anchorPos[0]= 10/maxWidth;
        anchorPos[1]=10/(60 + maxHeight * 20);
      }
    });
    //console.log('cfg',cfg.anchorPoints)
    return container;
  },
  getAnchorPoints(cfg) {
    return cfg.anchorPoints;
  },

});
// 记录锚点
let sourceAnchorIdx, targetAnchorIdx, sourceAnchor, startType, isDropingFile = false;
// 处理平行和不同锚点的边
function truncateTextWithEllipsis(text, maxLength) {
  // 检查 text 是否为 null 或 undefined
  if (text == null) {
    return ''; // 或者你可以返回一个默认值
  }

  // 检查文本中是否包含换行符
  const newLineIndex = text.indexOf('\n');

  // 如果有换行符，并且换行符的位置在最大显示长度之前，则截断到换行符位置
  if (newLineIndex !== -1 && newLineIndex < maxLength) {
      return text.substring(0, newLineIndex) + '...';
  }

  // 如果文本长度超过最大显示长度，进行截断并添加省略号
  if (text.length > maxLength) {
      return text.substring(0, maxLength) + '...';
  } else {
      return text;
  }
}

// 初始化图
function ChangeLink(Anchor)
{
    const Kind=Anchor.get('Kind')
    const Id=Anchor.cfg.Id
    const anchorPointIdx=Anchor.get('anchorPointIdx')
    const Num=Anchor.get('links')
    let nodes=graph.save().nodes;
    if(Kind=='input')
    {
      nodes.forEach((node) => {
        if(node.id === Id) {
            node.Inputs.forEach((input, index) => {
                if(index==anchorPointIdx)
                {
                  input.Link = Num;
                }
              });
        }
      });
    }
    else if(Kind=='output')
    {
      nodes.forEach((node) => {
        if(node.id === Id) {
          if(anchorPointIdx!=-1)
          {
            node.Outputs.forEach((output, index) => {
                if(index+node.Inputs.length==anchorPointIdx)
                {
                  output.Link = Num;
                }
            });
          }
          else
          {
            node.TriggerLink = Num;
          }
        }
      });
    }
    else if(Kind=='Trigger')
    {
      nodes.forEach((node) => {
        if(node.id === Id) {
          node.TriggerLink = Num;
        }
      });
    }
    ChangeDatas(nodes);
}
const initGraph = async (id = null) => {
    if (id) {
      await requestGraphData(id);
    }
    const w = window.innerWidth;
    const h = window.innerHeight;
    graph = new G6.Graph({
      container: 'mountNode',
      // 画布宽高
      width: w,
      height: h,
      modes: {
        default: [
          {
            type: 'drag-canvas',
            scalableRange: -1,
          },
          {
            type: 'click-select',
          },
          {
            type: 'drag-combo',
          },
          'zoom-canvas',
          {
            type: 'drag-node',
            shouldBegin: e => {
              const { item } = e;
              const model = item.getModel();
              // 如果节点的isBlock属性为true，阻止拖动
              console.log('model',model)
              if (model.IsBlock) {
                showMessage("Now is Running, Nodes Is Blocking",'#000000');
                return false;
              }
              // 可以进一步细化，例如不允许拖动特定部分
              if (e.target.get('name') === 'anchor-point') {
                return false;
              }
              return true; // 其他情况允许拖动
            }
          },
          {
            type: 'create-edge',
            trigger: 'drag', // set the trigger to be drag to make the create-edge triggered by drag
            shouldBegin: e => {
              // avoid beginning at other shapes on the node
              if (e.target && e.target.get('name') !== 'anchor-point' && e.target.get('name') !== 'Triggle-anchor-point') return false;
              startType = e.target.get('Kind');
              sourceAnchorIdx = e.target.get('anchorPointIdx');
              e.target.attr('fill', '#78bbe5');
              sourceAnchor = e.target;
              sourceAnchor.set('links', sourceAnchor.get('links') + 1); // cache the number of edge connected to this anchor-point circle
              ChangeLink(e.target);
              return true;
            },
            shouldEnd: e => {
              // avoid ending at other shapes on the node
              //if(e.target&&e.target.get('Kind')!=sourceAnchor.get('Kind')) return false;
              const sourceKind=sourceAnchor.get('Kind');
              const targetKind=e.target.get('Kind');
              const sourceLinks=sourceAnchor.get('links');
              const targetLinks=e.target.get('links');
              let Temp=e.target;
              let SourceNodeKind=''
              const data=graph.save().nodes;
              data.forEach((node) => {
                if(node.id === sourceAnchor.cfg.Id) {
                  SourceNodeKind=node.NodeKind
                }
              });
              if (e.target && e.target.get('name') !== 'anchor-point' && (e.target.get('name')!=='Triggle-anchor-point' && SourceNodeKind=='IfNode')) return false;
              if(sourceKind==targetKind) return false;
              if(sourceLinks>=2 && sourceKind=='input') return false;
              if(targetLinks>=1 && targetKind=='input') return false;
              if (getBeforeUnderscore(e.target.get('AnChorKind')) !== getBeforeUnderscore(sourceAnchor.get('AnChorKind'))) return false;

              // 辅助函数，用于获取 '_' 之前的字符串部分
              function getBeforeUnderscore(str) {
                return str?.toString().split('_')[0] ?? '';
            }
            

              if (e.target) {
                targetAnchorIdx = e.target.get('anchorPointIdx');
                e.target.set('links', e.target.get('links') + 1);  // cache the number of edge connected to this anchor-point circl
                let nodes=graph.save().nodes;
                ChangeLink(e.target);
                e.target.attr('fill', '#78bbe5')
                return true;
              }
              else if(sourceLinks>=1 )
              {
                sourceAnchor.attr('fill', '#fff')
                sourceAnchor = undefined;
                return false;
              }
              
            },
          }

        ], // 允许拖拽画布、放缩画布、拖拽节点
      },
      animate: true, // Boolean，切换布局时是否使用动画过度，默认为 false
      animateCfg: {
        duration: 500, // Number，一次动画的时长
        easing: 'easeLinear', // String，动画函数
      },
      defaultNode: {
        type: 'fileNode',
        stateStyles: {
          hover: {
            fill: 'lightgreen',
          },
          active: {
            stroke: '#ff0000',
            lineWidth: 100,
          }
        },
      },
      defaultCombo: {
        type: 'resizable-combo',
        style: {
          fill: '#f0f0f0',
          stroke: '#888888',
        },
      },
      defaultEdge: {
        type: 'line-dash',
        style: {
          lineWidth: 3,
          stroke: '#000',
          endArrow: {
            path: 'M 0,0 L 12,6 L 12,-6 Z',
            fill: '#5c95ff',
            d: 0,
          },
        },
        curveOffset: 20,
        minCurveOffset: 10,
      },
      plugins: [
        contextMenu,
      ]
    });
// 读取数据
    graph.data([]);
// 渲染图
    graph.render();
    // todo 可以自行添加背景图

    let backgroundImag = graph.getGroup().addShape('image', {
      attrs: {
        width: graph.getWidth(),
        height: graph.getHeight(),
        img: '',
      },
      capture: false
    });
    let shift = true;
    const switchDiv = document.createElement('div');
    backgroundImag.toBack();

    // 添加边后更新锚点-旧
    // graph.on('aftercreateedge', (e) => {
    //   // update the sourceAnchor and targetAnchor for the newly added edge
    //   graph.updateItem(e.edge, {
    //     sourceAnchor: sourceAnchorIdx,
    //     targetAnchor: targetAnchorIdx
    //   })

    //   // update the curveOffset for parallel edges
    //   const edges = graph.save().edges;
    //   processParallelEdgesOnAnchorPoint(edges);
    //   graph.getEdges().forEach((edge, i) => {
    //     graph.updateItem(edge, {
    //       curveOffset: edges[i].curveOffset,
    //       curvePosition: edges[i].curvePosition,
    //     });
    //   });
    // });

    graph.on('afteradditem', e => {
      if (e.item && e.item.getType() === 'edge' && !isDropingFile) {
        graph.updateItem(e.item, {
          sourceAnchor: sourceAnchorIdx
        });
      }
      if(e.item && e.item.getType() === 'node') {
        let data = graph.save()
        //data.nodes.forEach((node) => {
            //if(node.id === e.item._cfg.id) {
              //node.Inputs.forEach((input, index) => {
                //input.Id += index.toString();
              //});
             // node.Outputs.forEach((output, index) => {
                //output.Id+=index.toString();
             // });
           // }
          //});
          ChangeDatas(data);
      }
    })
    //combo有关
    //#region

    // 在文档中添加一个用于显示错误信息的浮窗元素
    graph.on('node:mouseenter', (e) => {
      const nodeItem = e.item;
      graph.updateItem(nodeItem, {
        IsHovor: true,
      });
      console.log('node:mouseenter', nodeItem);
      let linkedLines = [];
      const edges = graph.save().edges;
      edges.forEach(edge => {
        if (edge.target === nodeItem._cfg.id|| edge.source === nodeItem._cfg.id) {
          linkedLines.push(edge.id);
        }
      });
      //if node.isrunning==false
        linkedLines.forEach(e => {
          const eg = graph.findById(e);
          eg.setState('linkBlue', true);
        });    
      if(nodeItem._cfg.model.IsLoadSuccess==false)
      {
        tooltip.textContent='Load Failed';  
        tooltip.style.display = 'block'; // 显示浮窗
        tooltip.style.left = `${e.clientX + 10}px`; // 根据鼠标位置调整浮窗位置，+10偏移防止遮挡鼠标
        tooltip.style.top = `${e.clientY + 10}px`;
      }
          
      if (nodeItem._cfg.model.IsError === true) {
        tooltip.textContent = nodeItem._cfg.model.ErrorContext; // 设置错误信息
        tooltip.style.display = 'block'; // 显示浮窗
        tooltip.style.left = `${e.clientX + 10}px`; // 根据鼠标位置调整浮窗位置，+10偏移防止遮挡鼠标
        tooltip.style.top = `${e.clientY + 10}px`;
      }
    });
    graph.on('edge:mouseenter', (e) => {
      if (document.getElementById('runButton').textContent == '运行') {
      //我希望把边成红色粗体
      const edgeItem = e.item;
      edgeItem.setState('linkRed', true);
      }
    });
    graph.on('edge:mouseleave', (e) => {
      if (document.getElementById('runButton').textContent == '运行') {
      //我希望把边成红色粗体
      const edgeItem = e.item;
      edgeItem.setState('linkRed', false);
      }
    });
    graph.on('edge:click', (e) => {
      if (document.getElementById('runButton').textContent == '运行') {
        removeEdge(e.item._cfg.id);
      }
    });
    graph.on('node:mouseleave', (e) => {
      const nodeItem = e.item;
      graph.updateItem(nodeItem, {
        IsHovor: false,
      });
      let linkedLines = [];
      const edges = graph.save().edges;
      edges.forEach(edge => {
        if (edge.target === nodeItem._cfg.id|| edge.source === nodeItem._cfg.id) {
          linkedLines.push(edge.id);
        }
      });
      const nodes=graph.save().nodes;
      const TempNode=nodes.find(node => node.id === nodeItem._cfg.id);
      let isRunning=true;
      if(TempNode.IsRunning==false)
      {
        isRunning=false;
      }  
        linkedLines.forEach(e => {
          const eg = graph.findById(e);
          if(isRunning==false || eg.target=== nodeItem._cfg.id)
          eg.setState('linkBlue', false);
        });
      
      
  tooltip.style.display = 'none'; // 隐藏浮窗
});


    graph.on('node:click', (e) => {
      const nodeItem = e.item;
      // 如果当前是 active 状态，则取消，否则设置为 active
      graph.setItemState(nodeItem, 'active', false);

    });
    graph.on('node:mousedown', (e) => {
      //检测是否是左键
      const nodeItem = e.item;
      console.log('node:mousedown', e);
        let nodes=graph.save().nodes;
        nodes.forEach((node) => {
          if(node.id === nodeItem._cfg.id) {
            node.IsError=false;
          }
        });
        ChangeDatas(nodes);
    });
    //#endregion
    //combo有关
    graph.on('beforeremoveitem', (e) => {
      if (e && e.type === 'edge' && e.item) {
        const edge = graph.findById(e.item.id);
        //if edge为undefined，说明是删除节点直接终止
        if (!edge) return;
        const sourceNode = edge.getSource();
        const targetNode = edge.getTarget();
        const sourceAnchor = sourceNode.getContainer().find(ele => ele.get('anchorPointIdx') === e.item.sourceAnchor);
        sourceAnchor.set('links', sourceAnchor.get('links') - 1);
        ChangeLink(sourceAnchor);
        if (targetNode && typeof targetNode.getContainer === 'function') {
          const targetAnchor = targetNode.getContainer().find(ele => ele.get('anchorPointIdx') === e.item.targetAnchor);
          targetAnchor.set('links', targetAnchor.get('links') - 1);
          ChangeLink(targetAnchor);
        }

        //const targetNode = edge.getTarget();
        //const targetAnchor = targetNode.getContainer()?.find(ele => ele.get('anchorPointIdx') === e.item.targetAnchor);
        //targetAnchor && targetAnchor.attr('fill', '#fff');
      }
    });
    graph.on('beforecreateedge', (e) => {

    });
    graph.on('aftercreateedge', (e) => {
      // update the sourceAnchor and targetAnchor for the newly added edge
      // todo：当检测到不是要求的方向的时候，互换point 和 anchor
      if (startType !== 'output') {
        const {source, target} = e.edge.getModel()
        const nodes = graph.save().nodes;
        const targetNode = nodes.find(node => node.id === target);
        const sourceNode = nodes.find(node => node.id === source);
        let sourceAnchorID=targetNode.Outputs[targetAnchorIdx- targetNode.Inputs.length].Id;
        let targetAnchorID=sourceNode.Inputs[sourceAnchorIdx].Id;
        if(targetNode.NodeKind=='IfNode')
        {
          sourceAnchorID=targetNode.Id;
          targetAnchorID=sourceNode.Inputs[sourceAnchorIdx].Id;
        }
        graph.updateItem(e.edge, {
          source: target,
          target: source,
          sourceAnchorID:sourceAnchorID,
          targetAnchorID:targetAnchorID,
          sourceAnchor: targetAnchorIdx,
          targetAnchor: sourceAnchorIdx,
        })
      } else {
        const {source, target} = e.edge.getModel();
        const nodes = graph.save().nodes;
        const targetNode = nodes.find(node => node.id === target);
        const sourceNode = nodes.find(node => node.id === source);
        let sourceKind=''
        const data=graph.save().nodes;
        data.forEach((node) => {
          if(node.id === source) {
            sourceKind=node.NodeKind
          }
        });
        console.log('sourceKind',sourceKind)
        if(sourceKind==='IfNode')
        {
          graph.updateItem(e.edge, {
            sourceAnchor: sourceAnchorIdx,
            targetAnchor: targetAnchorIdx,
            sourceAnchorID:sourceNode.Outputs[sourceAnchorIdx-sourceNode.Inputs.length].Id,
            targetAnchorID:targetNode.Id,
          })
        }
        else
        {
          graph.updateItem(e.edge, {
            sourceAnchor: sourceAnchorIdx,
            targetAnchor: targetAnchorIdx,
            sourceAnchorID:sourceNode.Outputs[sourceAnchorIdx-sourceNode.Inputs.length].Id,
            targetAnchorID:targetNode.Inputs[targetAnchorIdx].Id,
          })
        }

      }
      // update the curveOffset for parallel edges
      const edges = graph.save().edges;
      graph.getEdges().forEach((edge, i) => {
        graph.updateItem(edge, {
          // curveOffset: 0,
          // curvePosition: 0,
        });
      });
      //e.edge.setState('linked', true);
      const result=detectCycles(graph.save().nodes, graph.save().edges);
      if(result==null)
      {
        console.log('No cycles detected.');
      }
      else
      {
        console.log('Cycle detected:', result);
        console.log('Cycle detected:', graph.save().edges[result].id,e.edge._cfg.id);
        setTimeout(() => {
          const item = graph.findById(e.edge._cfg.id);
          // Remove the item
          removeEdge(item);
          alert('连接存在循环');
        }, 1);

      }
      console.log(graph.save())
    });
    graph.on('mousedown', (e) => {
      // e.originEvent 鼠标原生事件
      // e.item // 事件触发的物体 e.target.get('name') !== 'anchor-point'

    })
    graph.on('node:dblclick', (e) => {
      //检测isblock是否为true
      if(e.item._cfg.model.IsBlock==false)
      {
        CreatDetaile(e.item._cfg);
      }
      else
      {
        showMessage("Now is Running, Nodes Is Blocking",'#000000');
      }
    });
    graph.on('node:drag', (e) => {
      updateDomBlock(e.item._cfg);
    });

    graph.on('afterremoveitem', () => {
      console.log(graph.save());
    });
    graph.on('edge:mouseup', (e) => {
      if(e.target.get('name') === 'anchor-point') {
        //console.log('点击了锚点', e.target.get('anchorPointIdx'));
      }
    });
    graph.on('afteradditem', () => {
      //console.log(graph.save());
      // todo 在更改元素的时候保存下来
      //   由graph.save()获取到数据
    });
    window.onresize = () => {
      graph.changeSize(window.innerWidth, window.innerHeight);
    };
  }
;

const requestSaveGraphData = () => {
  // todo 在这里请求你的已保存的图数据
}
//检测循环
function validateConnections(nodes, edges) {
    for (let edge of edges) {
        const sourceNode = nodes.find(node => node.id === edge.source);
        const targetNode = nodes.find(node => node.id === edge.target);
        const sourceAnchor = edge.sourceAnchor;
        const targetAnchor = edge.targetAnchor;

        if (sourceAnchor < sourceNode.Outputs.length && targetAnchor >= targetNode.Inputs.length) {
            throw new Error(`Invalid connection from ${edge.source} to ${edge.target}`);
        }

        if (sourceAnchor >= sourceNode.Outputs.length && targetAnchor < targetNode.Inputs.length) {
            throw new Error(`Invalid connection from ${edge.source} to ${edge.target}`);
        }
    }

    console.log('All connections are valid.');
}

// 使用深度优先搜索检测循环
//
function detectCycles(nodes, edges) {
  const graph = {};
  nodes.forEach(node => graph[node.id] = []);
  edges.forEach((edge, index) => graph[edge.source].push({ target: edge.target, index }));

  const visited = {};
  const recStack = {};

  function dfs(nodeId) {
      if (!visited[nodeId]) {
          visited[nodeId] = true;
          recStack[nodeId] = true;

          for (let { target, index } of graph[nodeId]) {
              if (!visited[target] && dfs(target)) {
                  return index;  // 返回发现循环的边的索引
              } else if (recStack[target]) {
                  return index;  // 返回发现循环的边的索引
              }
          }
      }

      recStack[nodeId] = false;
      return null;  // 如果没有发现循环，返回 null
  }

  for (let node of nodes) {
      const cycleIndex = dfs(node.id);
      if (cycleIndex !== null) {
          return cycleIndex;  // 返回发现循环的边的索引
      }
  }

  console.log('No cycles detected.');
  return null;  // 如果没有发现循环，返回 null
}

//检测循环
initGraph();


let fileInfoArray = [];
InitFunction()
//按键编辑
document.getElementById('saveButton').addEventListener('click', saveFunction);
document.getElementById('NodeButton').addEventListener('click', NodeFunction);
document.getElementById('WorkFlowButton').addEventListener('click', WorkFlowFunction);
document.getElementById('runButton').addEventListener('click', runFunction);
document.getElementById('exportButton').addEventListener('click', exportFunction);
document.getElementById('recoderButton').addEventListener('click', recoderFunction);
let sideWindowVisible = false;
function saveUIState() {
  const uiState = {};
  const kindElements = document.querySelectorAll('.LeftSideWindow_node-content');
  
  kindElements.forEach(kindElement => {
      const kindId = kindElement.id;
      const isExpanded = kindElement.style.display === 'block';
      const scrollTop = kindElement.scrollTop;

      uiState[kindId] = {
          isExpanded: isExpanded,
          scrollTop: scrollTop
      };
  });

  return uiState;
}

function restoreUIState(uiState) {
  Object.keys(uiState).forEach(kindId => {
      const kindElement = document.getElementById(kindId);
      if (kindElement) {
          const state = uiState[kindId];
          kindElement.style.display = state.isExpanded ? 'block' : 'none';
          kindElement.scrollTop = state.scrollTop;
          
          // 更新箭头方向
          const toggleIcon = kindElement.previousElementSibling.querySelector('.LeftSideWindow_toggle-icon');
          if (toggleIcon) {
              toggleIcon.textContent = state.isExpanded ? '▼' : '▶';
          }
      }
  });
}
// 在全局或更高的作用域下保存初始节点信息
let initialNodes = [];
let draggedNode = null;
function NodeFunction() {
  // 保存当前UI状态
  const uiState = saveUIState();

  refreshFileList();
  console.log('NodeFunction', fileList);

  const sideWindow = document.getElementById('LeftSideWindow_side-window');
  if (!sideWindowVisible) {
      sideWindow.classList.add('visible');
  } else {
      sideWindow.classList.remove('visible');
  }
  sideWindowVisible = !sideWindowVisible;

  const container = document.getElementById('LeftSideWindow_KIND-container');

  // 先清空 initialNodes
  initialNodes = [];

  // 清空容器内容
  container.innerHTML = '';

  // 保留搜索框元素
  const searchInput = document.getElementById('search-input');
  const searchContainer = searchInput ? searchInput.parentNode : document.createElement('div');

  if (!searchInput) {
      // 添加搜索框到侧边栏顶部
      searchContainer.style.padding = '5px'; // 调整边距
      searchContainer.style.backgroundColor = '#d3d3d3';
      searchContainer.style.borderRadius = '5px';
      searchContainer.style.marginBottom = '10px';
      searchContainer.style.width = 'calc(100% - 10px)'; // 确保搜索栏宽度与类别栏一致

      const newSearchInput = document.createElement('input');
      newSearchInput.type = 'text';
      newSearchInput.id = 'search-input';
      newSearchInput.placeholder = 'Search...';
      newSearchInput.style.width = '100%';
      newSearchInput.style.padding = '5px';
      newSearchInput.style.borderRadius = '5px';
      newSearchInput.style.border = '1px solid #ccc';

      searchContainer.appendChild(newSearchInput);
      container.appendChild(searchContainer);

      newSearchInput.addEventListener('input', (event) => {
          const keyword = event.target.value.trim();
          filterComponents(keyword, container, newSearchInput, searchContainer);
          function filterComponents(keyword, container, searchInput, searchContainer) {
            let matchingNodes = [];
          
            console.log('Filtering with keyword:', keyword);
            console.log('Initial Nodes:', initialNodes.length);
          
            initialNodes.forEach(node => {
                const text = node.innerText.toLowerCase();
                console.log('text:', text);
                const matches = text.includes(keyword.toLowerCase());
          
                if (matches) {
                    matchingNodes.push(node);
                }
            });
          
            // 在渲染前手动移除浮窗（如果存在）
            removeFloatingWindows();
          
            // 获取搜索框的光标位置
            const cursorPosition = searchInput.selectionStart;
          
            // 清空容器内容，但保留搜索框
            container.innerHTML = '';
            container.appendChild(searchContainer);
          
            console.log('Matching nodes:', matchingNodes.length, matchingNodes);
          
            if (keyword && matchingNodes.length > 0) {
                matchingNodes.forEach(node => {
                    node.style.display = 'block';
                    container.appendChild(node); // 直接将匹配的节点添加到 container 中
                });
            } else {
                // 如果没有关键词或搜索框为空，恢复显示所有类别和组件
                console.log('Restoring all categories');
                
                // 重新构建所有类别及其节点
                const groupedFiles = fileList.reduce((acc, file) => {
                    const key = file.NodeKind.split('_')[0];
                    if (!acc[key]) {
                        acc[key] = [];
                    }
                    acc[key].push(file);
                    return acc;
                }, {});
          
                Object.keys(groupedFiles).forEach(kind => {
                    const kindDiv = document.createElement('div');
                    kindDiv.classList.add('LeftSideWindow_kind');
                    kindDiv.innerHTML = `
                        <div class="LeftSideWindow_node">
                            ${kind} <span class="LeftSideWindow_toggle-icon">▶</span>
                        </div>
                        <div class="LeftSideWindow_node-content" id="LeftSideWindow_${kind}-content">
                        </div>
                    `;
                    container.appendChild(kindDiv);
          
                    const kindContent = kindDiv.querySelector(`#LeftSideWindow_${kind}-content`);
                    groupedFiles[kind].forEach(node => {
                        const nodeDiv = document.createElement('div');
                        nodeDiv.classList.add('LeftSideWindow_node', 'LeftSideWindow_draggable');
                        nodeDiv.innerText = node.filename.slice(0, -3); // 移除 .py 扩展名
                        nodeDiv.draggable = true;
          
                        // 手动重新绑定事件监听器
                        bindNodeEvents(nodeDiv, node);
          
                        kindContent.appendChild(nodeDiv);
                    });
          
                    const kindHeader = kindDiv.querySelector('.LeftSideWindow_node');
                    const toggleIcon = kindHeader.querySelector('.LeftSideWindow_toggle-icon');
                    kindHeader.addEventListener('click', () => {
                        const content = kindDiv.querySelector('.LeftSideWindow_node-content');
                        const isExpanded = content.style.display === 'block';
                        content.style.display = isExpanded ? 'none' : 'block';
                        toggleIcon.textContent = isExpanded ? '▶' : '▼';
                    });
                });
            }
          
            // 恢复搜索框的光标位置和焦点
            searchInput.focus();
            searchInput.setSelectionRange(cursorPosition, cursorPosition);
          }
      });
  }

  // 现在开始渲染文件列表
  const groupedFiles = fileList.reduce((acc, file) => {
      const key = file.NodeKind.split('_')[0];
      if (!acc[key]) {
          acc[key] = [];
      }
      acc[key].push(file);
      return acc;
  }, {});

  Object.keys(groupedFiles).forEach(kind => {
      const kindDiv = document.createElement('div');
      kindDiv.classList.add('LeftSideWindow_kind');
      kindDiv.innerHTML = `
          <div class="LeftSideWindow_node">
              ${kind} <span class="LeftSideWindow_toggle-icon">▶</span>
          </div>
          <div class="LeftSideWindow_node-content" id="LeftSideWindow_${kind}-content">
          </div>
      `;
      container.appendChild(kindDiv);

      const kindContent = kindDiv.querySelector(`#LeftSideWindow_${kind}-content`);
      groupedFiles[kind].forEach(node => {
          const nodeDiv = document.createElement('div');
          nodeDiv.classList.add('LeftSideWindow_node', 'LeftSideWindow_draggable');
          nodeDiv.innerText = node.filename.slice(0, -3); // 移除 .py 扩展名
          nodeDiv.draggable = true;

          // 将节点信息保存到全局存储结构中
          initialNodes.push(nodeDiv);

          // 手动重新绑定事件监听器
          bindNodeEvents(nodeDiv, node);
          function bindNodeEvents(nodeDiv, node) {
            // 悬停事件监听 - 显示浮窗
            let hoverTimeout;
            nodeDiv.addEventListener('mouseover', (event) => {
                hoverTimeout = setTimeout(() => {
                    const floatingWindow = document.createElement('div');
                    floatingWindow.classList.add('LeftSideWindow_floating-window');
          
                    let introductionText = '';
                    if (typeof node.NodeFunction.includes('String')) {
                        introductionText = node.NodeFunction.replace(/\\n/g, '<br>');
                    } else {
                        introductionText = 'No introduction available';
                    }
                    floatingWindow.innerHTML = introductionText;
          
                    document.body.appendChild(floatingWindow);
          
                    // 设置浮窗位置紧随鼠标
                    floatingWindow.style.top = `${event.clientY + 10}px`;
                    floatingWindow.style.left = `${event.clientX + 10}px`;
          
                    event.target.addEventListener('mousemove', (moveEvent) => {
                        floatingWindow.style.top = `${moveEvent.clientY + 10}px`;
                        floatingWindow.style.left = `${moveEvent.clientX + 10}px`;
                    });
          
                    event.target.addEventListener('mouseleave', () => {
                        floatingWindow.remove();
                        clearTimeout(hoverTimeout); // 清除定时器，避免内存泄漏
                    });
                }, 500); // 延迟0.5秒显示浮窗
            });
          
            nodeDiv.addEventListener('mouseleave', () => {
                clearTimeout(hoverTimeout); // 如果鼠标在0.5秒内移出，取消显示浮窗
            });
          
            nodeDiv.addEventListener('dragstart', (event) => {
                draggedNode = {
                    name: node.filename,
                    hash: node.hash,
                    kind: node.NodeKind,
                };
            });
          }
          kindContent.appendChild(nodeDiv);
      });

      const kindHeader = kindDiv.querySelector('.LeftSideWindow_node');
      const toggleIcon = kindHeader.querySelector('.LeftSideWindow_toggle-icon');
      kindHeader.addEventListener('click', () => {
          const content = kindDiv.querySelector('.LeftSideWindow_node-content');
          const isExpanded = content.style.display === 'block';
          content.style.display = isExpanded ? 'none' : 'block';
          toggleIcon.textContent = isExpanded ? '▶' : '▼';
      });
  });

  // 恢复UI状态
  restoreUIState(uiState);
  const canvas = document.getElementById('graph-container'); // 画布的容器

  // 确保 dragover 阻止默认行为
  canvas.addEventListener('dragover', (event) => {
      event.preventDefault(); // 允许放置
      console.log('dragover on canvas');
  });

  // 处理 drop 事件
  document.addEventListener('drop', (event) => {
      event.preventDefault();
      console.log('drop event triggered', draggedNode);

      if (draggedNode) {
          const x = event.clientX - canvas.getBoundingClientRect().left;
          const y = event.clientY - canvas.getBoundingClientRect().top;
          console.log('Add node at position:', x, y);
          addNode(draggedNode.name, x, y, draggedNode.hash, draggedNode.kind);
          draggedNode = null; // 仅在成功放置后重置拖拽的节点
      }
  });
}
// 创建有效的ID


// 主函数
async function WorkFlowFunction() {
  // 保存当前UI状态
  function createValidId(str) {
    return str.replace(/[^a-zA-Z0-9]/g, '_');
  }
  
  // 刷新工作流文件列表
  async function refreshWorkflowFiles() {
    try {
        console.log('Fetching workflow files...');
        const response = await fetch('/workflow-files');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        workflowFileList = await response.json();
        console.log('Workflow files received:', workflowFileList);
    } catch (error) {
        console.error('Error fetching workflow files:', error);
        workflowFileList = [];
    }
  }
  
  // 过滤工作流组件
  function filterWorkflowComponents(keyword, container, searchInput, searchContainer) {
    const components = container.querySelectorAll('.LeftSideWindow_kind');
    components.forEach(comp => {
        if (comp === searchContainer) return;
        
        const text = comp.textContent.toLowerCase();
        const searchTerm = keyword.toLowerCase();
        
        if (text.includes(searchTerm)) {
            comp.style.display = 'block';
        } else {
            comp.style.display = 'none';
        }
    });
  }
  
  // 保存UI状态
  function saveUIState() {
    const expandedFolders = [];
    document.querySelectorAll('.LeftSideWindow_node-content').forEach(content => {
        if (content.style.display === 'block') {
            expandedFolders.push(content.id);
        }
    });
    return { expandedFolders };
  }
  
  // 恢复UI状态
  function restoreUIState(state) {
    if (state.expandedFolders) {
        state.expandedFolders.forEach(id => {
            const content = document.getElementById(id);
            if (content) {
                content.style.display = 'block';
                const toggleIcon = content.parentElement.querySelector('.LeftSideWindow_toggle-icon');
                if (toggleIcon) {
                    toggleIcon.textContent = '▼';
                }
            }
        });
    }
  }
  
  
  // 添加工作流节点
  
  const uiState = saveUIState();

  // 刷新工作流文件列表
  await refreshWorkflowFiles();

  const sideWindow = document.getElementById('LeftSideWindow_side-window');
  if (!sideWindowVisible) {
      sideWindow.classList.add('visible');
  } else {
      sideWindow.classList.remove('visible');
  }
  sideWindowVisible = !sideWindowVisible;

  const container = document.getElementById('LeftSideWindow_KIND-container');
  container.innerHTML = '';

  // 保留/创建搜索框
  const searchInput = document.getElementById('workflow-search-input');
  const searchContainer = searchInput ? searchInput.parentNode : document.createElement('div');

  if (!searchInput) {
      searchContainer.style.padding = '5px';
      searchContainer.style.backgroundColor = '#d3d3d3';
      searchContainer.style.borderRadius = '5px';
      searchContainer.style.marginBottom = '10px';
      searchContainer.style.width = 'calc(100% - 10px)';

      const newSearchInput = document.createElement('input');
      newSearchInput.type = 'text';
      newSearchInput.id = 'workflow-search-input';
      newSearchInput.placeholder = 'Search workflows...';
      newSearchInput.style.width = '100%';
      newSearchInput.style.padding = '5px';
      newSearchInput.style.borderRadius = '5px';
      newSearchInput.style.border = '1px solid #ccc';

      searchContainer.appendChild(newSearchInput);
      container.appendChild(searchContainer);

      newSearchInput.addEventListener('input', (event) => {
          const keyword = event.target.value.trim();
          filterWorkflowComponents(keyword, container, newSearchInput, searchContainer);
      });
  }

  // 按文件夹分组文件
  const groupedFiles = workflowFileList.reduce((acc, file) => {
      const folderName = file.folder || 'Other';
      if (!acc[folderName]) {
          acc[folderName] = [];
      }
      acc[folderName].push(file);
      return acc;
  }, {});

  // 渲染文件夹和文件
  Object.keys(groupedFiles).forEach(folder => {
      const folderDiv = document.createElement('div');
      folderDiv.classList.add('LeftSideWindow_kind');
      const folderId = createValidId(folder);

      folderDiv.innerHTML = `
          <div class="LeftSideWindow_node">
              ${folder} <span class="LeftSideWindow_toggle-icon">▶</span>
          </div>
          <div class="LeftSideWindow_node-content" id="LeftSideWindow_${folderId}_content">
          </div>
      `;
      container.appendChild(folderDiv);

      const folderContent = folderDiv.querySelector(`#LeftSideWindow_${folderId}_content`);
      groupedFiles[folder].forEach(file => {
          const fileDiv = document.createElement('div');
          fileDiv.classList.add('LeftSideWindow_node', 'LeftSideWindow_draggable');
          fileDiv.innerText = file.filename.slice(0, -5);
          fileDiv.draggable = true;

          // 存储文件信息
          fileDiv.dataset.filepath = file.filepath;
          fileDiv.dataset.folder = folder;

          // 绑定拖拽事件
          bindWorkflowNodeEvents(fileDiv, file);
          folderContent.appendChild(fileDiv);
      });

      // 添加文件夹展开/折叠功能
      const folderHeader = folderDiv.querySelector('.LeftSideWindow_node');
      const toggleIcon = folderHeader.querySelector('.LeftSideWindow_toggle-icon');
      folderHeader.addEventListener('click', () => {
          const content = folderDiv.querySelector('.LeftSideWindow_node-content');
          const isExpanded = content.style.display === 'block';
          content.style.display = isExpanded ? 'none' : 'block';
          toggleIcon.textContent = isExpanded ? '▶' : '▼';
      });
  });

  // 恢复UI状态
  restoreUIState(uiState);
  // 辅助函数：设置画布拖放事件

// 修改bindWorkflowNodeEvents函数以添加更多日志
function bindWorkflowNodeEvents(nodeDiv, fileInfo) {
  console.log('Binding events to node:', fileInfo);

  nodeDiv.addEventListener('dragstart', (event) => {
      console.log('Drag start event triggered', fileInfo);
      draggedWorkflowNode = {
          name: fileInfo.filename.slice(0, -5),
          filepath: fileInfo.filepath,
          folder: fileInfo.folder
      };
      console.log('Set draggedWorkflowNode:', draggedWorkflowNode);
      event.dataTransfer.setData('text/plain', '');
      nodeDiv.classList.add('dragging');
  });

  nodeDiv.addEventListener('dragend', (event) => {
    console.log('Drag end event triggered');
    nodeDiv.classList.remove('dragging');
    // 获取鼠标位置
    const mousePosition = {
        x: event.clientX,
        y: event.clientY
    };
    console.log('Mouse position:', mousePosition);
    AddWorkflowNode(draggedWorkflowNode, mousePosition);
});
}
}

function animateTitle(baseTitle) {
  // 使用星月变化符号，模拟月相变化
  const animation = ['🌑', '🌒', '🌓', '🌔', '🌕', '🌖', '🌗', '🌘'];
  // 或者使用更简约的符号版本
  // const animation = ['○', '◐', '●', '◑'];
  let index = 0;

  return setInterval(() => {
      const isRunning = document.getElementById('runButton')?.textContent === '运行中...';
      
      if (isRunning) {
          let title = baseTitle;
          
          // 保持原有的命名规则
          if (IsRunningFunction) {
              title = title + '{' + passivityTriggerArray.length + '}[' + (ArrayTriggerArray.length+1).toString() + ']';
          } else {
              title = title + '{' + passivityTriggerArray.length + '}[' + ArrayTriggerArray.length + ']';
          }
          
          // 添加动画符号
          document.title = `${title} ${animation[index]}`;
          index = (index + 1) % animation.length;
      } else {
          document.title = baseTitle;
      }
  }, 1000); // 调整为更缓慢的节奏，让动画更优雅
}
// 移除页面上所有的浮窗
function removeFloatingWindows() {
  const floatingWindows = document.querySelectorAll('.LeftSideWindow_floating-window');
  floatingWindows.forEach(window => window.remove());
}

async function recoderFunction() {
  //去除后缀名".josn"
  ProjectName = ProjectName.replace('.json', '');
  console.log('recoderFunction', ProjectName);
  
  const response = await fetch('/start_Message', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ ProjectName })
  });

  if (response.ok) {
    const result = await response.json();
    console.log(result.status);
    // 打开新的域名
    window.open(`http://127.0.0.1:2999/?project_name=${ProjectName}`, '_blank');
  } else {
    console.error('Failed to start project');
  }
}

async function exportFunction() {
  let choice = confirm("是否要保存当前图的代码？选择“确定”继续选择保存类型。");
  if (choice) {
    let option = confirm("选择“确定”保存为完整的 Python 代码，选择“取消”选择独立的 Python 代码。");
    if (option) {
      const graphData = graph.save();
      await exportGraphData(graphData, "full");
    } else {
      const graphData = graph.save();
      await exportGraphData(graphData, "independent");
    }
  }
}

async function exportGraphData(graphData, type) {
  const fileName = prompt("请输入保存的文件名（不含扩展名）：");
  if (fileName) {
    const response = await fetch('/export', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ graphData, fileName, type })
    });

    if (response.ok) {
        alert('图数据已成功导出为 Python 函数');
    } else {
        alert('导出失败');
    }
  }
}

function updateDomBlock(item) {
  // 从 item 中提取模型数据

}
function initializeDragAndResize(Nodes,maxWidth,maxHeight) {
  let onMove = false;
  let offsetX, offsetY;

  // 获取初始样式以便之后计算
  let oddStyle = window.getComputedStyle(Nodes);
  const content = document.getElementById('graph-container'); // 假设这是外层容器，已正确设置
  // 假设 scaleX 和 scaleY 已在外部定义
  const dragElement = Nodes.querySelector(".drag-bar"); // 假设你的 Nodes 元素内部有 .drag-bar 元素
  if (dragElement) {
      dragElement.addEventListener("mousedown", function(e) {
          onMove = true;
          const contentRect = content.getBoundingClientRect();
          // 考虑缩放和content位置，调整鼠标位置计算
          offsetX = (e.clientX - contentRect.left) - parseFloat(oddStyle.left);
          offsetY = (e.clientY - contentRect.top)  - parseFloat(oddStyle.top);
          document.addEventListener("mousemove", onMouseMove);
          document.addEventListener("mouseup", onMouseUp);
      });
  }
// 为 Nodes 内的所有 .circle 元素添加事件监听器

  // circle.addEventListener('mouseup', stopLining)
function onMouseMove(e) {
      if (onMove) {
          const contentRect = content.getBoundingClientRect();
          // 考虑缩放和content位置，调整元素新位置的计算
          let newX = (e.clientX - contentRect.left) - offsetX;
          let newY = (e.clientY - contentRect.top) - offsetY;
          Nodes.style.left = `${newX}px`;
          Nodes.style.top = `${newY}px`;
      }
  }

  function onMouseUp() {
      onMove = false;
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
  }
  // 边缘调整大小的初始化
  //resizeOnEdge(Nodes, ".edge-right", "width",maxWidth);
 // resizeOnEdge(Nodes, ".edge-left", "width",maxWidth);
  //resizeOnEdge(Nodes, ".edge-top", "height",maxHeight);
  //resizeOnEdge(Nodes, ".edge-bottom", "height",maxHeight);
}
function resizeOnEdge(Nodes, edgeClass, moveAxis,maxNum) {
  const target = Nodes.querySelector(edgeClass);
  const content = document.getElementById('graph-container'); // 获取缩放容器
  // 假设scaleX和Viewspace.scaleY变量已经根据容器的缩放比例进行了设置
  if (!target) return;

  target.addEventListener("mousedown", function(e) {
      const contentRect = content.getBoundingClientRect();
      let startWidth = parseFloat(window.getComputedStyle(Nodes).width);
      let startHeight = parseFloat(window.getComputedStyle(Nodes).height);
      let startX = (e.clientX - contentRect.left) ;
      let startY = (e.clientY - contentRect.top) ;
      let startPos = { left: parseFloat(Nodes.style.left || 0), top: parseFloat(Nodes.style.top || 0) };

      function onMouseMove(e) {
          let mouseX = (e.clientX - contentRect.left) ;
          let mouseY = (e.clientY - contentRect.top) ;
          let deltaWidth = mouseX - startX;
          let deltaHeight = mouseY - startY;

          if (moveAxis === "width") {

              if (edgeClass.includes("-left")) {
                  let newWidth = startWidth - deltaWidth;
                  Nodes.style.width = `${Math.max(maxNum, newWidth)}px`;
                  Nodes.style.left = `${startPos.left + deltaWidth}px`;
              }
              else
              {
                  let newWidth = startWidth + deltaWidth;
                  Nodes.style.width = `${Math.max(maxNum, newWidth)}px`;
              }

          } else if (moveAxis === "height") {

              if (edgeClass.includes("-top")) {
                  let newHeight = startHeight - deltaHeight;
                  Nodes.style.top = `${startPos.top + deltaHeight}px`;
                  Nodes.style.height = `${Math.max(maxNum, newHeight)}px`;
              }
              else
              {
                  let newHeight = startHeight + deltaHeight;
                  Nodes.style.height = `${Math.max(maxNum, newHeight)}px`;
              }
          }
      }

      function onMouseUp() {
          document.removeEventListener("mousemove", onMouseMove);
          document.removeEventListener("mouseup", onMouseUp);
      }

      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
      e.preventDefault();
  });
}
function showMessage(message,color) {
  const messageContainer = document.getElementById('message-container');
  const messageText = document.getElementById('message-text');

  messageText.textContent = message;
  messageText.style.color = color;
  messageContainer.style.display = 'block'; // 显示消息
  messageContainer.style.opacity = 1; // 重置透明度为完全不透明
  messageContainer.style.top = '20px'; // 重置顶部位置
  messageText.style.fontWeight = 'bold';//粗体字

  // 短暂延迟后应用动画效果
  setTimeout(() => {
    messageContainer.classList.add('message-fade');
  }, 10); // 短暂延迟确保样式应用正确

  // 完成后隐藏和清理消息容器
  setTimeout(() => {
    messageContainer.style.display = 'none';
    messageContainer.classList.remove('message-fade'); // 移除类以重置动画
  }, 3000); // 3秒后隐藏消息
}


function ChangeNodeLabel(id, name, Kind) {
  if (Kind === -1) {
    // 获取当前图形的所有节点数据
    const nodes = graph.save().nodes;

    // 检查是否存在与给定 Name 重名的节点
    const nameExists = nodes.some(node => node.id !== id && node.label === name);

    if (nameExists) {
      // 如果存在重名，弹出提示框并终止函数执行
      alert('已存在相同名称的节点，请选择不同的名称！');
      return;
    }
    let data = graph.save();
    // 如果没有重名，找到对应的节点并更新其名称
    const nodeIndex = data.nodes.findIndex(node => node.id === id);

    // If the node is found, update its label
    if (nodeIndex !== -1) {
      data.nodes[nodeIndex].label = name;

      // Apply the modified data to the graph
      ChangeDatas(data);
    } else {
      // Optional: Alert or log if the specific node id was not found
      console.log('未找到对应的节点ID');
    }
  }
}
function ChangeRetryNum(id,Value) {
  let data = graph.save();
  const nodeIndex = data.nodes.findIndex(node => node.id === id);
  if (nodeIndex != -1) {
    //转换成int
    data.nodes[nodeIndex].ReTryNum = parseInt(Value);
    ChangeDatas(data);
  } else {
    console.log('未找到对应的节点ID');
  }
}
function ChangeLlmSetting(id,Value) {
  const nodes = graph.save().nodes;
  console.log('Value',Value);
  let nameExists = false;
  nodes.forEach(node => {
  if(node.id == id)
  {
    nameExists = true;
    node.name=Value[0]+'.py'
    node.temperature=Value[1]
    node.Top_p=Value[2]
    node.frequency_penalty=Value[3]
    node.presence_penalty=Value[4]
    node.max_tokens=Value[5]
  }
  });
  if(nameExists)
  {
    let data = graph.save();
    ChangeDatas(data);
    console.log('修改成功',data);
  }
  else
  {
    console.log('未找到对应的节点ID');
  }
}
function ChangeAnchorValue(Nodeid,Value,Status,id) {
    if(Status=='Input')
    {
        const nodes = graph.save().nodes;
        let nameExists = false;
        nodes.forEach(node => {
        if(node.id == Nodeid)
        node.Inputs.forEach(input => {
          if (input.Id !== id ) {
            nameExists = true;
          }
        });
      });
      let data = graph.save();
      const nodeIndex = data.nodes.findIndex(node => node.id === Nodeid);
      const anchorIndex = data.nodes[nodeIndex].Inputs.findIndex(input => input.Id === id); // 假设 Inputs 是一个数组
      if (anchorIndex != -1) {
        data.nodes[nodeIndex].Inputs[anchorIndex].IsLabel = true;
        if (data.nodes[nodeIndex].Inputs[anchorIndex].Kind == 'Num')
        {
          data.nodes[nodeIndex].Inputs[anchorIndex].Num = parseInt(Value);
        }
        else if (data.nodes[nodeIndex].Inputs[anchorIndex].Kind.includes('String'))
        {
          data.nodes[nodeIndex].Inputs[anchorIndex].Context = Value.trim();
        }
        else if (data.nodes[nodeIndex].Inputs[anchorIndex].Kind == 'Boolean')
        {
          if(Value == 'true')
          {
            data.nodes[nodeIndex].Inputs[anchorIndex].Boolean = true;
          }
          else
          {
            data.nodes[nodeIndex].Inputs[anchorIndex].Boolean = false;
          }
        }
        data=graph.save();
        data.nodes.forEach(node => {
          if(node.id == Nodeid)
          {
            node.Inputs.forEach(input => {
              if (input.Id == id )
              {
                input.Link = 1;
              }
            });
          }
        });
        const edges = data.edges;
        edges.forEach((edge, index) => {
          if (edge.target == Nodeid && edge.targetAnchorID == id) {
              //移除边
              edges.splice(index, 1);
          }
        });
        ChangeDatas(data);
        RefreshEdge();
      } else {
        console.error('未找到对应的锚点ID');
      }
    }
    else if(Status=='link')
    {
      let data = graph.save();
      const nodeIndex = data.nodes.findIndex(node => node.id === Nodeid);
      const anchorIndex = data.nodes[nodeIndex].Inputs.findIndex(input => input.Id === id); // 假设 Inputs 是一个数组
      if (anchorIndex != -1) {
        data.nodes[nodeIndex].Inputs[anchorIndex].IsLabel = false;
        data.nodes[nodeIndex].Inputs[anchorIndex].Link = 0;
        ChangeDatas(data);
      }
    }

}

function ChangeAnchorLabel(Nodeid, name, Kind,id,IsInput) {
  const nodes = graph.save().nodes;
  console.log('Kind',Kind);
  if(typeof Kind === 'string' && Kind.includes('selectBox'))
    {
        let nameExists = false;
        nodes.forEach(node => {
        if(node.id == Nodeid)
        node.Inputs.forEach(input => {
          if (input.Id !== id && input.name === name) {
            nameExists = true;
          }
        });
      });
      if (nameExists) {
          alert('已存在相同名称的锚点，请选择不同的名称！');
          return;
      }
      let data = graph.save();
      const nodeIndex = data.nodes.findIndex(node => node.id === Nodeid);
      const anchorIndex = data.nodes[nodeIndex].Outputs.findIndex(output => output.Id === id);
      if (anchorIndex != -1) {
        //将kind转化成键值
        data.nodes[nodeIndex].Outputs[anchorIndex][Kind]=name;
        ChangeDatas(data);
      } else {
        console.error('未找到对应的锚点ID');
      }
    }  
    else if(typeof Kind === 'string' && Kind=='OriginalText')
    {
      //修改对应node的OriginalTextName
      let nameExists = false;
      nodes.forEach(node => {
      if(node.id == Nodeid)
      {
        nameExists = true;
        node.Outputs[0].name=name;
      }
      });
      if(nameExists)
      {
        let data = graph.save();
        ChangeDatas(data);
      }
      else
      {
        console.log('未找到对应的节点ID');
      }

    }
    else
    {
      if(IsInput==true)
        {
            let nameExists = false;
            nodes.forEach(node => {
            if(node.id == Nodeid)
            node.Inputs.forEach(input => {
              if (input.Id !== id && input.name === name) {
                nameExists = true;
              }
            });
          });
          if (nameExists) {
              alert('已存在相同名称的矛点，请选择不同的名称！');
              return;
          }
          let data = graph.save();
          const nodeIndex = data.nodes.findIndex(node => node.id === Nodeid);
          const anchorIndex = data.nodes[nodeIndex].Inputs.findIndex(input => input.Id === id); // 假设 Inputs 是一个数组
          if (anchorIndex != -1) {
            data.nodes[nodeIndex].Inputs[anchorIndex].name = name;
            ChangeDatas(data);
          } else {
            console.error('未找到对应的锚点ID');
          }
        }
        else
        {
            let nameExists = false;
            nodes.forEach(node => {
            if(node.id == Nodeid)
            node.Outputs.forEach(output => {
              if (output.Id !== id && output.name === name) {
                nameExists = true;
              }
            });
          });
          if (nameExists) {
            alert('已存在相同名称的矛点，请选择不同的名称！');
            return;
          }
          let data = graph.save();
          const nodeIndex = data.nodes.findIndex(node => node.id === Nodeid);
          const anchorIndex = data.nodes[nodeIndex].Outputs.findIndex(output => output.Id === id); // 假设 Inputs 是一个数组
          if (anchorIndex != -1) {
            data.nodes[nodeIndex].Outputs[anchorIndex].name = name;
            ChangeDatas(data);
          } else {
            console.error('未找到对应的锚点ID');
          }
        }
    }
}
function CreatFilePath(id,Nodeid) {
  const nodes = graph.save().nodes;
  let FilePath= '';
  nodes.forEach(node => {
      if(node.id == Nodeid)
      {
        node.Inputs.forEach(input => {
          if (input.Id == id )
          {
            //input.Context包含字符
            if (input.Context && /[\S]/.test(input.Context)) {
              FilePath = input.Context;
          }
          }
        });
      }
  });
  let domElement = document.getElementById(`dom-${Nodeid}-${id}-FilePath`);
  if (!domElement) {
      domElement = document.createElement('div');
      domElement.id = `dom-${Nodeid}-${id}-FilePath`;
      domElement.className = 'Nodes';
      domElement.style.cssText = `
          position: absolute;
          left: 500px;
          top: 500px;
          width: 900px;
          height: 1000px;
          border-radius: 10px;
          border: 2px solid #ccc;  
          background-color: #f9f9f9;
          padding: 0;
          box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
          display: flex;
          flex-direction: column;
          overflow: hidden;
      `;

      const dragBar = document.createElement('div');
      dragBar.className = 'drag-bar';
      dragBar.style.cssText = `
          cursor: move;
          height: 30px;
          width: 100%;
          background-color: #4CAF50;
          border-radius: 10px 10px 0 0;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 0 10px;
      `;
      const title = document.createElement('span');
      title.style.cssText = `
          font-weight: bold;
          color: white;
          font-size: 16px;
      `;
      title.textContent = 'FilePath';
      dragBar.appendChild(title);
      domElement.appendChild(dragBar);

      dragBar.addEventListener('mousedown', function(e) {
          e.preventDefault();
          let posX = e.clientX;
          let posY = e.clientY;
          const onMouseMove = function(e) {
              let dx = e.clientX - posX;
              let dy = e.clientY - posY;
              domElement.style.left = `${domElement.offsetLeft + dx}px`;
              domElement.style.top = `${domElement.offsetTop + dy}px`;
              posX = e.clientX;
              posY = e.clientY;
          };
          const onMouseUp = function() {
              document.removeEventListener('mousemove', onMouseMove);
              document.removeEventListener('mouseup', onMouseUp);
          };
          document.addEventListener('mousemove', onMouseMove);
          document.addEventListener('mouseup', onMouseUp);
      });

      let vessel = document.createElement('div');
      vessel.className = 'Vessel';
      vessel.style.cssText = `
          position: relative;
          flex-grow: 1;
          display: flex;
          flex-direction: row;
          flex-wrap: wrap;
          overflow-y: auto;
          overflow-x: hidden;
          background-color: #f0f0f0;
          padding: 10px;
          border: none;
          align-content: flex-start;
      `;
      domElement.appendChild(vessel);

      const navContainer = document.createElement('div');
      navContainer.style.cssText = `
          display: flex;
          background-color: #f0f0f0;
          padding: 5px;
          border-top: 1px solid #ccc;
          align-items: center;
      `;

      const backButton = document.createElement('button');
      backButton.innerHTML = '&#8592;';
      backButton.style.cssText = `
          width: 48px;
          height: 30px;
      `;
      backButton.addEventListener('click', function() {
          navigateBack();
      });
      navContainer.appendChild(backButton);

      const forwardButton = document.createElement('button');
      forwardButton.innerHTML = '&#8594;';
      forwardButton.style.cssText = `
          width: 48px;
          height: 30px;
          margin-left: 5px;
      `;
      forwardButton.addEventListener('click', function() {
          navigateForward();
      });
      navContainer.appendChild(forwardButton);

      let pathDisplay = document.createElement('input');
      pathDisplay.type = 'text';
      pathDisplay.style.cssText = `
          flex-grow: 1;
          margin: 0 10px;
          padding: 5px;
          border: 1px solid #ccc;
          background-color: #f0f0f0;
          outline: none;
      `;

      navContainer.appendChild(pathDisplay);

      domElement.appendChild(navContainer);

      const buttonContainer = document.createElement('div');
      buttonContainer.style.cssText = `
          display: flex;
          justify-content: space-between;
          padding: 5px;
          border-top: 1px solid #ccc;
      `;

      let selectedFilePathButton = document.createElement('button');
      selectedFilePathButton.textContent = 'Selected File Path';
      selectedFilePathButton.style.cssText = `
          width: 48%;
          margin-top: 5px;
      `;
      selectedFilePathButton.addEventListener('click', function() {
        let data = graph.save();
        const nodeIndex = data.nodes.findIndex(node => node.id === Nodeid);
        data.nodes[nodeIndex].Inputs.forEach(input => {
            if (input.Id == id) {
                if (domElement && domElement.parentNode) { // 检查 domElement 和它的父节点是否存在
                    domElement.parentNode.removeChild(domElement);
                } else {
                    console.error('domElement or its parentNode is null, cannot remove the element.');
                }
    
                const index = domBlocks.findIndex(block => block.id === `dom-${Nodeid}-${id}-FilePath`);
                if (index > -1) {
                    domBlocks.splice(index, 1);
                }
                input.Context = pathDisplay.value;
    
                let uniqueClass = `unique-textarea-${Nodeid}-${input.Id}`; // 使用 input.Id 生成唯一的类名
                document.querySelectorAll('[id]').forEach(element => {
                    if (element.id === uniqueClass) {
                        console.log('识别');
                        element.value = pathDisplay.value;
                        const event = new Event('input', {
                            bubbles: true, // 事件是否应该冒泡
                            cancelable: true // 事件是否可以被取消
                        });
                        element.dispatchEvent(event); // 触发事件
                        return; // 立即终止循环，防止修改多个元素
                    }
                });
            }
        });
    });
    
      buttonContainer.appendChild(selectedFilePathButton);

      const cancelButton = document.createElement('button');
      cancelButton.textContent = 'Cancel';
      cancelButton.style.cssText = `
          width: 48%;
          margin-top: 5px;
      `;
      cancelButton.addEventListener('click', function() {
          domElement.parentNode.removeChild(domElement);
          const index = domBlocks.findIndex(block => block.id === `dom-${id}-FilePath`);
          if (index > -1) {
              domBlocks.splice(index, 1);
          }
      });
      buttonContainer.appendChild(cancelButton);

      domElement.appendChild(buttonContainer);

      let currentPath = '';
      if(FilePath!='')
        currentPath = FilePath;
      let historyStack = [];
      let forwardStack = [];
      loadDirectory(currentPath, vessel, selectedFilePathButton, pathDisplay);
      console.log('Creating domElement:', domElement);
      document.getElementById('graph-container').appendChild(domElement);
      console.log('domElement added to body');

      vessel.addEventListener('click', function(e) {
          if (e.target === vessel) {
              pathDisplay.value = currentPath;
          }
      });

      function formatPath(path) {
          return path.replace(/\\/g, '\\\\').replace(/\\\\+/g, '\\\\');
      }

      function loadDirectory(path, container, selectedFilePathButton, pathDisplay, isUserInput = false) {
          if (path === '') {
              const drives = ['C:\\', 'D:\\', 'E:\\', 'F:\\','@TempFiles'];
              container.innerHTML = '';
              drives.forEach(drive => {
                  const element = document.createElement('div');
                  element.className = 'item-container';
                  element.style.cssText = `
                      display: flex;
                      flex-direction: column;
                      align-items: center;
                      width: 80px;
                      margin: 10px;
                      text-align: center;
                  `;
                  
                  const icon = document.createElement('img');
                  icon.src = '/static/icons/drive-icon.png';
                  icon.style.cssText = `
                      width: 48px;
                      height: 48px;
                      margin-bottom: 5px;
                  `;

                  const text = document.createElement('span');
                  text.textContent = drive;
                  text.style.cssText = `
                      font-size: 12px;
                      white-space: pre-wrap;
                      word-wrap: break-word;
                      word-break: break-all;
                  `;

                  element.appendChild(icon);
                  element.appendChild(text);

                  element.addEventListener('click', function() {
                      loadDirectory(drive, container, selectedFilePathButton, pathDisplay);
                  });

                  container.appendChild(element);
              });
          } else {
              if (currentPath && !isUserInput) {
                  historyStack.push(currentPath);
              }

              fetch('/browse', {
                  method: 'POST',
                  headers: {
                      'Content-Type': 'application/json'
                  },
                  body: JSON.stringify({ path: path })
              })
              .then(response => response.json())
              .then(data => {
                  if (data.error) {
                      if (isUserInput) {
                          container.innerHTML = '<p style="padding: 10px; color: red;">路径错误</p>';
                      }
                      console.error('错误:', data.error || '目录中没有文件。');
                  } else {
                      currentPath = formatPath(path);
                      pathDisplay.value = currentPath;
                      updateUI(data, currentPath, container, selectedFilePathButton, pathDisplay);
                  }
              })
              .catch(error => {
                  if (isUserInput) {
                      container.innerHTML = '<p style="padding: 10px; color: red;">路径错误</p>';
                  }
                  console.error('错误:', error);
              });
          }
      }
      pathDisplay.addEventListener('input', function() {
        const newPath = pathDisplay.value;
        if (newPath) {
            fetch('/browse', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ path: newPath })
            })
            .then(response => response.json())
            .then(data => {
                if (data.error || data.length === 0) {
                    vessel.innerHTML = '<p style="padding: 10px; color: red;">路径错误</p>';
                    console.error('错误:', data.error || '目录中没有文件。');
                } else {
                    currentPath = formatPath(newPath);
                    updateUI(data, currentPath, vessel, selectedFilePathButton, pathDisplay);
                }
            })
            .catch(error => {
                vessel.innerHTML = '<p style="padding: 10px; color: red;">路径错误</p>';
                console.error('错误:', error);
            });
        }
    });
    
    function updateUI(items, path, container, selectedFilePathButton, pathDisplay) {
          container.innerHTML = '';
          items.forEach(item => {
              const element = document.createElement('div');
              element.className = 'item-container';
              element.style.cssText = `
                  display: flex;
                  flex-direction: column;
                  align-items: center;
                  width: 80px;
                  margin: 10px;
                  text-align: center;
              `;

              const icon = document.createElement('img');
              icon.src = item.is_dir ? '/static/icons/folder-icon.png' : '/static/icons/file-icon.png';
              icon.style.cssText = `
                  width: 48px;
                  height: 48px;
                  margin-bottom: 5px;
              `;

              const text = document.createElement('span');
              text.textContent = item.name;
              text.style.cssText = `
                  font-size: 12px;
                  white-space: pre-wrap;
                  word-wrap: break-word;
                  word-break: break-all;
              `;

              element.appendChild(icon);
              element.appendChild(text);

              element.addEventListener('click', function(e) {
                  e.stopPropagation();
                  document.querySelectorAll('.item-container').forEach(el => {
                      el.style.backgroundColor = 'white';
                  });
                  element.style.backgroundColor = '#d3d3d3';
                  if (item.is_dir) {
                      loadDirectory(item.path, container, selectedFilePathButton, pathDisplay);
                  } else {
                      pathDisplay.value = formatPath(item.path);
                  }
              });

              container.appendChild(element);
          });
      }
        function navigateBack() {
          // 检测路径是否是根目录或空路径，并检查最后一个 '\' 后面是否有其他字符
          console.log('currentPath:', currentPath, (currentPath.match(/\\/g) || []).length);
      
          // 使用正则表达式来检测路径是否符合要求
          // 匹配根路径或路径中最后一个 '\' 后没有其他字符的情况
          const regex = /^([A-Z]:\\)$|(^[A-Z]:\\[^\\]+$)/i;
      
          if (!regex.test(currentPath) && (currentPath.match(/\\/g) || []).length <= 1) {
              pathDisplay.value = '';
              currentPath = ''; // 清空 currentPath
              loadDirectory('', vessel, selectedFilePathButton, pathDisplay); // 跳转回驱动选择界面
              return;
          }
      
          if (currentPath.includes('\\') && currentPath.lastIndexOf('\\') > 2) {
              forwardStack.push(currentPath);
              currentPath = currentPath.replace(/\\+$/, '');
              let pathParts = currentPath.split('\\');
              pathParts.pop();
              if (pathParts.length > 0) {
                  currentPath = pathParts.join('\\');
                  loadDirectory(currentPath, vessel, selectedFilePathButton, pathDisplay);
              } else {
                  console.log('已经在根目录，无法继续后退');
              }
          }
      }
    
      function navigateForward() {
        if (forwardStack.length > 0) {
            currentPath = forwardStack.pop();
            loadDirectory(currentPath, vessel, selectedFilePathButton, pathDisplay);
        }
      }
  }
}
function populateSelectBoxFromObject(addedKeys, obj, parentKey = "", selectBoxTemp) {
  function addOptionsFromObject(addedKeys, obj, parentKey = "", selectBoxTemp) {
    // 检查 obj 是否为字符串
    if (typeof obj === 'string') {
      // 如果是字符串，直接添加为选项
      if (!addedKeys.has(obj)) {
        const option = document.createElement('option');
        option.value = obj;
        option.text = obj;
        selectBoxTemp.appendChild(option);
        addedKeys.add(obj);
      }
    }
    // 检查 obj 是否为数组
    else if (Array.isArray(obj)) {
      // 如果是数组，直接排序并添加选项
      const sortedItems = obj.sort((a, b) => {
        const numA = parseInt(a.split('/')[0]);
        const numB = parseInt(b.split('/')[0]);
        return numA - numB;  // 升序排列
      });

      for (let i = 0; i < sortedItems.length; i++) {
        const fullKey = sortedItems[i];
        if (!addedKeys.has(fullKey)) {
          const option = document.createElement('option');
          option.value = fullKey;
          option.text = fullKey;
          selectBoxTemp.appendChild(option);
          addedKeys.add(fullKey);
        }
      }
    } else if (typeof obj === 'object' && obj !== null) {
      // 如果是对象，保持原有的处理逻辑
      const keys = Object.keys(obj).sort((a, b) => {
        const numA = parseInt(a.split('/')[0]);
        const numB = parseInt(b.split('/')[0]);
        return numB - numA;
      });

      for (let i = keys.length - 1; i >= 0; i--) {
        const key = keys[i];
        if (obj.hasOwnProperty(key)) {
          const fullKey = parentKey ? `${parentKey}/${key}` : key;
          if (!addedKeys.has(fullKey)) {
            const option = document.createElement('option');
            option.value = fullKey;
            option.text = fullKey;
            selectBoxTemp.appendChild(option);
            addedKeys.add(fullKey);
          }

          const value = obj[key];
          if (typeof value === 'object' && !Array.isArray(value)) {
            addOptionsFromObject(addedKeys, value, fullKey, selectBoxTemp);
          }
        }
      }
    }
  }

  addOptionsFromObject(addedKeys, obj, parentKey, selectBoxTemp);
}


function SearchOutput(id,IdTemp)
{
let dataTemp = graph.save();

let nodeTemp = dataTemp.nodes.filter(node => node.id === id);
let outputTemp = nodeTemp[0].Outputs.filter(output => output.Id === IdTemp)[0];
return outputTemp;
}
function adjustHeight(textarea) {
  textarea.style.height = 'auto'; // 重置高度以获得正确的滚动高度
  textarea.style.height = `${textarea.scrollHeight}px`;
}
function CreatDetaile(Item)
  {
    // 确保 item.model 中包含 x, y 位置和 id
    const { x, y, id,width,height,label,Inputs,Outputs,NodeKind,prompt,ReTryNum,name,Top_p,presence_penalty,frequency_penalty,temperature,max_tokens,OriginalTextSelector,OriginalTextName,InputIsAdd,OutputsIsAdd} = Item.model;
    // 创建 DOM 元素或者更新现有元素
    console.log('Inputs',InputIsAdd,OutputsIsAdd);
    let domElement = document.getElementById(`dom-${id}`);
  if (!domElement) {
    domElement = document.createElement('div');
    domElement.id = `dom-${id}`;
    document.className = 'Nodes';
    domElement.style.cssText = `
      position: absolute;
      left: ${500}px;
      top: ${500}px;
      width: ${600}px;
      height: ${400}px;
      border-radius: 10px;
    `;
    const NameId = document.createElement('input'); // 创建 input 元素而不是 div
    NameId.value = label; // 设置输入框的初始值为 id
    NameId.style.cssText = `
        position: absolute;
        left: 24px; // 使用 px，因为这是 CSS 中的单位
        top: 30px; // 使用 px
        width: 200px; // 可以根据需要调整宽度
        height: 30px; // 可以根据需要调整高度
    `;
    NameId.addEventListener('focus', function() {
    });

    // 当输入框失去焦点时触发
    NameId.addEventListener('input', function() {
        ChangeNodeLabel(id,NameId.value,-1);
    });
    domElement.appendChild(NameId);
    const dragBar = document.createElement('div');
    dragBar.className = 'drag-bar';
    domElement.appendChild(dragBar);

    // 添加图标到 .drag-bar
    const icons = ['w-out'];
    icons.forEach(iconClass => {
        const icon = document.createElement('div');
        icon.className = iconClass;
        icon.style.left=-5;
        icon.style.top=-5;
        icon.style.width=20;
        icon.style.height=20;
        dragBar.appendChild(icon);
        icon.addEventListener('click', function() {
          domElement.parentNode.removeChild(domElement); // 移除 DOM 元素
          // 从数组中移除
          const index = domBlocks.findIndex(block => block.id === `dom-${id}`);
          if (index > -1) {
            domBlocks.splice(index, 1);
          }
        });
    });
    // 创建 .Vessel 并设置内容

    // 创建边缘可拖动区域
    const edges = ['edge-top', 'edge-bottom', 'edge-right', 'edge-left'];
    edges.forEach(edgeClass => {
        const edge = document.createElement('div');
        edge.className = `edge ${edgeClass}`;
        domElement.appendChild(edge);
    });
    // 创建角落可拖动区域
    const corners = ['corner-lt', 'corner-lb', 'corner-rt', 'corner-rb'];
    corners.forEach(cornerClass => {
        const corner = document.createElement('div');
        corner.className = `corner ${cornerClass}`;
        domElement.appendChild(corner);
    });
    const vessel = document.createElement('div');
    vessel.className = 'Vessel';

    domElement.appendChild(vessel);
    // 创建 ResetColumn 容器
    const ResetColumn = document.createElement('div');
    ResetColumn.className = 'column';
    ResetColumn.style.cssText = `
        position: relative;
        display: flex;
        align-items: center; /* 垂直居中对齐 */
        flex-direction: row; /* 确保子元素水平排列 */
    `;

    // 创建输入框容器
    const inputContainer = document.createElement('div');
    inputContainer.style.cssText = `
        display: flex;
        align-items: center; /* 垂直居中对齐 */
        margin-right: 10px; /* 确保输入框和标签之间有间距 */
    `;

    // 创建输入框
    const input = document.createElement('input');
    input.type = 'number';
    input.value = ReTryNum;
    input.style.cssText = `
        width: 30px; /* 调整输入框的宽度 */
        text-align: center;
    `;

    inputContainer.appendChild(input);

    // 创建并设置 ReTryNumlabel
    const ReTryNumlabel = document.createElement('div');
    ReTryNumlabel.textContent = 'ReTryNum'; // 设置文本
    ReTryNumlabel.className = 'column-label'; // 设置样式类
    ReTryNumlabel.style.cssText = `
        position: relative;
        top: -5px;
        display: flex;
        align-items: center; /* 垂直居中对齐 */
    `;

    ResetColumn.appendChild(inputContainer);
    ResetColumn.appendChild(ReTryNumlabel);

    inputContainer.appendChild(input);
    ResetColumn.appendChild(inputContainer);
    vessel.appendChild(ResetColumn);
    input.addEventListener('input', function() {
      if(input.value<0)
        {
          input.value=0;
        }
      ChangeRetryNum(id,input.value);
    });

    // 创建输入列
 // 创建输入列
    // 创建输入列并添加标签
    if(NodeKind=='ArrayTrigger_DataBase')
    {
      const inputColumn = document.createElement('div');
      inputColumn.className = 'column';
      const inputLabel = document.createElement('div');
      inputLabel.textContent = 'Input'; // 设置文本
      inputLabel.className = 'column-label'; // 设置样式类
      inputColumn.appendChild(inputLabel);
      vessel.appendChild(inputColumn);
      // 调整textarea高度以适应内容
      // 输入框空格键增长逻辑
      let IdTemp='';
      const outputColumn = document.createElement('div');
      outputColumn.className = 'column';
      const addNode1 = document.createElement('div');
      addNode1.className = 'column-AddNode'; // 使用之前定义的样式类
      addNode1.style.left = '60px'; // 设置左边距
      outputColumn.appendChild(addNode1);
      const outputLabel = document.createElement('div');
      outputLabel.textContent = 'Output'; // 设置文本
      outputLabel.className = 'column-label'; // 设置样式类
      outputColumn.appendChild(outputLabel);
      // 将输入和输出列添加到节点容器中
      addNode1.onmousedown = function() {
        let data=graph.save();
        data.nodes.forEach((node) => {
          if(node.id == id && node.TempOutPuts!=undefined && node.TempOutPuts!=null && node.TempOutPuts.length!=0)
          {
            IdTemp='Output' + (node.Outputs.length + 1).toString()+Date.now();
            let TempName = 'Output' + (node.Outputs.length + 1).toString();
            let counter = 1; // 新增一个计数器
            // 检查是否重名，如果重名则+1继续检查
            while (node.Outputs.some(output => output.name === TempName)) {
                TempName = 'Output' + (node.Outputs.length + 1 + counter).toString(); // 使用计数器调整名称
                counter++; // 每次循环递增计数器
            }
            node.Outputs.push({
              'Num': 0,
              'Kind': 'String',
              'Id': IdTemp,
              'Context': '',
              'Boolean': false,
              'Isnecessary': false,
              'name': TempName,
              'Link': 0,
              'IsLabel': false,
          });
          const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
          node.anchorPoints = node.Inputs.map((node, index) => {
              const anchorHeight = 60 + index * 20;
              return [0.05, anchorHeight / maxHeight]
            }).concat(node.Outputs.map((node, index) => {
              const anchorHeight = 60 + index * 20;
              return [0.95, anchorHeight / maxHeight]
            })).concat([[0, 0]]);
          CreatOutputs(node.Outputs[node.Outputs.length - 1],node.Outputs.length - 1,IdTemp);
          ChangeDatas(data);
          }
        });
        RefreshEdge();
      };
      vessel.appendChild(outputColumn);
      // 添加元素到 DOM
    function CreatInputs(input,index,IdTemp)
    {
      const inputContainer = document.createElement('div');
      inputContainer.className = 'input-container';

      // 创建显示输入名称的输入框
      const inputName = document.createElement('input');
      inputName.value = input.name;
      inputContainer.appendChild(inputName);

      // 创建选择框
      const selectBox = document.createElement('select');
      const optionLink = document.createElement('option');
      optionLink.value = 'link';
      optionLink.text = 'Link';
      const optionLabel = document.createElement('option');
      optionLabel.value = 'Input';
      optionLabel.text = 'Input';
      selectBox.appendChild(optionLink);
      selectBox.appendChild(optionLabel);
      inputContainer.appendChild(selectBox);

      function RefreshOutput() {
        // 确保outputColumn是已定义的，并且开始清理操作
        if (outputColumn) {
            // 获取所有子元素
            let children = outputColumn.children;
            // 从后往前遍历子元素，以便安全删除元素
            for (let i = children.length - 1; i >= 0; i--) {
                // 假设我们用className来识别是否是addNode1
                if (children[i].className !== 'column-AddNode' && children[i].className !== 'column-label'&& child.className!=='column-SubNode') {
                    outputColumn.removeChild(children[i]); // 删除不是addNode1的元素
                }
            }
        }

        // 这里添加Outputs中的addNode1元素，或其他处理逻辑
        Outputs.forEach((output, index) => {
            // 检查是否是我们需要添加的特定节点addNode1
              CreatOutputs(output, index, output.Id);
        });
    }


    // 假设Outputs是全局变量，如果不是，需要确保它在这个函数中是可访问的
      if(input.Isnecessary==false)
      {
        const SubNode = document.createElement('div');
        SubNode.className = 'column-SubNode'; // 使用之前定义的样式类
        SubNode.style.left = '250px'; // 设置与标签之间的间距
        inputContainer.appendChild(SubNode);
        SubNode.onmousedown = function() {//删除这个矛点
          let data=graph.save();
          data.nodes.forEach((node) => {
            if(node.id == id)
            {
              //通过IdTemp删除这个矛点
              node.Inputs.forEach((input,index) => {
                  if(input.Id == IdTemp)
                  {
                    node.Inputs.splice(index,1);
                    RefreshOutput();
                  }
                }
              );
              const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
              node.anchorPoints = node.Inputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.05, anchorHeight / maxHeight]
                }).concat(node.Outputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.95, anchorHeight / maxHeight]
                })).concat([[0, 0]]);
              ChangeDatas(data);
              //移除inputContainer
              inputContainer.parentNode.removeChild(inputContainer);
            }
          });
          RefreshEdge();
        }
      }
      let labelTextarea = document.createElement('textarea'); // 在外部声明变量以便在不同的作用域中访问
      labelTextarea.className = 'input-textarea';
      if(input.IsLabel==true)
      {
        selectBox.value = 'Input';
        handleChange('Input');
      }
      // 处理选择框变化
      
      function handleChange(value) {
        console.log('value测试',value);
        let pathButton = null; // 在函数内部初始化为 null
        // 如果之前添加了文本区域且现在选择是“Link”，则移除文本区域
        let data = graph.save();
        data.edges.forEach(edge => {
            if (edge.target == id && edge.targetAnchor == index) {
                const item = graph.findById(edge.id);
                const targetNode = graph.findById(edge.target);
                const targetAnchor = targetNode.getContainer().find(ele => ele.get('anchorPointIdx') === anchorIndex);
                targetAnchor.set('links', targetAnchor.get('links') + 1);
                ChangeLink(targetAnchor);
                graph.remove(item);
            }
        });
    
        if (labelTextarea && value === 'link') {
            inputContainer.removeChild(labelTextarea);
            labelTextarea = null; // 确保引用被清除
            ChangeAnchorValue(id, '', 'link', input.Id);
            
            if (pathButton && inputContainer.contains(pathButton)) {
                inputContainer.removeChild(pathButton);
                pathButton = null; // 确保 pathButton 被正确清除
            }
        } else if (value === 'Input') {
            // 如果当前选择是“Input”，则添加文本区域
            console.log('index测试',index);
            if(index!=1)
            {
              
              labelTextarea = document.createElement('textarea');
              labelTextarea.style.width = '550px'; // 设置固定宽度
              labelTextarea.style.height = '20px'; // 初始高度
              labelTextarea.style.overflow = 'hidden'; // 防止滚动条出现
              labelTextarea.style.verticalAlign = 'top'; // 输入行字符居上
              labelTextarea.style.lineHeight = '20px'; // 设置行高以匹配初始高度
              labelTextarea.style.resize = 'vertical';
              labelTextarea.addEventListener('input', function () {
                // 重置高度以计算新的高度
                this.style.height = 'auto';
                // 设置新的高度
                this.style.height = `${this.scrollHeight}px`;
                let isOk = true; // 假定输入有效
                if (input.Kind == 'Num') {
                    if (labelTextarea.value.match(/^[0-9]+$/)) {
                        isOk = true; // 如果是数字，将 isOk 设置为 true
                    } else {
                        // 如果不符合条件，则弹出提示
                        isOk = false;
                        alert("类型不符，您应该输入数字！");
                    }
                }
                if (labelTextarea.value.trim() === '') {
                    isOk = false; // 如果输入为空，则将 isOk 设置为 false
                    alert("输入不能为空！");
                }
    
                if (isOk) {
                  if (index == 0) {
                      let pathButton = inputContainer.querySelector('button'); 
                      pathButton.innerHTML = 'Select Path <span class="circle-loader"></span>';
                      let filePath = labelTextarea.value;
              
                      fetch('/read_DataBase', {
                          method: 'POST',
                          headers: {
                              'Content-Type': 'application/json'
                          },
                          body: JSON.stringify({ 'file_path': filePath })
                      })
                      .then(response => response.json())
                      .then(data => {
                          if (data.status === 'success') {
                              pathButton.innerHTML = 'Select Path <span style="color: green;">(Load Success)</span>';
                              let dataTemp=graph.save();
                              dataTemp.nodes.forEach((node) => {
                                if(node.id == id)
                                {
                                  node.TempOutPuts= data.data;
                                }
                              });
                              ChangeDatas(dataTemp);
                              console.log('Data:', dataTemp);
                              
                          } else {
                              console.error('Error:', data.message,data);
                              pathButton.innerHTML = 'Select Path <span style="color: red;">(Load Fail)</span>';
                          }
                      })
                      .catch(error => {
                          console.error('Error:', error,data);
                          pathButton.innerHTML = 'Select Path <span style="color: red;">(Load Fail)</span>';
                      });
                  }
                  ChangeAnchorValue(id, labelTextarea.value, 'Input', input.Id); // 假定 id 和 ChangeNodeLabel 已定义
              }
              
              });
              //触发labelTextarea.addEventListener('input', function () {
                          
              if (input.Kind == 'Num')
                  labelTextarea.value = input.Num;
              else if (input.Kind.includes('String'))
                  labelTextarea.value = input.Context;
              if(input.Context!=null)
              {
                setTimeout(() => {
                  labelTextarea.dispatchEvent(new Event('input'));
                }, 100);     
              }
            }
            else
            {
              labelTextarea = document.createElement('Select');
              labelTextarea.style.width = '100px'; // 设置固定宽度
              labelTextarea.style.height = '20px'; // 初始高度
              labelTextarea.style.overflow = 'hidden'; // 防止滚动条出现
              labelTextarea.style.verticalAlign = 'top'; // 输入行字符居上
              labelTextarea.style.lineHeight = '20px'; // 设置行高以匹配初始高度
              labelTextarea.style.resize = 'vertical';
              let database = graph.save();
              for(let i=0;i<database.nodes.length;i++)
              {
                if(database.nodes[i].id == id)
                {
                  const TempOutPuts = database.nodes[i].TempOutPuts;
                  Object.keys(TempOutPuts).forEach((key, index) => {
                    const option = document.createElement('option');
                    // TempOutPut对象的属性名称
                    option.value = key;
                    option.text = key;
                    labelTextarea.appendChild(option);
                    });
                }
              }
              labelTextarea.addEventListener('click', function () {
                let database = graph.save();
                for(let i=0;i<database.nodes.length;i++)
                {
                  if(database.nodes[i].id == id)
                  {
                    //清除labelTextarea
                    let isDifferent = false;
                    const TempOutPuts1 = database.nodes[i].TempOutPuts;
                    for (let j = 1; j < labelTextarea.options.length; j++) {
                      // 获取当前选项的值
                      let currentValue = labelTextarea.options[j].value;
                      isDifferent = true; // 默认假设不同
                    
                      // 遍历 TempOutPuts 的所有键
                      for (let key of Object.keys(TempOutPuts1)) {
                        if (currentValue === key) {
                          isDifferent = false; // 找到匹配的键
                          break; // 找到后退出循环
                        }
                      }
                      // 这里可以根据 isDifferent 的值做进一步的处理
                    }
                    if(labelTextarea.options.length!=Object.keys(TempOutPuts1).length+1)
                    {
                      isDifferent = true;
                    }
                    if(isDifferent ==true)
                    {
                      while (labelTextarea.firstChild) {
                        labelTextarea.removeChild(labelTextarea.firstChild);
                      }
                    }
                    
                    const TempOutPuts = database.nodes[i].TempOutPuts;
                    Object.keys(TempOutPuts).forEach((key, index) => {
                      const option = document.createElement('option');
                      // TempOutPut对象的属性名称
                      option.value = key;
                      option.text = key;
                      labelTextarea.appendChild(option);
                      });
                  }
                }
                labelTextarea.value = input.Context;
              });
              labelTextarea.addEventListener('change', function () {
                ChangeAnchorValue(id, labelTextarea.value, 'Input', input.Id);
              });
              if(input.Context!=null)
                labelTextarea.value = input.Context;
            }
            //
            let uniqueClass = `unique-textarea-${id}-${input.Id}`; // 使用 input.Id 生成唯一的类名
            
            if (input.Kind == 'String_FilePath') {
                // 创建路径按钮
                // 检查是否已经存在名为 "Select Path" 的按钮，避免重复创建
                let existingPathButton = inputContainer.querySelector('button'); // 假设 inputContainer 中只会有一个按钮

                // 如果不存在按钮，则创建新的
                if (!existingPathButton) {
                    let pathButton = document.createElement('button'); // 创建按钮
                    pathButton.textContent = 'Select Path'; // 设置按钮文本

                    // 文件选择逻辑
                    pathButton.addEventListener('click', function () {
                        CreatFilePath(input.Id, id);
                    });

                    // 将按钮添加到 inputContainer 中
                    inputContainer.appendChild(pathButton);
                } else {
                    console.log('按钮已经存在');
                }

            }
            
            labelTextarea.className = uniqueClass;
            labelTextarea.id = uniqueClass;
            labelTextarea.classList.add(uniqueClass); // 为文本区域添加唯一类名
            
            
    
            inputContainer.appendChild(labelTextarea);
        }
      }
    
      selectBox.addEventListener('change', function() {
        handleChange(this.value);
      });
      // 为输入框添加 blur 监听器
      inputName.addEventListener('input', function() {
          ChangeAnchorLabel(id, inputName.value, index,input.Id,true); // 假定 id 和 ChangeNodeLabel 已定义
      });
      RefreshEdge();
      inputColumn.appendChild(inputContainer);
    }
    function CreatOutputs(output, index,IdTemp) {
      const outputContainer = document.createElement('div');
      outputContainer.className = 'output-container';
      outputContainer.style.display = 'flex';
      outputContainer.style.alignItems = 'flex-start'; // 内容顶部对齐
      outputContainer.style.flexWrap = 'wrap'; // 允许子元素换行
      outputContainer.style['margin-bottom'] = '10px'; // 增加行间距，这里的值可以根
      // Create an input box to display the output name
      const outputName = document.createElement('input');
      outputName.value = output.name;
      outputName.style.width = '100px'; // 设置固定宽度
      outputName.style.marginBottom = '5px'; // 增加10px的下边距，增加行距
      outputContainer.appendChild(outputName);
      const newLineDiv = document.createElement('div');
      newLineDiv.style.width = '5%'; // 设置宽度为100%
      newLineDiv.style.height = '0'; // 高度设置为0，使其不影响视觉效果
      outputContainer.appendChild(newLineDiv);
      // Create type selection box
      const Label1 = document.createElement('label');
      Label1.textContent = '组'; // 'Description' in Chinese
      Label1.style.flex = '0 0 auto'; // 不允许标签伸缩，保持内容大小
      //字体颜色
      Label1.style.color = '#FFFFFF'; // 设置字体颜色以突出显示
      outputContainer.appendChild(Label1);
      const Select1 = document.createElement('select');
      Select1.style.width = '100px'; // 设置固定宽度
      
      outputContainer.appendChild(Select1);
      let database = graph.save();
      let TempOutPuts;
      const addedKeys = new Set();
      for(let i=0;i<database.nodes.length;i++)
      {
        if(database.nodes[i].id == id)
        {
          TempOutPuts = database.nodes[i].TempOutPuts;
        }
      }
      if(TempOutPuts[Inputs[1].Context]!=null || TempOutPuts[Inputs[1].Context].length!=0)
      {
          TempOutPuts[Inputs[1].Context].forEach(item => {
          if (Array.isArray(item)) {
            item.forEach(subItem => populateSelectBoxFromObject(addedKeys,subItem,"",Select1));
          } else {
            populateSelectBoxFromObject(addedKeys,item,"",Select1);
          }
          let data = graph.save();
          data.nodes.forEach((node) => {
            if (node.id == id) {
              node.Outputs.forEach((output,index) => {
                if (output.Id == IdTemp) {
                  if(output.selectBox4!=null)
                    Select1.value = output.selectBox4;
                      }
                    });
                  }
              })
          
        });
      }
      
      const option = document.createElement('option');
      option.value = 'All';
      option.text = 'All';
      Select1.appendChild(option);
      Object.keys(TempOutPuts).forEach((key, index) => {
      const option = document.createElement('option');
      // TempOutPut对象的属性名称
      option.value = key;
      option.text = key;
      Select1.appendChild(option);
      });
      let TempOutput=SearchOutput(id,IdTemp);
      if(TempOutput.selectBox1!=null)
      {
        Select1.value = TempOutput.selectBox1;
      }
      Select1.addEventListener('change', function() {
        let data = graph.save();
        //清除outputContainer除Select1与Label1以外的所有的子元素
        let child = outputContainer.lastElementChild;
        while (child) {
            // 在进入下一个循环前保存上一个元素
            const prev = child.previousElementSibling;

            // 检查当前元素是否不是 Select1 和 Label1
            if (child !== Select1  && child !== outputName && child !== newLineDiv &&child !==Label1 && child.className!=='column-SubNode') {
                outputContainer.removeChild(child);
            }

            // 更新 child 为之前的元素
            child = prev;
        }
        data.nodes.forEach((node) => {
          if (node.id == id) {
            node.Outputs.forEach((output,index) => {
              if (output.Id == IdTemp) {
                output.selectBox1 = this.value;
                //output.selectBox5 = null;
                output.selectKind = null;
              }
            }
            );
          }
        }
        );
        ChangeDatas(data);
      });
      //触发Select1.addEventListener('change'函数
      setTimeout(function() {
        Select1.dispatchEvent(new Event('change'));
      }, 1000);
      Select1.dispatchEvent(new Event('change'));
      
      Select1.addEventListener('click', function() {
        //清除所有的option
        // 判断 Select1.options 中的 value 是否与 TempOutPuts 中的 key 相同（不考虑顺序），如果不相同，则 isDifferent=true
        let isDifferent = false;
        let nodes = graph.save().nodes;
        let Tempnode=nodes.filter(node => node.id == id)
        let TempOutPuts=Tempnode[0].TempOutPuts;
        const optionsLength = Select1.options.length;
        const tempKeys = Object.keys(TempOutPuts);
        const tempLength = tempKeys.length;
        // 如果数量不一致，直接标记为不同
        if (optionsLength !== tempLength+1) {
          isDifferent = true;
        } else {
          // 如果数量一致，检查两个集合中的值是否相同（不考虑顺序）
          const optionValues = Array.from(Select1.options).map(option => option.value);

          // 对两个数组进行排序后比较
          optionValues.sort();
          tempKeys.sort();

          for (let index = 0; index < optionsLength; index++) {
            if (optionValues[index] !== tempKeys[index]) {
              isDifferent = true;
              break;
            }
          }
        }

        // 结果在 isDifferent 中
        if(isDifferent==true)
        {
          //清空Select1
          Select1.innerHTML = "";
          let nodes = graph.save().nodes;
          let Tempnode=nodes.filter(node => node.id == id)
          let TempOutPuts=Tempnode[0].TempOutPuts;
          const option = document.createElement('option');
          option.value = 'All';
          option.text = 'All';
          Select1.appendChild(option);
          const addedKeys = new Set();
          TempOutPuts[Inputs[1].Context].forEach(item => {
            if (Array.isArray(item)) {
              item.forEach(subItem => populateSelectBoxFromObject(addedKeys,subItem,"",Select1));
            } else {
              populateSelectBoxFromObject(addedKeys,item,"",Select1);
            }
            let data = graph.save();
            data.nodes.forEach((node) => {
              if (node.id == id) {
                node.Outputs.forEach((output,index) => {
                  if (output.Id == IdTemp) {
                    if(output.selectBox4!=null)
                      Select1.value = output.selectBox4;
                        }
                      });
                    }
                })
            
          });
          Select1.value = TempOutput.selectBox1;
        }
        
      });
      creatSubNode();
      function creatSubNode()
      {
        let IsBreak=false;
        let data=graph.save();
        data.nodes.forEach((node) => {
          if(node.id == id)
          {
            //通过IdTemp删除这个矛点
            node.Outputs.forEach((output,index) => {
                if(output.Id == IdTemp && output.Isnecessary==true)
                {
                  //跳出creatSubNode函数
                  console.log("IsBreak",IdTemp);
                  IsBreak=true;
                  return;
                }
              });
          }
        });
        if(IsBreak)
          return;
        const SubNode = document.createElement('div');
        SubNode.className = 'column-SubNode'; // 使用之前定义的样式类
        SubNode.style.left = '112px'; // 设置与 Description 之间的间距
        outputContainer.appendChild(SubNode);
        SubNode.onmousedown = function() {//删除这个矛点
          let data=graph.save();
          data.nodes.forEach((node) => {
            if(node.id == id)
            {
              //通过IdTemp删除这个矛点
              node.Outputs.forEach((output,index) => {
                  if(output.Id == IdTemp)
                  {
                    node.Outputs.splice(index,1);
                  }
                }
              );
              const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
              node.anchorPoints = node.Inputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.05, anchorHeight / maxHeight]
                }).concat(node.Outputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.95, anchorHeight / maxHeight]
                })).concat([[0, 0]]);
              ChangeDatas(data);
              //移除outputContainer
              outputContainer.parentNode.removeChild(outputContainer);
            }
          });
          RefreshEdge();
        }
      }
      // Add description label


      outputColumn.appendChild(outputContainer);
    }
      Inputs.forEach((input, index) => {
        CreatInputs(input,index,input.Id);
      });
      Outputs.forEach((output, index) => {
          CreatOutputs(output,index,output.Id);
      });
    }
    if(NodeKind=='DataBase')
    {
      const inputColumn = document.createElement('div');
      inputColumn.className = 'column';
      const inputLabel = document.createElement('div');
      inputLabel.textContent = 'Input'; // 设置文本
      inputLabel.className = 'column-label'; // 设置样式类
      inputColumn.appendChild(inputLabel);
      const addNode = document.createElement('div');
      addNode.className = 'column-AddNode'; // 使用之前定义的样式类
      vessel.appendChild(inputColumn);
      // 调整textarea高度以适应内容

      // 输入框空格键增长逻辑
      let IdTemp='';
      addNode.onmousedown = function() {
          let data=graph.save();
          data.nodes.forEach((node) => {
            if(node.id == id)
            {
                IdTemp='Input' + (node.Inputs.length + 1).toString()+Date.now();
                let TempName = 'Input' + (node.Inputs.length + 1).toString();
                let counter = 1; // 新增一个计数器
                // 检查是否重名，如果重名则+1继续检查
                while (node.Inputs.some(input => input.name === TempName)) {
                    TempName = 'Input' + (node.Inputs.length + 1 + counter).toString(); // 使用计数器调整名称
                    counter++; // 每次循环递增计数器
                }
                node.Inputs.push({
                  'Num': null,
                  'Kind': 'String',
                  'Id': IdTemp,
                  'Context': null,
                  'Isnecessary': false,
                  'name': TempName,
                  'Link': 0,
                  'IsLabel': false,
              });
              const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
              node.anchorPoints = node.Inputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.05, anchorHeight / maxHeight]
                }).concat(node.Outputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.95, anchorHeight / maxHeight]
                })).concat([[0, 0]]);
              CreatInputs(node.Inputs[node.Inputs.length - 1],node.Inputs.length - 1,IdTemp);
              ChangeDatas(data);
            }
          });

          RefreshEdge();

        };
      //等比例扩大addNode

      // 确定插入位置并将AddNode插入到inputColumn中
      const nextElement = inputLabel.nextSibling; // 获取inputLabel之后的元素
      if (nextElement) {
          // 如果inputLabel后面有其他元素，则在这个元素之前插入addNode
          inputColumn.insertBefore(addNode, nextElement);
      } else {
          // 如果inputLabel是最后一个元素或inputColumn没有其他子元素，则直接追加
          inputColumn.appendChild(addNode);
      }
    const outputColumn = document.createElement('div');
    outputColumn.className = 'column';
    const addNode1 = document.createElement('div');
    addNode1.className = 'column-AddNode'; // 使用之前定义的样式类
    addNode1.style.left = '60px'; // 设置左边距
    outputColumn.appendChild(addNode1);
    const outputLabel = document.createElement('div');
    outputLabel.textContent = 'Output'; // 设置文本
    outputLabel.className = 'column-label'; // 设置样式类
    outputColumn.appendChild(outputLabel);
    // 将输入和输出列添加到节点容器中
    addNode1.onmousedown = function() {
      let data=graph.save();
      data.nodes.forEach((node) => {
        if(node.id == id)
        {
          IdTemp='Output' + (node.Outputs.length + 1).toString()+Date.now();
          let TempName = 'Output' + (node.Outputs.length + 1).toString();
          let counter = 1; // 新增一个计数器
          // 检查是否重名，如果重名则+1继续检查
          while (node.Outputs.some(output => output.name === TempName)) {
              TempName = 'Output' + (node.Outputs.length + 1 + counter).toString(); // 使用计数器调整名称
              counter++; // 每次循环递增计数器
          }
          node.Outputs.push({
            'Num': 0,
            'Kind': 'String',
            'Id': IdTemp,
            'Context': '',
            'Boolean': false,
            'Isnecessary': false,
            'name': TempName,
            'Link': 0,
            'IsLabel': false,
        });
        const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
        node.anchorPoints = node.Inputs.map((node, index) => {
            const anchorHeight = 60 + index * 20;
            return [0.05, anchorHeight / maxHeight]
          }).concat(node.Outputs.map((node, index) => {
            const anchorHeight = 60 + index * 20;
            return [0.95, anchorHeight / maxHeight]
          })).concat([[0, 0]]);
        CreatOutputs(node.Outputs[node.Outputs.length - 1],node.Outputs.length - 1,IdTemp);
        ChangeDatas(data);
        }
      });

      RefreshEdge();
    };
    vessel.appendChild(outputColumn);
    // 添加元素到 DOM
    function CreatInputs(input,index,IdTemp)
    {
      const inputContainer = document.createElement('div');
      inputContainer.className = 'input-container';

      // 创建显示输入名称的输入框
      const inputName = document.createElement('input');
      inputName.value = input.name;
      inputContainer.appendChild(inputName);

      // 创建选择框
      const selectBox = document.createElement('select');
      const optionLink = document.createElement('option');
      optionLink.value = 'link';
      optionLink.text = 'Link';
      const optionLabel = document.createElement('option');
      optionLabel.value = 'Input';
      optionLabel.text = 'Input';
      selectBox.appendChild(optionLink);
      selectBox.appendChild(optionLabel);
      inputContainer.appendChild(selectBox);

      function RefreshOutput() {
        // 确保outputColumn是已定义的，并且开始清理操作
        if (outputColumn) {
            // 获取所有子元素
            let children = outputColumn.children;
            // 从后往前遍历子元素，以便安全删除元素
            for (let i = children.length - 1; i >= 0; i--) {
                // 假设我们用className来识别是否是addNode1
                if (children[i].className !== 'column-AddNode' && children[i].className !== 'column-label'&& child.className!=='column-SubNode') {
                    outputColumn.removeChild(children[i]); // 删除不是addNode1的元素
                }
            }
        }

        // 这里添加Outputs中的addNode1元素，或其他处理逻辑
        Outputs.forEach((output, index) => {
            // 检查是否是我们需要添加的特定节点addNode1
              CreatOutputs(output, index, output.Id);
        });
    }


    // 假设Outputs是全局变量，如果不是，需要确保它在这个函数中是可访问的
      if(input.Isnecessary==false)
      {
        const SubNode = document.createElement('div');
        SubNode.className = 'column-SubNode'; // 使用之前定义的样式类
        SubNode.style.left = '250px'; // 设置与标签之间的间距
        inputContainer.appendChild(SubNode);
        SubNode.onmousedown = function() {//删除这个矛点
          let data=graph.save();
          data.nodes.forEach((node) => {
            if(node.id == id)
            {
              //通过IdTemp删除这个矛点
              node.Inputs.forEach((input,index) => {
                  if(input.Id == IdTemp)
                  {
                    node.Inputs.splice(index,1);
                    RefreshOutput();
                  }
                }
              );
              const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
              node.anchorPoints = node.Inputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.05, anchorHeight / maxHeight]
                }).concat(node.Outputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.95, anchorHeight / maxHeight]
                })).concat([[0, 0]]);
              ChangeDatas(data);
              //移除inputContainer
              inputContainer.parentNode.removeChild(inputContainer);
            }
          });
          RefreshEdge();
        }
      }
      let labelTextarea = document.createElement('textarea'); // 在外部声明变量以便在不同的作用域中访问
      labelTextarea.className = 'input-textarea';
      if(input.IsLabel==true)
      {
        selectBox.value = 'Input';
        handleChange('Input');
      }
      // 处理选择框变化
      
      function handleChange(value) {
        let pathButton = null; // 在函数内部初始化为 null
        // 如果之前添加了文本区域且现在选择是“Link”，则移除文本区域
        let data = graph.save();
        data.edges.forEach(edge => {
            if (edge.target == id && edge.targetAnchor == index) {
                const item = graph.findById(edge.id);
                const targetNode = graph.findById(edge.target);
                const targetAnchor = targetNode.getContainer().find(ele => ele.get('anchorPointIdx') === anchorIndex);
                targetAnchor.set('links', targetAnchor.get('links') + 1);
                ChangeLink(targetAnchor);
                graph.remove(item);
            }
        });
    
        if (labelTextarea && value === 'link') {
            inputContainer.removeChild(labelTextarea);
            labelTextarea = null; // 确保引用被清除
            ChangeAnchorValue(id, '', 'link', input.Id);
            
            if (pathButton && inputContainer.contains(pathButton)) {
                inputContainer.removeChild(pathButton);
                pathButton = null; // 确保 pathButton 被正确清除
            }
        } else if (value === 'Input') {
            // 如果当前选择是“Input”，则添加文本区域
            labelTextarea = document.createElement('textarea');
            labelTextarea.className = 'input-textarea';
            if (input.Kind == 'Num')
                labelTextarea.value = input.Num;
            else if (input.Kind.includes('String'))
                labelTextarea.value = input.Context;
            //
            let uniqueClass = `unique-textarea-${id}-${input.Id}`; // 使用 input.Id 生成唯一的类名
            
            if (input.Kind == 'String_FilePath') {
                // 创建路径按钮
                // 检查是否已经存在名为 "Select Path" 的按钮，避免重复创建
                let existingPathButton = inputContainer.querySelector('button'); // 假设 inputContainer 中只会有一个按钮

                // 如果不存在按钮，则创建新的
                if (!existingPathButton) {
                    let pathButton = document.createElement('button'); // 创建按钮
                    pathButton.textContent = 'Select Path'; // 设置按钮文本

                    // 文件选择逻辑
                    pathButton.addEventListener('click', function () {
                        CreatFilePath(input.Id, id);
                    });

                    // 将按钮添加到 inputContainer 中
                    inputContainer.appendChild(pathButton);
                } else {
                    console.log('按钮已经存在');
                }

            }
            
            labelTextarea.className = uniqueClass;
            labelTextarea.id = uniqueClass;
            labelTextarea.classList.add(uniqueClass); // 为文本区域添加唯一类名
    
            labelTextarea.addEventListener('input', function () {
                let isOk = true; // 假定输入有效
                if (input.Kind == 'Num') {
                    if (labelTextarea.value.match(/^[0-9]+$/)) {
                        isOk = true; // 如果是数字，将 isOk 设置为 true
                    } else {
                        // 如果不符合条件，则弹出提示
                        isOk = false;
                        alert("类型不符，您应该输入数字！");
                    }
                }
                if (labelTextarea.value.trim() === '') {
                    isOk = false; // 如果输入为空，则将 isOk 设置为 false
                    alert("输入不能为空！");
                }
    
                if (isOk) {
                  if (index == 0) {
                      let pathButton = inputContainer.querySelector('button'); 
                      pathButton.innerHTML = 'Select Path <span class="circle-loader"></span>';
                      let filePath = labelTextarea.value;
              
                      fetch('/read_DataBase', {
                          method: 'POST',
                          headers: {
                              'Content-Type': 'application/json'
                          },
                          body: JSON.stringify({ 'file_path': filePath })
                      })
                      .then(response => response.json())
                      .then(data => {
                          if (data.status === 'success') {
                              pathButton.innerHTML = 'Select Path <span style="color: green;">(Load Success)</span>';
                              let dataTemp=graph.save();
                              dataTemp.nodes.forEach((node) => {
                                if(node.id == id)
                                {
                                  console.log(data);
                                  node.TempOutPuts= data.data;
                                  node.TempColumns= data.columns;
                                }
                              });
                              ChangeDatas(dataTemp);
                              console.log('Data:', dataTemp);
                              
                          } else {
                              console.error('Error:', data.message,data);
                              pathButton.innerHTML = 'Select Path <span style="color: red;">(Load Fail)</span>';
                          }
                      })
                      .catch(error => {
                          console.error('Error:', error,data);
                          pathButton.innerHTML = 'Select Path <span style="color: red;">(Load Fail)</span>';
                      });
                  }
                  ChangeAnchorValue(id, labelTextarea.value, 'Input', input.Id); // 假定 id 和 ChangeNodeLabel 已定义
              }
              
            });
            //触发labelTextarea.addEventListener('input', function () {
            if(input.Context!=null)
            labelTextarea.dispatchEvent(new Event('input'));
            labelTextarea.addEventListener('input', function () {
                // 重置高度以计算新的高度
                this.style.height = 'auto';
                // 设置新的高度
                this.style.height = `${this.scrollHeight}px`;
            });
    
            inputContainer.appendChild(labelTextarea);
        }
      }
    
      selectBox.addEventListener('change', function() {
        handleChange(this.value);
      });
      // 为输入框添加 blur 监听器
      inputName.addEventListener('input', function() {
          ChangeAnchorLabel(id, inputName.value, index,input.Id,true); // 假定 id 和 ChangeNodeLabel 已定义
      });
      RefreshEdge();
      inputColumn.appendChild(inputContainer);
    }
    function CreatOutputs(output, index,IdTemp) {

      function CreatLable(Select3,SelectLabel) {
        //#region快捷输入栏
        let TempOutPuts;
        let Tempoutput=SearchOutput(id,IdTemp);
        let data = graph.save();
        data.nodes.forEach((node) => {
          if(node.id == id)
            TempOutPuts=node.TempOutPuts;
        });

        const dropdown = document.createElement('ul');
        dropdown.style.position = 'absolute';
        dropdown.style.display = 'none'; // 初始状态隐藏
        dropdown.style.listStyle = 'none';
        dropdown.style.margin = '0';
        // 设置下拉框的最小和最大宽度，防止过大或过小
        dropdown.style.minWidth = '100px'; // 设置一个合理的最小宽度
        dropdown.style.maxWidth = '300px'; // 限制最大宽度，避免过大
        dropdown.style.width = 'auto'; // 根据内容自动调整宽度

        dropdown.style.padding = '0';
        dropdown.style.border = '1px solid #ccc';
        dropdown.style.backgroundColor = '#fff';
        document.body.appendChild(dropdown);


        let currentIndex = -1; // 用于跟踪当前选中的快捷栏项
        let itemsList = [];    // 用于存储当前显示的候选项

        // 函数：渲染下拉列表
        function renderDropdown(items) {
          dropdown.innerHTML = ''; // 清空现有的内容
          let maxWidth = 0; // 用于存储最大宽度

          items.forEach((item, index) => {
            const li = document.createElement('li');
            li.textContent = item;
            li.style.padding = '8px';
            li.style.cursor = 'pointer';

            // 计算当前项的宽度
            document.body.appendChild(li);
            const itemWidth = li.offsetWidth;
            document.body.removeChild(li);

            // 更新最大宽度
            if (itemWidth > maxWidth) {
              maxWidth = itemWidth;
            }

            // 当鼠标悬浮时，高亮该选项
            li.addEventListener('mouseenter', function() {
              currentIndex = index;
              highlightItem();
            });

            // 当点击该选项时，确认选择
            li.addEventListener('click', function() {
              confirmSelection();
            });

            dropdown.appendChild(li);
          });

          // 设置下拉框宽度为最大内容宽度+16px用于内边距
          dropdown.style.width = `${maxWidth + 16}px`;

          // 如果有内容，显示下拉框；否则隐藏
          dropdown.style.display = items.length > 0 ? 'block' : 'none';
        }
        // 函数：高亮当前选中的项
        function highlightItem() {
          Array.from(dropdown.children).forEach((li, index) => {
            if (index === currentIndex) {
              li.style.backgroundColor = '#ddd'; // 高亮当前项
            } else {
              li.style.backgroundColor = '#fff'; // 清除高亮
            }
          });
        }

        // 函数：确认选中的项
        function confirmSelection() {
          if (currentIndex >= 0 && currentIndex < itemsList.length) {
            Select3.value = itemsList[currentIndex];
            dropdown.style.display = 'none'; // 选择后隐藏下拉框
            ChangeAnchorLabel(id, Select3.value, SelectLabel, IdTemp, false);
          }
        }

        // 函数：生成候选项（去重）
        function generateItems(inputValue) {
          const uniqueItems = new Set(); // 使用 Set 去重
                  // 遍历Inputs从1开始的所有数组
          for (let i = 1; i < Inputs.length; i++) {
            const inputName = `{{${Inputs[i].name}}}`;
            uniqueItems.add(inputName);
          }
          console.log(Tempoutput)
          if(Tempoutput.selectBox5==null||(Tempoutput.selectBox5.includes('Json输入')==false && Tempoutput.selectBox5.includes('修改')==false))
          {
            if(TempOutPuts[Tempoutput.selectBox1]!=undefined)
            {
              TempOutPuts[Tempoutput.selectBox1].forEach(item => {
                if (Tempoutput.selectBox2 !== 'All') {
                  const outputValue = item[Tempoutput.selectBox2] ? item[Tempoutput.selectBox2].toString() : ''; // 确保值存在
                  if (outputValue.toLowerCase().includes(inputValue)) {
                    uniqueItems.add(outputValue); // 添加匹配的项
                  }
                } else if (Array.isArray(item)) {
                  // 修复：item 是数组才可以使用 forEach
                  item.forEach(subItem => {
                    const subItemValue = subItem ? subItem.toString() : '';
                    if (subItemValue.toLowerCase().includes(inputValue)) {
                      uniqueItems.add(subItemValue); // 添加匹配的项
                    }
                  });
                }
              });
            }
          }
          return Array.from(uniqueItems); // 返回去重后的数组
        }

        // 输入框事件监听
        Select3.addEventListener('input', function() {
          const inputValue = Select3.value.toLowerCase(); // 获取输入的值
          itemsList = generateItems(inputValue); // 获取去重后的候选项
          ChangeAnchorLabel(id, this.value, SelectLabel, IdTemp, false);
          // 渲染快捷栏
          renderDropdown(itemsList);
        });

        // 处理键盘事件：上下键和回车键
        Select3.addEventListener('keydown', function(e) {
          if (dropdown.style.display === 'block') {
            if (e.key === 'ArrowDown') {
              currentIndex = (currentIndex + 1) % itemsList.length; // 下移
              highlightItem();
              e.preventDefault();
            } else if (e.key === 'ArrowUp') {
              currentIndex = (currentIndex - 1 + itemsList.length) % itemsList.length; // 上移
              highlightItem();
              e.preventDefault();
            } else if (e.key === 'Enter' || e.key === ' ') {
              // 回车键或者空格键确认选择
              confirmSelection();
              e.preventDefault();
            }
          }
        });

        // 当输入框失去焦点时，隐藏快捷栏
        Select3.addEventListener('blur', function() {
          setTimeout(() => { dropdown.style.display = 'none'; }, 200); // 延迟隐藏，保证鼠标点击
        });

        // 设置下拉框位置，随输入框移动
        Select3.addEventListener('focus', function() {
          const rect = Select3.getBoundingClientRect();
          dropdown.style.left = `${rect.left}px`;
          dropdown.style.top = `${rect.bottom}px`;
          dropdown.style.width = `${rect.width}px`;

          // 如果输入框是空的，显示全部选项
          if (Select3.value.trim() === '') {
            itemsList = generateItems(''); // 显示所有项
            renderDropdown(itemsList); // 渲染快捷栏
          }
        });

    //#endregion
}

      const outputContainer = document.createElement('div');
      outputContainer.className = 'output-container';
      outputContainer.style.display = 'flex';
      outputContainer.style.alignItems = 'flex-start'; // 内容顶部对齐
      outputContainer.style.flexWrap = 'wrap'; // 允许子元素换行
      outputContainer.style['margin-bottom'] = '16px'; // 增加行间距，这里的值可以根
      // Create an input box to display the output name
      const outputName = document.createElement('input');
      outputName.value = output.name;
      outputName.style.width = '100px'; // 设置固定宽度
      outputName.style.marginBottom = '5px'; // 增加10px的下边距，增加行距
      outputContainer.appendChild(outputName);

      // 添加一个宽度为100%的透明div来强制换行
      const newLineDiv1 = document.createElement('div');
      newLineDiv1.style.width = '5%'; // 设置宽度为100%
      newLineDiv1.style.height = '0'; // 高度设置为0，使其不影响视觉效果
      outputContainer.appendChild(newLineDiv1);

      
      if(index!=0)
      {
        const Label5 = document.createElement('label');
        Label5.textContent = '类型';
        Label5.style.flex = '0 0 auto';
        Label5.style.color = '#FFFFFF'; // 设置字体颜色以突出显示
        outputContainer.appendChild(Label5);
        const Select5 = document.createElement('select');
        Select5.style.width = '100px';
        outputContainer.appendChild(Select5);
        let nodes = graph.save().nodes;
        let Tempnode=nodes.filter(node => node.id == id)
        let TempOutPuts=Tempnode[0].TempOutPuts;
        const options = ['Json输入', '修改','删除','查询','新增'];
        options.forEach(option => {
          const optionElement = document.createElement('option');
          optionElement.value = option;
          optionElement.textContent = option;
          Select5.appendChild(optionElement);
          
        });
        const newLineDiv = document.createElement('div');
        newLineDiv.style.width = '5%'; // 设置宽度为100%
        newLineDiv.style.height = '0'; // 高度设置为0，使其不影响视觉效果
        outputContainer.appendChild(newLineDiv);
        // Create type selection box
        const Label1 = document.createElement('label');
        Label1.textContent = '组'; // 'Description' in Chinese
        Label1.style.flex = '0 0 auto'; // 不允许标签伸缩，保持内容大小
        //字体颜色
        Label1.style.color = '#FFFFFF'; // 设置字体颜色以突出显示
        outputContainer.appendChild(Label1);
        const Select1 = document.createElement('select');
        Select1.style.width = '100px'; // 设置固定宽度
        
        outputContainer.appendChild(Select1);
        Object.keys(TempOutPuts).forEach((key, index) => {
        const option = document.createElement('option');
        // TempOutPut对象的属性名称
        option.value = key;
        option.text = key;
        Select1.appendChild(option);
        });
        let TempOutput=SearchOutput(id,IdTemp);
        if(TempOutput.selectBox1!=null)
        {
          Select1.value = TempOutput.selectBox1;
        }
        else
        {
          Select1.value = Object.keys(TempOutPuts)[0];
        }
        CreatCondition(Select1.value);
        //触发change事件函数

        Select1.addEventListener('change', function() {
          let data = graph.save();
          //清除outputContainer除Select1与Label1以外的所有的子元素
          let child = outputContainer.lastElementChild;
          while (child) {
              // 在进入下一个循环前保存上一个元素
              const prev = child.previousElementSibling;

              // 检查当前元素是否不是 Select1 和 Label1
              if (child !== Select1  && child !== outputName && child !== newLineDiv && child !== newLineDiv1  &&child !==Label5 &&child !==Select5 &&child !==Label1 && child.className!=='column-SubNode') {
                  outputContainer.removeChild(child);
              }

              // 更新 child 为之前的元素
              child = prev;
          }
          data.nodes.forEach((node) => {
            if (node.id == id) {
              node.Outputs.forEach((output,index) => {
                if (output.Id == IdTemp) {
                  output.selectBox1 = this.value;
                  //output.selectBox5 = null;
                  output.selectKind = null;
                  CreatCondition(this.value);
                }
              }
              );
            }
          }
          );
          ChangeDatas(data);
        });
        //触发Select1.addEventListener('change'函数
        setTimeout(function() {
          Select1.dispatchEvent(new Event('change'));
        }, 1000);
        Select1.dispatchEvent(new Event('change'));
        
        Select1.addEventListener('click', function() {
          //清除所有的option
          // 判断 Select1.options 中的 value 是否与 TempOutPuts 中的 key 相同（不考虑顺序），如果不相同，则 isDifferent=true
          let isDifferent = false;
          let nodes = graph.save().nodes;
          let Tempnode=nodes.filter(node => node.id == id)
          let TempOutPuts=Tempnode[0].TempOutPuts;
          const optionsLength = Select1.options.length;
          const tempKeys = Object.keys(TempOutPuts);
          const tempLength = tempKeys.length;
          // 如果数量不一致，直接标记为不同
          if (optionsLength !== tempLength) {
            isDifferent = true;
          } else {
            // 如果数量一致，检查两个集合中的值是否相同（不考虑顺序）
            const optionValues = Array.from(Select1.options).map(option => option.value);

            // 对两个数组进行排序后比较
            optionValues.sort();
            tempKeys.sort();

            for (let index = 0; index < optionsLength; index++) {
              if (optionValues[index] !== tempKeys[index]) {
                isDifferent = true;
                break;
              }
            }
          }

          // 结果在 isDifferent 中
          if(isDifferent==true)
          {
            //清空Select1
            Select1.innerHTML = "";
            let nodes = graph.save().nodes;
            let Tempnode=nodes.filter(node => node.id == id)
            let TempOutPuts=Tempnode[0].TempOutPuts;
            let TempColumns=Tempnode[0].TempColumns;
            Object.keys(TempOutPuts).forEach((key, index) => {
                const option = document.createElement('option');
                //console.log("key", key);
                // TempOutPut对象的属性名称
                option.value = key;
                option.text = key;
                Select1.appendChild(option);
            });
          }
          
        });
        outputContainer.appendChild(newLineDiv);   
        function InitSelectBox2(value)
            {
             // 将 '/' 进行转义
              let existingLabel = document.querySelector(`#SelectedLabel${output.name}`);
              let outputTemp = SearchOutput(id,IdTemp);
              if (!existingLabel ) {         
               if(outputTemp.selectBox5=='查询' || outputTemp.selectBox5=='修改')
                {
                  const newLineDiv3 = document.createElement('div');
                  newLineDiv3.style.width = '5%';
                  newLineDiv3.style.height = '0';
                  outputContainer.appendChild(newLineDiv3);
                  const Label4 = document.createElement('label');
                  Label4.textContent = '查询类别'; // 标签的文本内容
                  Label4.id = `SelectedLabel${output.name}`; // 保持原始的 id，不对它做修改
                  Label4.style.flex = '0 0 auto'; // 不允许标签伸缩，保持内容大小
                  Label4.style.color = '#FFFFFF'; // 设置字体颜色以突出显示
                  outputContainer.appendChild(Label4);
                  const Select4 = document.createElement('select');
                  Select4.id = `Select4${output.name}`;
                  Select4.style.width = '100px';
                  Select4.value = value;
                  outputContainer.appendChild(Select4);
                  if(outputTemp.selectBox5=='修改')
                  {
                    const newLineDiv4 = document.createElement('div');
                    newLineDiv4.style.width = '5%';
                    newLineDiv4.style.height = '0';
                    outputContainer.appendChild(newLineDiv4);
                    const Label6 = document.createElement('label');
                    Label6.textContent = '修改内容';
                    Label6.id = `SelectedLabel${output.name}`;
                    Label6.style.flex = '0 0 auto';
                    Label6.style.color = '#FFFFFF';
                    outputContainer.appendChild(Label6);
                    const Input6 = document.createElement('input');
                    Input6.type = 'text';
                    Input6.id = `Input6${output.name}`;
                    Input6.style.width = '100px';
                    CreatLable(Input6,"selectBox6");
                    outputContainer.appendChild(Input6);
                    Input6.value=outputTemp.selectBox6;
                  }
                  let OutputTemp = SearchOutput(id,IdTemp);
                  const Table=OutputTemp.selectBox1;
                  //清空Select4中的option
                  while(Select4.options.length>0)
                  {
                    Select4.options.remove(0);
                  }
                  let option = document.createElement('option');
                  option.value = 'All';
                  option.text = 'All';
                  Select4.appendChild(option);
                  const addedKeys = new Set();
                  let nodes = graph.save().nodes;
                  let Tempnode=nodes.filter(node => node.id == id)
                  let TempColumns=Tempnode[0].TempColumns;
                  if(TempColumns[Table]!=undefined)
                  {
                    TempColumns[Table].forEach(item => {
                      if (Array.isArray(item)) {
                        item.forEach(subItem => populateSelectBoxFromObject(addedKeys,subItem,"",Select4));
                      } else {
                        populateSelectBoxFromObject(addedKeys,item,"",Select4);
                      }
                      let data = graph.save();
                      data.nodes.forEach((node) => {
                        if (node.id == id) {
                          node.Outputs.forEach((output,index) => {
                            if (output.Id == IdTemp) {
                              if(output.selectBox4!=null)
                                Select4.value = output.selectBox4;
                                  }
                                });
                              }
                          })
                      
                    });
                  }
                  
                  Select4.addEventListener('change', function() {
                    let data = graph.save();
                    data.nodes.forEach((node) => {
                      if (node.id == id) {
                    node.Outputs.forEach((output,index) => {
                      if (output.Id == IdTemp) {
                        output.selectKind='Str';
                        output.selectBox4=Select4.value;
                        output.selectNum3=Select4.value;
                      }
                    });
                    ChangeDatas(data);
                  }
                    });
                  });
                  Select4.addEventListener('click',function()
                  {
                    let data = graph.save();
                    data.nodes.forEach((node) => {
                      if (node.id == id) {
                      node.Outputs.forEach((output,index) => {

                          if(TempOutPuts[output.selectBox1]!=undefined || TempOutPuts[output.selectBox1]!=null)
                          {

                          }
                          if(output.Id == IdTemp && (node.TempOutPuts[output.selectBox1]!=undefined || node.TempOutPuts[output.selectBox1]!=null))
                            {
                              node.TempOutPuts[output.selectBox1].forEach(item => {
                                if (Array.isArray(TempColumns[Table])) {
                                  TempColumns[Table].forEach(item => {
                                    if (Array.isArray(item)) {
                                      item.forEach(subItem => populateSelectBoxFromObject(addedKeys, subItem, "", Select4));
                                    } else {
                                      populateSelectBoxFromObject(addedKeys, item, "", Select4);
                                    }
                                  });
                                } else {
                                  populateSelectBoxFromObject(addedKeys, TempColumns[Table], "", Select4);
                                }
                                let data = graph.save();
                                data.nodes.forEach((node) => {
                                  if (node.id == id) {
                                    node.Outputs.forEach((output,index) => {
                                      if (output.Id == IdTemp) {
                                        if(output.selectBox4!=null)
                                          Select4.value = output.selectBox4;
                                            }
                                          });
                                        }
                                    })
                                
                              });
                            }
                        });
                      }
                    });
                    
                  });
                }
                  // 如果不存在，创建一个新的label元素
              }
              else {
                  console.log("Label4 already exists, ignoring creation.");
              }
              let data = graph.save();
              data.nodes.forEach((node) => {
                if (node.id == id) {
                  node.Outputs.forEach((output,index) => {
                    if (output.Id == IdTemp) {
                      output.selectKind='Num';
                      output.selectBox2=value;
                      output.selectNum2=value;
                    }
                  });
                  ChangeDatas(data);
                }
              });
            }
        if(output.selectBox5!='null' && output.selectBox5!='')
          {
            if(output.selectBox5=='Json输入')
            {
              //CreatCondition();
            }
            Select5.value=output.selectBox5;
            Select5Function(Select5.value)
          }
        if(output.selectBox5=='null' || output.selectBox5=='')
          {
            Select5.value='查询';
            let data=graph.save();
            data.nodes.forEach(node=>{
              if(node.id == id)
              {
                node.Outputs.forEach((output,index) => {
                  if(output.Id == IdTemp )
                  {
                    //跳出creatSubNode函数
                    output.selectBox4=Select5.value;

                  }
                });
              }
            })
            Select5Function(Select5.value)
          }
        creatSubNode();
        function creatSubNode()
        {
          let IsBreak=false;
          let data=graph.save();
          data.nodes.forEach((node) => {
            if(node.id == id)
            {
              //通过IdTemp删除这个矛点
              node.Outputs.forEach((output,index) => {
                  if(output.Id == IdTemp && output.Isnecessary==true)
                  {
                    //跳出creatSubNode函数
                    console.log("IsBreak",IdTemp);
                    IsBreak=true;
                    return;
                  }
                });
            }
          });
          if(IsBreak)
            return;
          const SubNode = document.createElement('div');
          SubNode.className = 'column-SubNode'; // 使用之前定义的样式类
          SubNode.style.left = '112px'; // 设置与 Description 之间的间距
          outputContainer.appendChild(SubNode);
          SubNode.onmousedown = function() {//删除这个矛点
            let data=graph.save();
            data.nodes.forEach((node) => {
              if(node.id == id)
              {
                //通过IdTemp删除这个矛点
                node.Outputs.forEach((output,index) => {
                    if(output.Id == IdTemp)
                    {
                      node.Outputs.splice(index,1);
                    }
                  }
                );
                const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
                node.anchorPoints = node.Inputs.map((node, index) => {
                    const anchorHeight = 60 + index * 20;
                    return [0.05, anchorHeight / maxHeight]
                  }).concat(node.Outputs.map((node, index) => {
                    const anchorHeight = 60 + index * 20;
                    return [0.95, anchorHeight / maxHeight]
                  })).concat([[0, 0]]);
                ChangeDatas(data);
                //移除outputContainer
                outputContainer.parentNode.removeChild(outputContainer);
              }
            });
            RefreshEdge();
          }
        }
        
        function CreatCondition(Table)
        {
          const Tempdata1=graph.save();
          let TempOutPuts
          let TempColumns
          let NodeNum=-1;
          let Tempoutput=SearchOutput(id,IdTemp);
          Tempdata1.nodes.forEach((node) => {
            if(node.id == id)
            {
              TempColumns=node.TempColumns;
              TempOutPuts=node.TempOutPuts;
              Object.keys(TempOutPuts).forEach((key, index) => {
                if(key == Table)
                  NodeNum=index;
            });
            }
          });
          output.selectNum1=NodeNum;
          const Select3 = document.createElement('input');
          if(Tempoutput.selectBox5==null || Tempoutput.selectBox5.includes('Json输入')==false)
          {
            const Label2 = document.createElement('label');
            Label2.textContent = '条目'; // 'Description' in Chinese
            Label2.style.flex = '0 0 auto'; // 不允许标签伸缩，保持内容大小
            Label2.style.color = '#FFFFFF'; // 设置字体颜色以突出显示
            outputContainer.appendChild(Label2);
            output.selectBox1=Table;
  
            const Select2 = document.createElement('select');
            Select2.style.width = '100px';
            Select2.value = Table;
            const newLineDiv2 = document.createElement('div');
            newLineDiv2.style.width = '5%'; // 设置宽度为100%
            newLineDiv2.style.height = '0'; // 高度设置为0，使其不影响视觉效果
            
            const Label3 = document.createElement('label');
            Label3.textContent = '内容';
            Label3.style.flex = '0 0 auto';
            Label3.style.color = '#FFFFFF';
            
            //创建输入框
            Select3.style.width = '100px';
            Select3.value = Tempoutput.selectBox3;
            CreatLable(Select3,"selectBox3");
            outputContainer.appendChild(Select2);
            outputContainer.appendChild(newLineDiv2);
            outputContainer.appendChild(Label3);
            outputContainer.appendChild(Select3);
            
            // 遍历 TempOutPuts[Table] 中的每个项
            // 存储已添加的键值对，用于排除重复项
            let option = document.createElement('option');
            option.value = 'All';
            option.text = 'All';
            Select2.appendChild(option);
            const addedKeys = new Set();

            if(TempColumns[Table]!==undefined)
            {
              TempColumns[Table].forEach(item => {
                if (Array.isArray(TempColumns[Table])) {
                  TempColumns[Table].forEach(item => {
                    if (Array.isArray(item)) {
                      item.forEach(subItem => populateSelectBoxFromObject(addedKeys, subItem, "", Select2));
                    } else {
                      populateSelectBoxFromObject(addedKeys, item, "", Select2);
                    }
                  });
                } else {
                  populateSelectBoxFromObject(addedKeys, TempColumns[Table], "", Select2);
                }
              });
            }
            
            
            creatSubNode();
            Select2.addEventListener('change', function() {
              InitSelectBox2(Select2.value);
            });
            outputName.addEventListener('input', function() {
              ChangeAnchorLabel(id, outputName.value, index,output.Id,false); // 假定 id 和 ChangeNodeLabel 已定义
            });
            if(output.selectBox2!=null)
            {
              Select2.value = output.selectBox2;
              InitSelectBox2(output.selectBox2);
            }
            else
            {
              Select2.value = 0;
              InitSelectBox2(output.selectBox2);
            }
            
            
          }
          else if(Tempoutput.selectBox5.includes('Json输入'))
          {
            const Label3 = document.createElement('label');
            Label3.textContent = '内容';
            Label3.style.flex = '0 0 auto';
            Label3.style.color = '#FFFFFF';      
            //创建输入框
            Select3.style.width = '100px';
            Select3.value = Tempoutput.selectBox3;
            outputContainer.appendChild(Label3);
            outputContainer.appendChild(Select3);
          }
          //#region快捷输入栏
          const dropdown = document.createElement('ul');
          dropdown.style.position = 'absolute';
          dropdown.style.display = 'none'; // 初始状态隐藏
          dropdown.style.listStyle = 'none';
          dropdown.style.margin = '0';
          // 设置下拉框的最小和最大宽度，防止过大或过小
          dropdown.style.minWidth = '100px'; // 设置一个合理的最小宽度
          dropdown.style.maxWidth = '300px'; // 限制最大宽度，避免过大
          dropdown.style.width = 'auto'; // 根据内容自动调整宽度

          dropdown.style.padding = '0';
          dropdown.style.border = '1px solid #ccc';
          dropdown.style.backgroundColor = '#fff';
          document.body.appendChild(dropdown);


          let currentIndex = -1; // 用于跟踪当前选中的快捷栏项
          let itemsList = [];    // 用于存储当前显示的候选项

          // 函数：渲染下拉列表
          function renderDropdown(items) {
            dropdown.innerHTML = ''; // 清空现有的内容
            let maxWidth = 0; // 用于存储最大宽度

            items.forEach((item, index) => {
              const li = document.createElement('li');
              li.textContent = item;
              li.style.padding = '8px';
              li.style.cursor = 'pointer';

              // 计算当前项的宽度
              document.body.appendChild(li);
              const itemWidth = li.offsetWidth;
              document.body.removeChild(li);

              // 更新最大宽度
              if (itemWidth > maxWidth) {
                maxWidth = itemWidth;
              }

              // 当鼠标悬浮时，高亮该选项
              li.addEventListener('mouseenter', function() {
                currentIndex = index;
                highlightItem();
              });

              // 当点击该选项时，确认选择
              li.addEventListener('click', function() {
                confirmSelection();
              });

              dropdown.appendChild(li);
            });

            // 设置下拉框宽度为最大内容宽度+16px用于内边距
            dropdown.style.width = `${maxWidth + 16}px`;

            // 如果有内容，显示下拉框；否则隐藏
            dropdown.style.display = items.length > 0 ? 'block' : 'none';
          }
          // 函数：高亮当前选中的项
          function highlightItem() {
            Array.from(dropdown.children).forEach((li, index) => {
              if (index === currentIndex) {
                li.style.backgroundColor = '#ddd'; // 高亮当前项
              } else {
                li.style.backgroundColor = '#fff'; // 清除高亮
              }
            });
          }

          // 函数：确认选中的项
          function confirmSelection() {
            if (currentIndex >= 0 && currentIndex < itemsList.length) {
              Select3.value = itemsList[currentIndex];
              dropdown.style.display = 'none'; // 选择后隐藏下拉框
              ChangeAnchorLabel(id, Select3.value, "selectBox3", output.Id, false);
            }
          }

          // 函数：生成候选项（去重）
          function generateItems(inputValue) {
            const uniqueItems = new Set(); // 使用 Set 去重
                    // 遍历Inputs从1开始的所有数组
            for (let i = 1; i < Inputs.length; i++) {
              const inputName = `{{${Inputs[i].name}}}`;
              uniqueItems.add(inputName);
            }
            if(Tempoutput.selectBox5.includes('Json输入')==false)
            {
              if(TempOutPuts[Table]!=undefined)
                {
                  TempOutPuts[Table].forEach(item => {
                    if (output.selectBox2 !== 'All') {
                      const outputValue = item[output.selectBox2] ? item[output.selectBox2].toString() : ''; // 确保值存在
                      if (outputValue.toLowerCase().includes(inputValue)) {
                        uniqueItems.add(outputValue); // 添加匹配的项
                      }
                    } else if (Array.isArray(item)) {
                      // 修复：item 是数组才可以使用 forEach
                      item.forEach(subItem => {
                        const subItemValue = subItem ? subItem.toString() : '';
                        if (subItemValue.toLowerCase().includes(inputValue)) {
                          uniqueItems.add(subItemValue); // 添加匹配的项
                        }
                      });
                    }
                  });
                }
              
            }
            return Array.from(uniqueItems); // 返回去重后的数组
          }

          // 输入框事件监听
          Select3.addEventListener('input', function() {
            const inputValue = Select3.value.toLowerCase(); // 获取输入的值
            itemsList = generateItems(inputValue); // 获取去重后的候选项

            // 渲染快捷栏
            renderDropdown(itemsList);
          });

          // 处理键盘事件：上下键和回车键
          Select3.addEventListener('keydown', function(e) {
            if (dropdown.style.display === 'block') {
              if (e.key === 'ArrowDown') {
                currentIndex = (currentIndex + 1) % itemsList.length; // 下移
                highlightItem();
                e.preventDefault();
              } else if (e.key === 'ArrowUp') {
                currentIndex = (currentIndex - 1 + itemsList.length) % itemsList.length; // 上移
                highlightItem();
                e.preventDefault();
              } else if (e.key === 'Enter' || e.key === ' ') {
                // 回车键或者空格键确认选择
                confirmSelection();
                e.preventDefault();
              }
            }
          });

          // 当输入框失去焦点时，隐藏快捷栏
          Select3.addEventListener('blur', function() {
            setTimeout(() => { dropdown.style.display = 'none'; }, 200); // 延迟隐藏，保证鼠标点击
          });

          // 设置下拉框位置，随输入框移动
          Select3.addEventListener('focus', function() {
            const rect = Select3.getBoundingClientRect();
            dropdown.style.left = `${rect.left}px`;
            dropdown.style.top = `${rect.bottom}px`;
            dropdown.style.width = `${rect.width}px`;

            // 如果输入框是空的，显示全部选项
            if (Select3.value.trim() === '') {
              itemsList = generateItems(''); // 显示所有项
              renderDropdown(itemsList); // 渲染快捷栏
            }
          });

      //#endregion
        }
        Select5.addEventListener('change', function() {
          Select5Function(this.value);
        });
        function Select5Function(value)
        {      
          let data = graph.save();
          //清除outputContainer除Select1与Label1以外的所有的子元素
          let child = outputContainer.lastElementChild;
          while (child) {
              // 在进入下一个循环前保存上一个元素
              const prev = child.previousElementSibling;
              // 检查当前元素是否不是 Select1 和 Label1
              if (child !== outputName && child !== newLineDiv1  &&child !==Label5 &&child !==Select5 && child.className!=='column-SubNode' &&child !== Select1 && child !== Label1&& child !== newLineDiv) {
                  outputContainer.removeChild(child);
              }

              // 更新 child 为之前的元素
              child = prev;
          }
          data.nodes.forEach((node) => {
            if (node.id == id) {
              node.Outputs.forEach((output,index) => {
                if (output.Id == IdTemp) {
                  output.selectBox5 = value;
                  CreatCondition(output.selectBox1)
                }
              }
              );
            }
          }
          );
          ChangeDatas(data);
          
        }
      }
      
      // Add description label


      outputColumn.appendChild(outputContainer);
    }


    // 假设Inputs是已定义的
  Inputs.forEach((input, index) => {
      CreatInputs(input,index,input.Id);
  });
  Outputs.forEach((output, index) => {
      CreatOutputs(output,index,output.Id);
  });
    }
    if(NodeKind.includes('Normal') || (NodeKind.includes('Trigger') && NodeKind!='ArrayTrigger_DataBase'))
    {
      if(InputIsAdd==null || InputIsAdd==false || InputIsAdd=='')
      {
        const inputColumn = document.createElement('div');
        inputColumn.className = 'column';
        const inputLabel = document.createElement('div');
        inputLabel.textContent = 'Input'; // 设置文本
        inputLabel.className = 'column-label'; // 设置样式类
        inputColumn.appendChild(inputLabel);
        vessel.appendChild(inputColumn);
        // 创建输出列并添加标签
        // 添加元素到 DOM

        // 假设Inputs是已定义的
        Inputs.forEach((input, index) => {
          //不包含'FilePath'

          const inputContainer = document.createElement('div');
          inputContainer.className = 'input-container';

          // 创建显示输入名称的输入框
          const inputName = document.createElement('input');
          inputName.value = input.name;
          inputContainer.appendChild(inputName);

          // 创建选择框
          const selectBox = document.createElement('select');
          const optionLink = document.createElement('option');
          optionLink.value = 'link';
          optionLink.text = 'Link';
          const optionLabel = document.createElement('option');
          optionLabel.value = 'Input';
          optionLabel.text = 'Input';
          selectBox.appendChild(optionLink);
          selectBox.appendChild(optionLabel);
          inputContainer.appendChild(selectBox);
          let labelTextarea = document.createElement('textarea'); // 在外部声明变量以便在不同的作用域中访问
          labelTextarea.className = 'normalInput-textarea';
          let pathButton;
          if(input.IsLabel==true)
          {
            selectBox.value = 'Input';
            handleChange('Input');
          }
          // 处理选择框变化
          
          function handleChange(value) {
              // 如果之前添加了文本区域且现在选择是“Link”，则移除文本区域
              if (labelTextarea && value === 'link') {
                  inputContainer.removeChild(labelTextarea);
                  if (pathButton && inputContainer.contains(pathButton)) {
                    inputContainer.removeChild(pathButton);
                  }
                  labelTextarea = null; // 确保引用被清除
                  ChangeAnchorValue(id, '', 'link',input.Id);
              } else if (value === 'Input') {
                  // 如果当前选择是“Input”，则添加文本区域
                  if(input.Kind !='Boolean')
                  {
                    console.log("input.Kind测试",input.Kind);
                    labelTextarea=document.createElement('textarea');

                    if(input.Kind == 'Num')
                    labelTextarea.value = input.Num;
                    else if(input.Kind .includes('String'))
                    labelTextarea.value = input.Context;
                    let uniqueClass = `unique-textarea-${id}-${input.Id}`;
                    labelTextarea.className = 'normalInput-textarea ' + uniqueClass; // 同时设置两个类名
                    labelTextarea.id = uniqueClass;
                    labelTextarea.style.height = '20px';
                    labelTextarea.style.width = '560px'; 
                    labelTextarea.classList.add(uniqueClass); // 为文本区域添加唯一类名
                    adjustHeightBasedOnContent(labelTextarea);
                    labelTextarea.oninput = function() {
                      adjustHeight(this);
                    };
                    labelTextarea.addEventListener('input', function() {
                    let isOk = true; // 假定输入无效
                    if(input.Kind == 'Num') {
                      if(labelTextarea.value.match(/^[0-9]+$/))
                      {
                        isOk = true; // 如果是，将isOk设置为true，表示输入有
                      }
                      else {
                        // 如果上述条件都不满足，则弹出提示窗口告知用户输入格式不正确
                        isOk = false;
                        alert("类型不符，您应该输入数字！");
                      }
                    }
                    if (labelTextarea.value.trim() === '') {
                        isOk = false; // 如果输入为空，则将isOk设置为false，表示输入无效
                        alert("输入不能为空！");
                    }
                      if (isOk) {
                        ChangeAnchorValue(id, labelTextarea.value, 'Input',input.Id); // 假定 id 和 ChangeNodeLabel 已定义
                      }

                  });
                    labelTextarea.addEventListener('input', function() {
                      // 重置高度以计算新的高度
                      this.style.height = 'auto';
                    
                      // 设置新的高度
                      this.style.height = `${this.scrollHeight}px`;
                    });
                    inputContainer.appendChild(labelTextarea);
                    if(input.Kind.includes('FilePath'))
                      {
                        pathButton = document.createElement('button');
                        pathButton.textContent = 'Selecte Path';
                        pathButton.addEventListener('click', function() {
                          CreatFilePath(input.Id,id);
                        });
                        inputContainer.appendChild(pathButton);
    
                      }
                  }
                  else
                  {
                    const selectBox = document.createElement('select');
                    const option1 = document.createElement('option');
                    option1.value = 'true';
                    option1.text = 'true';
                    const option2 = document.createElement('option');
                    option2.value = 'false';
                    option2.text = 'false';
                    selectBox.appendChild(option1);
                    selectBox.appendChild(option2);
                    inputContainer.appendChild(selectBox);
                    selectBox.value = input.Boolean;
                    selectBox.addEventListener('change', function() {
                      ChangeAnchorValue(id, selectBox.value, 'Input',input.Id); // 假定 id 和 ChangeNodeLabel 已定义
                    });
                  }
              }
          }
          selectBox.addEventListener('change', function() {
            handleChange(this.value);
          });
          // 为输入框添加 blur 监听器
          inputName.addEventListener('input', function() {
              ChangeAnchorLabel(id, inputName.value, index,input.Id,true); // 假定 id 和 ChangeNodeLabel 已定义
          });

          inputColumn.appendChild(inputContainer);
          
        });
      }
      else
      {
        function CreatInputs(input,index,IdTemp)
        {
          const inputContainer = document.createElement('div');
          inputContainer.className = 'input-container';

          // 创建显示输入名称的输入框
          const inputName = document.createElement('input');
          inputName.value = input.name;
          inputContainer.appendChild(inputName);

          // 创建选择框
          const selectBox = document.createElement('select');
          const optionLink = document.createElement('option');
          optionLink.value = 'link';
          optionLink.text = 'Link';
          const optionLabel = document.createElement('option');
          optionLabel.value = 'Input';
          optionLabel.text = 'Input';
          selectBox.appendChild(optionLink);
          selectBox.appendChild(optionLabel);
          inputContainer.appendChild(selectBox);

          const Select1=document.createElement('select');
          const optionContext = document.createElement('option');
          optionContext.value = 'String';
          optionContext.text = 'String';
          const optionNum = document.createElement('option');
          optionNum.value = 'Num';
          optionNum.text = 'Num';
          const optionBool = document.createElement('option');
          optionBool.value = 'Boolean';
          optionBool.text = 'Boolean';
          const optionFilePath = document.createElement('option');
          optionFilePath.value = 'String_FilePath';
          optionFilePath.text = 'FilePath';

          Select1.appendChild(optionContext);
          Select1.appendChild(optionNum);
          Select1.appendChild(optionBool);
          Select1.appendChild(optionFilePath);
          //Select1选择input.Kind的值匹配
          Select1.selectedIndex = 2;
          inputContainer.appendChild(Select1);
          Select1.addEventListener('change', function() {
            let data = graph.save();
            data.nodes.forEach((node) => {
              if (node.id == id) {
                node.Inputs.forEach((input,index) => {
                  if (input.Id == IdTemp) {
                    input.Kind = this.value;
                  }
                }
                );
              }
            }
            );
            ChangeDatas(data);
          });
          const SubNode = document.createElement('div');
          SubNode.className = 'column-SubNode'; // 使用之前定义的样式类
          SubNode.style.left = '310px'; // 设置与标签之间的间距
          inputContainer.appendChild(SubNode);
          SubNode.onmousedown = function() {//删除这个矛点
            let data=graph.save();
            data.nodes.forEach((node) => {
              if(node.id == id)
              {
                //通过IdTemp删除这个矛点
                node.Inputs.forEach((input,index) => {
                    if(input.Id == IdTemp)
                    {
                      node.Inputs.splice(index,1);
                    }
                  });
                const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
                node.anchorPoints = node.Inputs.map((node, index) => {
                    const anchorHeight = 60 + index * 20;
                    return [0.05, anchorHeight / maxHeight]
                  }).concat(node.Outputs.map((node, index) => {
                    const anchorHeight = 60 + index * 20;
                    return [0.95, anchorHeight / maxHeight]
                  })).concat([[0, 0]]);
                ChangeDatas(data);

                //移除inputContainer
                inputContainer.parentNode.removeChild(inputContainer);
              }
            });
            RefreshEdge();

          }

          Select1.value = input.Kind;
          let labelTextarea = document.createElement('textarea'); // 在外部声明变量以便在不同的作用域中访问
          if(input.IsLabel==true)
          {
            selectBox.value = 'Input';
            handleChange('Input');
          }
          // 处理选择框变化
          function handleChange(value) {
              // 如果之前添加了文本区域且现在选择是“Link”，则移除文本区域
              let data = graph.save();
              data.edges.forEach(edge => {
                if (edge.target==id && edge.targetAnchor==index) {
                  const item = graph.findById(edge.id);
                  const targetNode = graph.findById(edge.target);
                  const targetAnchor = targetNode.getContainer().find(ele => ele.get('anchorPointIdx') === edge.targetAnchor);
                  targetAnchor.set('links', targetAnchor.get('links') + 1);
                  ChangeLink(targetAnchor);
                  graph.remove(item);
                }
              });
              if (labelTextarea && value === 'link') {
                  inputContainer.removeChild(labelTextarea);
                  labelTextarea = null; // 确保引用被清除
                  ChangeAnchorValue(id, '', 'link',input.Id);
              } else if (value === 'Input') {
                  // 如果当前选择是“Input”，则添加文本区域
                  labelTextarea = document.createElement('textarea');
                  if(input.Kind == 'Num')
                  labelTextarea.value = input.Num;
                  else if(input.Kind .includes('String'))
                  labelTextarea.value = input.Context;
                  labelTextarea.style.width = '550px'; // 设置固定宽度
                  labelTextarea.style.height = '20px'; // 初始高度
                  labelTextarea.style.overflow = 'hidden'; // 防止滚动条出现
                  labelTextarea.style.verticalAlign = 'top'; // 输入行字符居上
                  labelTextarea.style.lineHeight = '20px'; // 设置行高以匹配初始高度
                  labelTextarea.style.resize = 'vertical';
                  let uniqueClass = `unique-textarea-${id}-${input.Id}`; // 使用input.Id生成唯一的类名
                  labelTextarea.className = uniqueClass;
                  labelTextarea.id = uniqueClass;
                  
                  labelTextarea.classList.add(uniqueClass); // 为文本区域添加唯一类名
                  //labelTextarea.style.resize = 'none'; // 禁止用户手动调整大小
                  labelTextarea.style.resize = 'vertical';
                  ChangeAnchorValue(id, labelTextarea.value, 'Input',input.Id);
                  labelTextarea.addEventListener('input', function() {
                  let isOk = true; // 假定输入无效
                  if(input.Kind == 'Num') {
                    if(labelTextarea.value.match(/^[0-9]+$/))
                    {
                      isOk = true; // 如果是，将isOk设置为true，表示输入有
                    }
                    else {
                      // 如果上述条件都不满足，则弹出提示窗口告知用户输入格式不正确
                      isOk = false;
                      alert("类型不符，您应该输入数字！");
                    }
                  }
                  if (labelTextarea.value.trim() === '') {
                      isOk = false; // 如果输入为空，则将isOk设置为false，表示输入无效
                      alert("输入不能为空！");
                  }
                    if (isOk) {
                      ChangeAnchorValue(id, labelTextarea.value, 'Input',input.Id); // 假定 id 和 ChangeNodeLabel 已定义
                    }

                });
                  labelTextarea.addEventListener('input', function() {
                    // 重置高度以计算新的高度
                    this.style.height = 'auto';
                  
                    // 设置新的高度
                    this.style.height = `${this.scrollHeight}px`;
                  });
                  inputContainer.appendChild(labelTextarea);
              }
          }
          selectBox.addEventListener('change', function() {
            handleChange(this.value);
          });
          Select1.addEventListener('change', function() {

          });
          // 为输入框添加 blur 监听器
          inputName.addEventListener('input', function() {
              ChangeAnchorLabel(id, inputName.value, index,input.Id,true); // 假定 id 和 ChangeNodeLabel 已定义
          });

          inputColumn.appendChild(inputContainer);
          RefreshEdge();
        }
        const inputColumn = document.createElement('div');
        inputColumn.className = 'column';
        const inputLabel = document.createElement('div');
        inputLabel.textContent = 'Input'; // 设置文本
        inputLabel.className = 'column-label'; // 设置样式类
        inputColumn.appendChild(inputLabel);
        const addNode = document.createElement('div');
        addNode.className = 'column-AddNode'; // 使用之前定义的样式类
        let IdTemp='';
        inputColumn.appendChild(inputLabel);
        vessel.appendChild(inputColumn);
        Inputs.forEach((input, index) => {
          if(input.Kind.includes('FilePath')==false)
          {
            const inputContainer = document.createElement('div');
            inputContainer.className = 'input-container';

            // 创建显示输入名称的输入框
            const inputName = document.createElement('input');
            inputName.value = input.name;
            inputContainer.appendChild(inputName);

            // 创建选择框
            const selectBox = document.createElement('select');
            const optionLink = document.createElement('option');
            optionLink.value = 'link';
            optionLink.text = 'Link';
            const optionLabel = document.createElement('option');
            optionLabel.value = 'Input';
            optionLabel.text = 'Input';
            selectBox.appendChild(optionLink);
            selectBox.appendChild(optionLabel);
            inputContainer.appendChild(selectBox);
            let labelTextarea = document.createElement('textarea'); // 在外部声明变量以便在不同的作用域中访问
            let uniqueClass = `unique-textarea-${id}-${input.Id}`; // 使用input.Id生成唯一的类名
            
            labelTextarea.className = uniqueClass;
            labelTextarea.id = uniqueClass;
            labelTextarea.classList.add(uniqueClass); // 为文本区域添加唯一类名
            if(input.IsLabel==true)
            {
              selectBox.value = 'Input';
              handleChange('Input');
            }
            // 处理选择框变化
            function handleChange(value) {
                // 如果之前添加了文本区域且现在选择是“Link”，则移除文本区域
                if (labelTextarea && value === 'link') {
                    inputContainer.removeChild(labelTextarea);
                    labelTextarea = null; // 确保引用被清除
                    ChangeAnchorValue(id, '', 'link',input.Id);
                } else if (value === 'Input') {
                    // 如果当前选择是“Input”，则添加文本区域
                    labelTextarea = document.createElement('textarea');
                    if(input.Kind == 'Num')
                    labelTextarea.value = input.Num;
                    else if(input.Kind .includes('String'))
                    labelTextarea.value = input.Context;
                    labelTextarea.style.width = '550px'; // 设置固定宽度
                    labelTextarea.style.height = '20px'; // 初始高度
                    labelTextarea.style.overflow = 'hidden'; // 防止滚动条出现
                    labelTextarea.style.verticalAlign = 'top'; // 输入行字符居上
                    labelTextarea.style.lineHeight = '20px'; // 设置行高以匹配初始高度
                    //labelTextarea.style.resize = 'none'; // 禁止用户手动调整大小
                    labelTextarea.style.resize = 'vertical';
                    adjustHeightBasedOnContent(labelTextarea);
                    labelTextarea.oninput = function() {
                      adjustHeight(this);
                    };
                    labelTextarea.addEventListener('input', function() {
                    let isOk = true; // 假定输入无效
                    if(input.Kind == 'Num') {
                      if(labelTextarea.value.match(/^[0-9]+$/))
                      {
                        isOk = true; // 如果是，将isOk设置为true，表示输入有
                      }
                      else {
                        // 如果上述条件都不满足，则弹出提示窗口告知用户输入格式不正确
                        isOk = false;
                        alert("类型不符，您应该输入数字！");
                      }
                    }
                    if (labelTextarea.value.trim() === '') {
                        isOk = false; // 如果输入为空，则将isOk设置为false，表示输入无效
                        alert("输入不能为空！");
                    }
                      if (isOk) {
                        ChangeAnchorValue(id, labelTextarea.value, 'Input',input.Id); // 假定 id 和 ChangeNodeLabel 已定义
                      }

                  });
                    labelTextarea.addEventListener('input', function() {
                      // 重置高度以计算新的高度
                      this.style.height = 'auto';
                    
                      // 设置新的高度
                      this.style.height = `${this.scrollHeight}px`;
                    });
                    inputContainer.appendChild(labelTextarea);
                }
            }
            selectBox.addEventListener('change', function() {
              handleChange(this.value);
            });
            // 为输入框添加 blur 监听器
            inputName.addEventListener('input', function() {
                ChangeAnchorLabel(id, inputName.value, index,input.Id,true); // 假定 id 和 ChangeNodeLabel 已定义
            });

            inputColumn.appendChild(inputContainer);
          }
          else if (input.Kind.includes('FilePath')) {
            const inputContainer = document.createElement('div');
            inputContainer.className = 'input-container';
          
            // 创建显示输入名称的输入框
            const inputName = document.createElement('input');
            inputName.value = input.name;
            inputContainer.appendChild(inputName);
            // 创建选择框
            const selectBox = document.createElement('select');
            const optionLink = document.createElement('option');
            optionLink.value = 'link';
            optionLink.text = 'Link';
            const optionLabel = document.createElement('option');
            optionLabel.value = 'Input';
            optionLabel.text = 'Input';
            selectBox.appendChild(optionLink);
            selectBox.appendChild(optionLabel);
            inputContainer.appendChild(selectBox);
            // 创建路径按钮
            let pathButton ;
          
            // 创建文本区域
            let labelTextarea = document.createElement('textarea'); // 在外部声明变量以便在不同的作用域中访问
            let uniqueClass = `unique-textarea-${id}-${input.Id}`; // 使用input.Id生成唯一的类名
            
            labelTextarea.className = uniqueClass;
            labelTextarea.id = uniqueClass;
            labelTextarea.classList.add(uniqueClass); // 为文本区域添加唯一类名
          
            // 为输入框添加 input 监听器
            inputName.addEventListener('input', function () {
              ChangeAnchorLabel(id, inputName.value, index, input.Id, true); // 假定 id 和 ChangeNodeLabel 已定义
            });
            if(input.IsLabel==true)
              {
                selectBox.value = 'Input';
                handleChange('Input');
              }
              // 处理选择框变化
              function handleChange(value) {
                  // 如果之前添加了文本区域且现在选择是“Link”，则移除文本区域
                  let data = graph.save();
                  data.edges.forEach(edge => {
                    if (edge.target==id && edge.targetAnchor==index) {
                      
                      const item = graph.findById(edge.id);
                      const targetNode = graph.findById(edge.target);
                      const targetAnchor = targetNode.getContainer().find(ele => ele.get('anchorPointIdx') === edge.targetAnchor);
                      targetAnchor.set('links', targetAnchor.get('links') + 1);
                      ChangeLink(targetAnchor);
                      graph.remove(item);
                    }
                  });
                  if (labelTextarea && value === 'link') {
                    if (pathButton && inputContainer.contains(pathButton)) {
                      inputContainer.removeChild(pathButton);
                    }
                    inputContainer.removeChild(labelTextarea);
                    labelTextarea = null; // 确保引用被清除
                    ChangeAnchorValue(id, '', 'link',input.Id);
                  } else if (value === 'Input') {
                      // 如果当前选择是“Input”，则添加文本区域
                      labelTextarea = document.createElement('textarea');
                      if(input.Kind == 'Num')
                      labelTextarea.value = input.Num;
                      else if(input.Kind .includes('String'))
                      labelTextarea.value = input.Context;
                      labelTextarea.style.width = '550px'; // 设置固定宽度
                      labelTextarea.style.height = '20px'; // 初始高度
                      labelTextarea.style.overflow = 'hidden'; // 防止滚动条出现
                      labelTextarea.style.verticalAlign = 'top'; // 输入行字符居上
                      labelTextarea.style.lineHeight = '20px'; // 设置行高以匹配初始高度
                      labelTextarea.style.resize = 'vertical';
                      let uniqueClass = `unique-textarea-${id}-${input.Id}`; // 使用input.Id生成唯一的类名
                      labelTextarea.className = uniqueClass;
                      labelTextarea.id = uniqueClass;
                      adjustHeightBasedOnContent(labelTextarea);
                      labelTextarea.oninput = function() {
                        adjustHeight(this);
                      };
                      labelTextarea.classList.add(uniqueClass); // 为文本区域添加唯一类名
                      //labelTextarea.style.resize = 'none'; // 禁止用户手动调整大小
                      labelTextarea.style.resize = 'vertical';
                      ChangeAnchorValue(id, labelTextarea.value, 'Input',input.Id);
                      labelTextarea.addEventListener('input', function() {
                      let isOk = true; // 假定输入无效
                      if(input.Kind == 'Num') {
                        if(labelTextarea.value.match(/^[0-9]+$/))
                        {
                          isOk = true; // 如果是，将isOk设置为true，表示输入有
                        }
                        else {
                          // 如果上述条件都不满足，则弹出提示窗口告知用户输入格式不正确
                          isOk = false;
                          alert("类型不符，您应该输入数字！");
                        }
                      }
                      if (labelTextarea.value.trim() === '') {
                          isOk = false; // 如果输入为空，则将isOk设置为false，表示输入无效
                          alert("输入不能为空！");
                      }
                        if (isOk) {
                          ChangeAnchorValue(id, labelTextarea.value, 'Input',input.Id); // 假定 id 和 ChangeNodeLabel 已定义
                        }
    
                    });
                      labelTextarea.addEventListener('input', function() {
                        // 重置高度以计算新的高度
                        this.style.height = 'auto';
                      
                        // 设置新的高度
                        this.style.height = `${this.scrollHeight}px`;
                      });
                      inputContainer.appendChild(labelTextarea);
                      if(input.Kind.includes('FilePath'))
                        {
                          pathButton = document.createElement('button');
                          pathButton.textContent = 'Selecte Path';
                          pathButton.addEventListener('click', function() {
                            CreatFilePath(input.Id,id);
                          });
                          inputContainer.appendChild(pathButton);
      
                        }
                  }
              }
              selectBox.addEventListener('change', function() {
                handleChange(this.value);
              });
            // 为文本区域添加 input 监听器
            labelTextarea.addEventListener('input', function () {
              ChangeAnchorValue(id, labelTextarea.value, 'FilePath', input.Id); // 假定 ChangeAnchorValue 已定义
            });
          
            inputColumn.appendChild(inputContainer);
          }
        });
        addNode.onmousedown = function() {
            let data=graph.save();
            data.nodes.forEach((node) => {
              if(node.id == id)
              {
                IdTemp='Input' + (node.Inputs.length + 1).toString()+Date.now();
                let TempName = 'Input' + (node.Inputs.length + 1).toString();
                let counter = 1; // 新增一个计数器
                // 检查是否重名，如果重名则+1继续检查
                while (node.Inputs.some(input => input.name === TempName)) {
                    TempName = 'Input' + (node.Inputs.length + 1 + counter).toString(); // 使用计数器调整名称
                    counter++; // 每次循环递增计数器
                }
                node.Inputs.push({
                  'Num': null,
                  'Kind': 'String',
                  'Id': IdTemp,
                  'Context': null,
                  'Isnecessary': false,
                  'name': TempName,
                  'Link': 0,
                  'IsLabel': false,
              });
              const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
              node.anchorPoints = node.Inputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.05, anchorHeight / maxHeight]
                }).concat(node.Outputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.95, anchorHeight / maxHeight]
                })).concat([[0, 0]]);
              CreatInputs(node.Inputs[node.Inputs.length - 1],node.Inputs.length - 1,IdTemp);
              ChangeDatas(data);
              }
            });

            RefreshEdge();
          };
        //等比例扩大addNode

        // 确定插入位置并将AddNode插入到inputColumn中
        const nextElement = inputLabel.nextSibling; // 获取inputLabel之后的元素
        if (nextElement) {
            // 如果inputLabel后面有其他元素，则在这个元素之前插入addNode
            inputColumn.insertBefore(addNode, nextElement);
        } else {
            // 如果inputLabel是最后一个元素或inputColumn没有其他子元素，则直接追加
            inputColumn.appendChild(addNode);
        }
      }
      if(OutputsIsAdd==null || OutputsIsAdd==false || OutputsIsAdd=='')
        {
          const outputColumn = document.createElement('div');
          outputColumn.className = 'column';
          const outputLabel = document.createElement('div');
          outputLabel.textContent = 'Output'; // 设置文本
          outputLabel.className = 'column-label'; // 设置样式类
          outputColumn.appendChild(outputLabel);
          // 将输入和输出列添加到节点容器中

          vessel.appendChild(outputColumn);
          Outputs.forEach((output, index) => {
            const outputContainer = document.createElement('div');
            outputContainer.className = 'output-container';
            const outputName = document.createElement('input');
            outputName.value = output.name;
            outputContainer.appendChild(outputName);
            outputName.addEventListener('input', function() {
              ChangeAnchorLabel(id, outputName.value, index,output.Id,false);
            });
            outputColumn.appendChild(outputContainer);
          });
        }
        else
        {
          function CreatOutputs(output, index,IdTemp) {
            const outputContainer = document.createElement('div');
            outputContainer.className = 'output-container';
            outputContainer.style.display = 'flex';
            outputContainer.style.alignItems = 'flex-start'; // 使内容顶部对齐
            outputContainer.style.flexWrap = 'nowrap'; // 允许子元素换行
    
            // Create an input box to display the output name
            const outputName = document.createElement('input');
            outputName.value = output.name;
            outputName.style.width = '100px'; // Allow it to grow
            outputContainer.appendChild(outputName);
    
            // Create type selection box
            const Select1 = document.createElement('select');
            Select1.style.width = '75px'; // Set a fixed width
            const optionContext = document.createElement('option');
            optionContext.value = 'String';
            optionContext.text = 'String';
            const optionNum = document.createElement('option');
            optionNum.value = 'Num';
            optionNum.text = 'Num';
            const optionBool = document.createElement('option');
            optionBool.value = 'Boolean';
            optionBool.text = 'Boolean';
            Select1.appendChild(optionContext);
            Select1.appendChild(optionNum);
            Select1.appendChild(optionBool);
            Select1.value = output.Kind;
            outputContainer.appendChild(Select1);
            Select1.addEventListener('change', function() {
              let data = graph.save();
              data.nodes.forEach((node) => {
                if (node.id == id) {
                  //切断跟它output有关的边
                  node.Outputs.forEach((output,index) => {
                    if (output.Id == IdTemp) {
                      output.Kind = this.value;
                    }
                  }
                  );
                }
              }
              );
              ChangeDatas(data);
            });
            Outputs.forEach((output, index) => {
              const outputContainer = document.createElement('div');
              outputContainer.className = 'output-container';
              const outputName = document.createElement('input');
              outputName.value = output.name;
              outputContainer.appendChild(outputName);
              outputName.addEventListener('input', function() {
                ChangeAnchorLabel(id, outputName.value, index,output.Id,false);
              });
              outputColumn.appendChild(outputContainer);
            });
            // 添加删除按钮
            const SubNode = document.createElement('div');
            SubNode.className = 'column-SubNode'; // 使用之前定义的样式类
            SubNode.style.right = '30px'; // 设置与 Description 之间的间距
            outputContainer.appendChild(SubNode);
            SubNode.onmousedown = function() {//删除这个矛点
              let data=graph.save();
              data.nodes.forEach((node) => {
                if(node.id == id)
                {
                  //通过IdTemp删除这个矛点
                  node.Outputs.forEach((output,index) => {
                      if(output.Id == IdTemp)
                      {
                        node.Outputs.splice(index,1);
                      }
                    }
                  );
                  const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
                  node.anchorPoints = node.Inputs.map((node, index) => {
                      const anchorHeight = 60 + index * 20;
                      return [0.05, anchorHeight / maxHeight]
                    }).concat(node.Outputs.map((node, index) => {
                      const anchorHeight = 60 + index * 20;
                      return [0.95, anchorHeight / maxHeight]
                    })).concat([[0, 0]]);
                  ChangeDatas(data);
                  //移除outputContainer
                  outputContainer.parentNode.removeChild(outputContainer);
                }
              });
              RefreshEdge();
            }
            outputName.addEventListener('input', function() {
              ChangeAnchorLabel(id, outputName.value, index,output.Id,false); // 假定 id 和 ChangeNodeLabel 已定义
          });
            outputColumn.appendChild(outputContainer);
          }
          const outputColumn = document.createElement('div');
          outputColumn.className = 'column';
          const outputLabel = document.createElement('div');
          outputLabel.textContent = 'Output'; // 设置文本
          outputLabel.className = 'column-label'; // 设置样式类
          outputColumn.appendChild(outputLabel);
          // 将输入和输出列添加到节点容器中
          vessel.appendChild(outputColumn);
          Outputs.forEach((output, index) => {
            const outputContainer = document.createElement('div');
            outputContainer.className = 'output-container';
            const outputName = document.createElement('input');
            outputName.value = output.name;
            outputContainer.appendChild(outputName);
            outputName.addEventListener('input', function() {
              ChangeAnchorLabel(id, outputName.value, index,output.Id,false);
            });
            outputColumn.appendChild(outputContainer);
          });
          const addNode1 = document.createElement('div');
          addNode1.className = 'column-AddNode'; // 使用之前定义的样式类
          addNode1.style.marginLeft = '20px'; // 设置与标签之间的间距
          let IdTemp='';
          outputColumn.appendChild(addNode1);
          addNode1.onmousedown = function() {
            let data=graph.save();
            data.nodes.forEach((node) => {
              if(node.id == id)
              {
                IdTemp='Output' + (node.Outputs.length + 1).toString()+Date.now();
                let TempName = 'Output' + (node.Inputs.length + 1).toString();
                let counter = 1; // 新增一个计数器
                // 检查是否重名，如果重名则+1继续检查
                while (node.Outputs.some(output => output.name === TempName)) {
                    TempName = 'Input' + (node.Outputs.length + 1 + counter).toString(); // 使用计数器调整名称
                    counter++; // 每次循环递增计数器
                }
                node.Outputs.push({
                  'Num': 0,
                  'Kind': 'String',
                  'Id': IdTemp,
                  'Context': '',
                  'Boolean': false,
                  'Isnecessary': true,
                  'name': TempName,
                  'Link': 0,
                  'IsLabel': false,
              });
              const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
              node.anchorPoints = node.Inputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.05, anchorHeight / maxHeight]
                }).concat(node.Outputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.95, anchorHeight / maxHeight]
                })).concat([[0, 0]]);
              CreatOutputs(node.Outputs[node.Outputs.length - 1],node.Outputs.length - 1,IdTemp);
              ChangeDatas(data);
              }
            });
    
            RefreshEdge();
          };
        }
    }
    else if(NodeKind.includes('LLm'))
    {
        //#region 基本设置部分
        const LlmSettingColumn = document.createElement('div');
        LlmSettingColumn.className = 'column';

        const llmSettings = document.createElement('div');
        llmSettings.className = 'column';

        
        const basicSettings = document.createElement('div');
        basicSettings.className = 'basic-settings';

        // 去掉 name 变量中的 '.py' 后缀
        const modelName = name.replace('.py', '');

        // 创建 modelSelector 元素并设置内容
        const modelSelector = document.createElement('div');
        modelSelector.className = 'model-selector';
        modelSelector.textContent = 'Model';
        modelSelector.style.color='white'

        // 过滤出 NodeKind 为 'LLm' 的文件，并去掉 '.py' 后缀
        const filteredFiles = fileList
            .filter(file => file.NodeKind.includes('LLm'))
            .map(file => file.filename.replace('.py', ''));

        // 创建选择框并添加过滤后的文件名
        const modelSelect = document.createElement('select');
        modelSelect.id = 'model';

        filteredFiles.forEach(filename => {
            const option = document.createElement('option');
            option.value = filename;
            option.textContent = filename;
            modelSelect.appendChild(option);
        });
        modelSelect.value = modelName; // 设置选择框的默认值

        // 将选择框添加到 modelSelector 元素中
        modelSelector.appendChild(modelSelect);

        // 添加到 basicSettings 中
        basicSettings.appendChild(modelSelector);

        // 温度设置
        const temperatureSetting = document.createElement('div');
        temperatureSetting.className = 'temperature-setting';

        const temperatureLabel = document.createElement('label');
        temperatureLabel.textContent = 'Temperature';
        temperatureLabel.style.color='white'
        temperatureSetting.appendChild(temperatureLabel);

        const temperatureInput = document.createElement('input');
        temperatureInput.type = 'number';
        temperatureInput.id = 'temperature';
        temperatureInput.style.width = '50px';
        temperatureInput.step = '0.1'; // 设置 step 属性为 0.1
        temperatureInput.min = '0';    // 设置最小值为0
        temperatureInput.max = '1';    // 设置最大值为1
        temperatureSetting.appendChild(temperatureInput);

        basicSettings.appendChild(temperatureSetting);

        // 创建快捷设置标签和选择框
        const presetSetting = document.createElement('div');
        presetSetting.className = 'preset-setting';

        const presetLabel = document.createElement('label');
        presetLabel.textContent = '加载预设';
        presetLabel.style.color='white'
        presetLabel.setAttribute('for', 'preset-select');
        presetSetting.appendChild(presetLabel);

        const presetSelect = document.createElement('select');
        presetSelect.id = 'preset-select';

        const presets = [
            { name: '创意', temperature: 0.8, top_p: 0.9, presence_penalty: 0.1, frequency_penalty: 0.1 },
            { name: '平衡', temperature: 0.5, top_p: 0.85, presence_penalty: 0.2, frequency_penalty: 0.3 },
            { name: '精确', temperature: 0.2, top_p: 0.75, presence_penalty: 0.5, frequency_penalty: 0.5 }
        ];

        presets.forEach(preset => {
            const option = document.createElement('option');
            option.value = preset.name;
            option.textContent = preset.name;
            presetSelect.appendChild(option);
        });

        // 设置选择框的默认值为“平衡”
        presetSelect.value = '平衡';

        presetSelect.addEventListener('change', () => {
            const selectedPreset = presets.find(preset => preset.name === presetSelect.value);
            if (selectedPreset) {
                temperatureInput.value = selectedPreset.temperature;
                topPInput.value = selectedPreset.top_p;
                presencePenaltyInput.value = selectedPreset.presence_penalty;
                frequencyPenaltyInput.value = selectedPreset.frequency_penalty;
                const values = [
                    modelSelect.value,
                    parseFloat(temperatureInput.value),
                    parseFloat(topPInput.value),
                    parseFloat(frequencyPenaltyInput.value),
                    parseFloat(presencePenaltyInput.value),
                    parseInt(maxTokensInput.value, 10)
                ];
                console.log('values', values);
                ChangeLlmSetting(id, values);  // 替换为实际的节点 ID
            }
        });

        presetSetting.appendChild(presetSelect);

        // 将快捷设置添加到 basicSettings 中
        basicSettings.appendChild(presetSetting);
        // 展开按钮
        const expandButton = document.createElement('button');
        expandButton.id = 'expand-button';
        expandButton.textContent = '↓';
        expandButton.className = 'expand-button';
        basicSettings.appendChild(expandButton);

        llmSettings.appendChild(basicSettings);

        // 高级设置部分
        const advancedSettings = document.createElement('div');
        advancedSettings.id = 'advanced-settings';
        advancedSettings.className = 'advanced-settings';

        // 参数行1
        const parameterRow1 = document.createElement('div');
        parameterRow1.className = 'parameter-row';

        // Top P
        const topPSetting = document.createElement('div');
        topPSetting.className = 'parameter';

        const topPLabel = document.createElement('label');
        topPLabel.textContent = 'Top P';
        topPSetting.appendChild(topPLabel);

        const topPInput = document.createElement('input');
        topPInput.type = 'number';
        topPInput.style.width = '50px';
        topPInput.style.marginLeft = '10px';

        topPInput.id = 'top-p';
        topPSetting.appendChild(topPInput);

        // 创建拖动条
        const topPRange = document.createElement('input');
        topPRange.type = 'range';
        topPRange.id = 'top-p-range';
        topPRange.min = 0;
        topPRange.max = 1;
        topPRange.step = 0.01;
        topPSetting.appendChild(topPRange);

        // 将输入框和拖动条同步
        topPInput.addEventListener('input', function () {
            topPRange.value = topPInput.value;
        });

        topPRange.addEventListener('input', function () {
            topPInput.value = topPRange.value;
        });

        parameterRow1.appendChild(topPSetting);

        // 频率惩罚
        const frequencyPenaltySetting = document.createElement('div');
        frequencyPenaltySetting.className = 'parameter';

        const frequencyPenaltyLabel = document.createElement('label');
        frequencyPenaltyLabel.textContent = '频率惩罚';
        frequencyPenaltySetting.appendChild(frequencyPenaltyLabel);

        const frequencyPenaltyInput = document.createElement('input');
        frequencyPenaltyInput.type = 'number';
        frequencyPenaltyInput.style.width = '50px';
        frequencyPenaltyInput.style.marginLeft = '10px';
        frequencyPenaltyInput.step = 0.1;
        frequencyPenaltyInput.min = 0;
        frequencyPenaltyInput.max = 1;
        frequencyPenaltyInput.id = 'frequency-penalty';
        frequencyPenaltySetting.appendChild(frequencyPenaltyInput);

        // 创建拖动条
        const frequencyPenaltyRange = document.createElement('input');
        frequencyPenaltyRange.type = 'range';
        frequencyPenaltyRange.id = 'frequency-penalty-range';
        frequencyPenaltyRange.min = 0;
        frequencyPenaltyRange.max = 1;
        frequencyPenaltyRange.step = 0.1;
        frequencyPenaltySetting.appendChild(frequencyPenaltyRange);

        // 将输入框和拖动条同步
        frequencyPenaltyInput.addEventListener('input', function () {
            frequencyPenaltyRange.value = frequencyPenaltyInput.value;
        });

        frequencyPenaltyRange.addEventListener('input', function () {
            frequencyPenaltyInput.value = frequencyPenaltyRange.value;
        });

        parameterRow1.appendChild(frequencyPenaltySetting);

        advancedSettings.appendChild(parameterRow1);

        // 参数行2
        const parameterRow2 = document.createElement('div');
        parameterRow2.className = 'parameter-row';

        // 存在惩罚
        const presencePenaltySetting = document.createElement('div');
        presencePenaltySetting.className = 'parameter';

        const presencePenaltyLabel = document.createElement('label');
        presencePenaltyLabel.textContent = '存在惩罚';
        presencePenaltySetting.appendChild(presencePenaltyLabel);

        const presencePenaltyInput = document.createElement('input');
        presencePenaltyInput.type = 'number';
        presencePenaltyInput.style.width = '50px';
        presencePenaltyInput.style.marginLeft = '10px';
        presencePenaltyInput.step = 0.1;
        presencePenaltyInput.min = 0;
        presencePenaltyInput.max = 1;
        presencePenaltyInput.id = 'presence-penalty';
        presencePenaltySetting.appendChild(presencePenaltyInput);

        // 创建拖动条
        const presencePenaltyRange = document.createElement('input');
        presencePenaltyRange.type = 'range';
        presencePenaltyRange.id = 'presence-penalty-range';
        presencePenaltyRange.min = 0;
        presencePenaltyRange.max = 1;
        presencePenaltyRange.step = 0.1;
        presencePenaltySetting.appendChild(presencePenaltyRange);

        // 将输入框和拖动条同步
        presencePenaltyInput.addEventListener('input', function () {
            presencePenaltyRange.value = presencePenaltyInput.value;
        });

        presencePenaltyRange.addEventListener('input', function () {
            presencePenaltyInput.value = presencePenaltyRange.value;
        });

        parameterRow2.appendChild(presencePenaltySetting);

        // 最大标记
        const maxTokensSetting = document.createElement('div');
        maxTokensSetting.className = 'parameter';

        const maxTokensLabel = document.createElement('label');
        maxTokensLabel.textContent = '最大标记';
        maxTokensSetting.appendChild(maxTokensLabel);

        const maxTokensInput = document.createElement('input');
        maxTokensInput.type = 'number';
        maxTokensInput.style.width = '50px';
        maxTokensInput.style.marginLeft = '10px';
        maxTokensInput.id = 'max-tokens';
        maxTokensSetting.appendChild(maxTokensInput);

        // 创建拖动条
        const maxTokensRange = document.createElement('input');
        maxTokensRange.type = 'range';
        maxTokensRange.id = 'max-tokens-range';
        maxTokensRange.min = 1;
        maxTokensRange.max = 16000;
        maxTokensRange.step = 1;
        maxTokensSetting.appendChild(maxTokensRange);

        // 将输入框和拖动条同步
        maxTokensInput.addEventListener('input', function () {
            maxTokensRange.value = maxTokensInput.value;
        });

        maxTokensRange.addEventListener('input', function () {
            maxTokensInput.value = maxTokensRange.value;
        });

        parameterRow2.appendChild(maxTokensSetting);

        advancedSettings.appendChild(parameterRow2);

        llmSettings.appendChild(advancedSettings);

        // 展开按钮的点击事件
        expandButton.addEventListener('click', function () {
            if (advancedSettings.style.display === 'none') {
                advancedSettings.style.display = 'block';
                expandButton.textContent = '↑';
            } else {
                advancedSettings.style.display = 'none';
                expandButton.textContent = '↓';
            }
        });

        // 将所有内容添加到文档中
        llmSettings.appendChild(basicSettings);
        llmSettings.appendChild(advancedSettings);
        LlmSettingColumn.appendChild(llmSettings);

        vessel.appendChild(LlmSettingColumn);

        // 设置默认值
        const defaultValues = {
            temperature: 0.7,
            top_p: 0.75,
            presence_penalty: 0.5,
            frequency_penalty: 0.5,
            max_tokens: 4096
        };

        // 创建一个函数来设置输入框和拖动条的值
        function setInputValue(input, range, value, defaultValue) {
          if (input) {
              if (value !== null && value !== undefined && !isNaN(value)) {
                  input.value = value;
                  if (range) {
                      range.value = value;
                  }
              } else {
                  input.value = defaultValue;
                  if (range) {
                      range.value = defaultValue;
                  }
              }
          }
      }
      
      // 使用这个函数设置输入框的值
        setInputValue(temperatureInput, null, temperature, defaultValues.temperature); // 没有滑动条
        setInputValue(topPInput, topPRange, Top_p, defaultValues.top_p);
        setInputValue(presencePenaltyInput, presencePenaltyRange, presence_penalty, defaultValues.presence_penalty);
        setInputValue(frequencyPenaltyInput, frequencyPenaltyRange, frequency_penalty, defaultValues.frequency_penalty);
        setInputValue(maxTokensInput, maxTokensRange, max_tokens, defaultValues.max_tokens);

        // 添加事件监听器，确保在参数值变化时调用 ChangeLlmSetting 函数
        const inputElements = [
            { input: topPInput, range: topPRange },
            { input: frequencyPenaltyInput, range: frequencyPenaltyRange },
            { input: presencePenaltyInput, range: presencePenaltyRange },
            { input: maxTokensInput, range: maxTokensRange }
        ];
        temperatureInput.addEventListener('input', () => {
          const values = [
              modelSelect.value,
              parseFloat(temperatureInput.value),
              parseFloat(topPInput.value),
              parseFloat(frequencyPenaltyInput.value),
              parseFloat(presencePenaltyInput.value),
              parseInt(maxTokensInput.value, 10)
          ];
          ChangeLlmSetting(id, values);
      });
        inputElements.forEach(item => {
            item.input.addEventListener('input', () => {
                item.range.value = item.input.value;
                const values = [
                    modelSelect.value,
                    parseFloat(temperatureInput.value),
                    parseFloat(topPInput.value),
                    parseFloat(frequencyPenaltyInput.value),
                    parseFloat(presencePenaltyInput.value),
                    parseInt(maxTokensInput.value, 10)
                ];
                ChangeLlmSetting(id, values);
            });

            item.range.addEventListener('input', () => {
                item.input.value = item.range.value;
                const values = [
                    modelSelect.value,
                    parseFloat(temperatureInput.value),
                    parseFloat(topPInput.value),
                    parseFloat(frequencyPenaltyInput.value),
                    parseFloat(presencePenaltyInput.value),
                    parseInt(maxTokensInput.value, 10)
                ];
                ChangeLlmSetting(id, values);
            });
        });

        modelSelect.addEventListener('change', () => {
            const values = [
                modelSelect.value,
                parseFloat(temperatureInput.value),
                parseFloat(topPInput.value),
                parseFloat(frequencyPenaltyInput.value),
                parseFloat(presencePenaltyInput.value),
                parseInt(maxTokensInput.value, 10)
            ];
            ChangeLlmSetting(id, values);
        });
        //#endregion 基本设置部分

        const inputColumn = document.createElement('div');
        inputColumn.className = 'column';
        const inputLabel = document.createElement('div');
        inputLabel.textContent = 'Input'; // 设置文本
        inputLabel.className = 'column-label'; // 设置样式类
        inputColumn.appendChild(inputLabel);
        const addNode = document.createElement('div');
        addNode.className = 'column-AddNode'; // 使用之前定义的样式类
        vessel.appendChild(inputColumn);
        const promptColumn = document.createElement('div');
        promptColumn.className = 'column';
        const promptLabel = document.createElement('div');
        promptLabel.innerText = 'Prompt';
        promptLabel.className = 'column-label';
        promptColumn.appendChild(promptLabel);
        vessel.appendChild(promptColumn);
        const promptContainer = document.createElement('div');
        promptContainer.className = 'prompt-container';
        promptColumn.appendChild(promptContainer);
        // 创建可编辑的 div
        let promptInput = document.createElement('div');
        promptInput.className = 'prompt-textarea'; // 应用样式类
        promptInput.contentEditable = true; // 使 div 可编辑
        promptInput.spellcheck = false; // 禁用拼写检查
        promptInput.innerText = prompt; // 设置初始值


        // 初始化时根据内容调整高度
        adjustHeightBasedOnContent(promptInput);
        updateContentHighlighting();

        // 在内容变化时调整高度（包括程序性改变和用户输入）
        promptInput.oninput = function() {
            adjustHeightBasedOnContent(this);
        };

        // 输入框空格键增长逻辑用 prompt 给 promptInput.value 输入

        // 输入框空格键增长逻辑
        let selectedOptionIndex = -1;
        function getCursorPosition() {
          const selection = window.getSelection();
          if (selection.rangeCount === 0) return 0;
          
          const range = selection.getRangeAt(0);
          const preRange = range.cloneRange();
          preRange.selectNodeContents(promptInput);
          preRange.setEnd(range.endContainer, range.endOffset);
          return preRange.toString().length;
      }
        promptInput.addEventListener('input', function() {
            let data = graph.save();
            const nodeIndex = data.nodes.findIndex(node => node.id === id);
            data.nodes[nodeIndex].prompt = promptInput.innerText;
            console.log('prompt', promptInput.innerText);
            ChangeDatas(data);

            // 统一获取输入内容和光标位置
            const inputValue = promptInput.innerText;
            const cursorPosition = getCursorPosition(); // 使用统一的光标获取方法

            // 精准检测未闭合语法（替换原有逻辑）
            let openStack = [];
            let lastUnclosedOpenPos = -1;

            // 遍历整个输入内容
            for (let i = 0; i < inputValue.length; i++) {
                if (i < inputValue.length - 1 && inputValue.substr(i, 2) === '{{') {
                    openStack.push(i);
                    i++; // 跳过第二个字符
                } else if (i < inputValue.length - 1 && inputValue.substr(i, 2) === '}}') {
                    if (openStack.length > 0) openStack.pop();
                    i++; // 跳过第二个字符
                }
            }

            // 判断是否需要显示快捷菜单
            if (openStack.length > 0) {
                lastUnclosedOpenPos = openStack[openStack.length - 1];
                const nextClosePos = inputValue.indexOf('}}', lastUnclosedOpenPos);
                
                // 检查光标是否在未闭合区域内
                const isInUnclosedArea = (
                    cursorPosition > lastUnclosedOpenPos + 1 && 
                    (nextClosePos === -1 || cursorPosition <= nextClosePos)
                );

                if (isInUnclosedArea) {
                    const searchKeyword = inputValue.substring(lastUnclosedOpenPos + 2, cursorPosition);
                    showQuickOptions(searchKeyword.trim());
                } else {
                    hideQuickOptions();
                }
            } else {
                hideQuickOptions();
            }

            updateContentHighlighting();
        });

    // 更新高亮显示的函数
        function updateContentHighlighting() {
          const selection = window.getSelection();
          let originalRange = null;
          let anchorOffset = 0;
          let focusOffset = 0;

          // 记录光标的锚点和焦点位置
          if (selection.rangeCount > 0) {
              originalRange = selection.getRangeAt(0);
              const anchorPreRange = document.createRange();
              anchorPreRange.selectNodeContents(promptInput);
              anchorPreRange.setEnd(originalRange.startContainer, originalRange.startOffset);
              anchorOffset = anchorPreRange.toString().length;

              const focusPreRange = document.createRange();
              focusPreRange.selectNodeContents(promptInput);
              focusPreRange.setEnd(originalRange.endContainer, originalRange.endOffset);
              focusOffset = focusPreRange.toString().length;
          }
      
          // 遍历所有文本节点进行高亮处理
          const walker = document.createTreeWalker(promptInput, NodeFilter.SHOW_TEXT, null, false);
          const textNodes = [];
          while (walker.nextNode()) textNodes.push(walker.currentNode);
      
          textNodes.forEach(textNode => {
            const content = textNode.nodeValue;
            const parent = textNode.parentNode;
        
            // 移除跳过 SPAN 的判断
            // if (parent.nodeName === 'SPAN') return;
        
            // 创建临时容器处理内容
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = content.replace(/\{\{(.*?)\}\}/g, (match, p1) => {
                const isValid = isValidContent(p1.trim());
                console.log(`Validating "${p1}": ${isValid}`); // 调试日志
                return `<span style="color: ${isValid ? '#4a90e2' : '#e74c3c'}; font-weight: bold;">{{${p1}}}</span>`;
            });
        
            // 清空原节点并插入新内容
            const fragment = document.createDocumentFragment();
            Array.from(tempDiv.childNodes).forEach(node => {
                fragment.appendChild(document.importNode(node, true));
            });
            
            textNode.replaceWith(fragment); // 直接替换原文本节点
        });
      
          // 增强型光标恢复
          if (originalRange && selection.rangeCount > 0) {
            const newRange = restoreCursorPosition(promptInput, anchorOffset, focusOffset);
            if (newRange) {
                selection.removeAllRanges();
                selection.addRange(newRange);
            }
          }
        }
        promptInput.addEventListener('keydown', function(e) {
          if (e.key === 'Enter') {
              e.preventDefault(); // 仅在需要自定义行为时阻止默认
              document.execCommand('insertLineBreak'); // 插入换行
              updateContentHighlighting();
          }
          // 移除箭头键的特殊处理，让浏览器处理默认的光标移动
          // 仅在内容可能发生变化时更新高亮
          if (!['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
              requestAnimationFrame(() => {
                  updateContentHighlighting();
              });
          }
        });
        // 新增独立的光标恢复函数
        function restoreCursorPosition(container, anchorOffset, focusOffset) {
          const range = document.createRange();
          let anchorFound = false;
          let focusFound = false;
          let charCount = 0;

          const nodeStack = [container];
          
          // 深度优先遍历
          while (nodeStack.length > 0 && (!anchorFound || !focusFound)) {
              const node = nodeStack.pop();
              
              if (node.nodeType === Node.TEXT_NODE) {
                  const nodeLength = node.textContent.length;
                  
                  // 锚点定位
                  if (!anchorFound && charCount <= anchorOffset && charCount + nodeLength >= anchorOffset) {
                      range.setStart(node, anchorOffset - charCount);
                      anchorFound = true;
                  }
                  
                  // 焦点定位
                  if (!focusFound && charCount <= focusOffset && charCount + nodeLength >= focusOffset) {
                      range.setEnd(node, focusOffset - charCount);
                      focusFound = true;
                  }
                  
                  charCount += nodeLength;
              } else {
                  // 保留原有结构顺序
                  Array.from(node.childNodes).reverse().forEach(child => {
                      nodeStack.push(child);
                  });
              }
          }
          
          return anchorFound && focusFound ? range : null;
        }
        // 检查内容是否有效
        function isValidContent(name) {
            for (let i = 0; i < Inputs.length; i++) {
                if (Inputs[i].name === name) {
                    return true;
                }
            }
            return false;
        }

        // 插入选中的名称
        function insertSelectedName(name) {
            const selection = window.getSelection();
            const range = selection.getRangeAt(0);

            // 找到光标前最近的 '{{' 位置
            const content = promptInput.innerText;
            const cursorPosition = range.startOffset;
            const lastOpenBrace = content.lastIndexOf('{{', cursorPosition - 1);

            if (lastOpenBrace !== -1 && lastOpenBrace < cursorPosition) {
                const beforeBrace = content.substring(0, lastOpenBrace + 2);
                const afterCursor = content.substring(cursorPosition);
                const newContent = beforeBrace + name + '}}' + afterCursor;

                // 更新内容
                promptInput.innerText = newContent;
                updateContentHighlighting();
                hideQuickOptions();

                // 将光标移动到插入内容之后
                const newPosition = lastOpenBrace + 2 + name.length + 2; // '{{' + name + '}}'
                setCaretPosition(promptInput, newPosition);

                // 更新数据
                let data = graph.save();
                const nodeIndex = data.nodes.findIndex(node => node.id === id);
                data.nodes[nodeIndex].prompt = newContent;
                ChangeDatas(data);
            }
        }

        // 设置光标位置的辅助函数
        function setCaretPosition(el, index) {
            const range = document.createRange();
            const selection = window.getSelection();

            let currentNode = null;
            let currentOffset = 0;
            let found = false;

            function traverseNodes(node) {
                if (found) return;
                if (node.nodeType === Node.TEXT_NODE) {
                    const textLength = node.textContent.length;
                    if (currentOffset + textLength >= index) {
                        currentNode = node;
                        currentOffset = index - currentOffset;
                        found = true;
                    } else {
                        currentOffset += textLength;
                    }
                } else {
                    for (let i = 0; i < node.childNodes.length; i++) {
                        traverseNodes(node.childNodes[i]);
                        if (found) return;
                    }
                }
            }

            traverseNodes(el);

            if (currentNode) {
                range.setStart(currentNode, currentOffset);
                range.collapse(true);
                selection.removeAllRanges();
                selection.addRange(range);
                el.focus();
            }
        }

        function hideQuickOptions() {
            let quickOptions = document.getElementById('quickOptions');
            if (quickOptions) {
                quickOptions.style.display = 'none';
            }
        }

        function showQuickOptions(searchKeyword) {

            let quickOptions = document.getElementById('quickOptions');
            if (!quickOptions) {
                quickOptions = document.createElement('div');
                quickOptions.id = 'quickOptions';
                quickOptions.style.position = 'absolute';
                quickOptions.style.border = '1px solid #ccc';
                quickOptions.style.backgroundColor = '#fff';
                quickOptions.style.zIndex = 1000;
                quickOptions.style.boxShadow = '0px 4px 6px rgba(0, 0, 0, 0.1)'; // 增加阴影
                document.body.appendChild(quickOptions);
            }

            quickOptions.innerHTML = '';
            selectedOptionIndex = -1;

            // 过滤匹配的选项
            const matchedInputs = Inputs.filter(input => input.name.includes(searchKeyword));

            matchedInputs.forEach((input, index) => {
                const option = document.createElement('div');
                option.textContent = input.name;
                option.style.padding = '5px';
                option.style.cursor = 'pointer';
                option.style.borderBottom = '1px solid #eee'; // 增加下边框
                option.setAttribute('data-index', index);
                option.addEventListener('click', function() {
                    insertSelectedName(input.name);
                });
                quickOptions.appendChild(option);
            });

            if (matchedInputs.length === 0) {
                hideQuickOptions();
                return;
            }

            // 获取光标位置
            const coords = getCaretCoordinates();

            if (coords) {
                quickOptions.style.left = `${coords.left + window.scrollX}px`;
                quickOptions.style.top = `${coords.top + window.scrollY + 20}px`; // 调整位置以避免覆盖光标
                quickOptions.style.width = '200px'; // 设置合适的宽度
                quickOptions.style.display = 'block';
            } else {
                hideQuickOptions();
            }
        }

        // 获取光标坐标
        function getCaretCoordinates() {
            const selection = window.getSelection();
            if (!selection.rangeCount) return null;

            const range = selection.getRangeAt(0).cloneRange();
            range.collapse(true);

            let rect = range.getClientRects()[0];
            if (rect) {
                return { left: rect.left, top: rect.top };
            }

            // 如果没有 rect，插入临时元素获取位置
            const span = document.createElement('span');
            span.textContent = '\u200b'; // 零宽度空格字符
            range.insertNode(span);
            rect = span.getBoundingClientRect();
            const spanParent = span.parentNode;
            spanParent.removeChild(span);

            // 清理多余的空白字符
            spanParent.normalize();

            return rect ? { left: rect.left, top: rect.top } : null;
        }

        // 点击其他地方时隐藏选项框
        document.addEventListener('click', function(event) {
            const quickOptions = document.getElementById('quickOptions');
            if (quickOptions && !quickOptions.contains(event.target) && event.target !== promptInput) {
                hideQuickOptions();
            }
        });

        // 调整高度的辅助函数
        function adjustHeightBasedOnContent(el) {
            el.style.height = 'auto';
            el.style.height = (el.scrollHeight) + 'px';
            // 检查高度是否超过了 400px
            if (el.scrollHeight > 400) {
                el.style.height = '400px';
            }
            if (el.scrollHeight < 100) {
                el.style.height = '100px';
            }
        }




        // 监听键盘事件，处理上下键选择和回车键确认
        promptInput.addEventListener('keydown', function(event) {
            const quickOptions = document.getElementById('quickOptions');
            if (quickOptions && quickOptions.style.display === 'block') {
                const options = quickOptions.children;

                if (event.key === 'ArrowDown') {
                    // 向下移动选择
                    if (selectedOptionIndex < options.length - 1) {
                        selectedOptionIndex++;
                    }
                    updateOptionHighlight(options);
                    event.preventDefault(); // 阻止默认的光标移动行为
                } else if (event.key === 'ArrowUp') {
                    // 向上移动选择
                    if (selectedOptionIndex > 0) {
                        selectedOptionIndex--;
                    }
                    updateOptionHighlight(options);
                    event.preventDefault(); // 阻止默认的光标移动行为
                } else if (event.key === 'Enter' || event.key === ' ') { // 用 ' ' 来捕获 Space 键
                  // 回车键或空格键确认选择
                  if (selectedOptionIndex >= 0 && selectedOptionIndex < options.length) {
                      const selectedOption = options[selectedOptionIndex];
                      insertSelectedName(selectedOption.textContent);
                      event.preventDefault(); // 阻止默认的回车或空格行为
                  }
              }
              
            }
        });

        function updateOptionHighlight(options) {
            for (let i = 0; i < options.length; i++) {
                if (i === selectedOptionIndex) {
                    options[i].style.backgroundColor = '#b3d4fc'; // 高亮选中的选项
                } else {
                    options[i].style.backgroundColor = ''; // 重置其他选项
                }
            }
        }

        promptInput.addEventListener('input', function() {
          // 获取当前元素的高度
          const currentHeight = parseFloat(this.style.height);
      
          // 重置高度以计算新的高度
          this.style.height = 'auto';
      
          // 计算新的高度
          const newHeight = this.scrollHeight;
      
          // 设置新的高度，如果当前高度小于400px，遵循400的高度限制
          if (currentHeight > 400) {
            //选择currentHeight与newHeight中的最小值
              this.style.height = `${Math.min(currentHeight, newHeight)}px`;
          } else {
              if (newHeight < 400) {
                  this.style.height = `${Math.min(400, newHeight)}px`;
              } else {
                  this.style.height = '400px';
              }
          }
      });
      
        let IdTemp='';
        addNode.onmousedown = function() {
            let data=graph.save();
            data.nodes.forEach((node) => {
              if(node.id == id)
              {
                IdTemp='Input' + (node.Inputs.length + 1).toString()+Date.now();
                let TempName = 'Input' + (node.Inputs.length + 1).toString();
                let counter = 1; // 新增一个计数器
                // 检查是否重名，如果重名则+1继续检查
                while (node.Inputs.some(input => input.name === TempName)) {
                    TempName = 'Input' + (node.Inputs.length + 1 + counter).toString(); // 使用计数器调整名称
                    counter++; // 每次循环递增计数器
                }
                node.Inputs.push({
                  'Num': null,
                  'Kind': 'String',
                  'Id': IdTemp,
                  'Context': null,
                  'Isnecessary': false,
                  'name': TempName,
                  'Link': 0,
                  'IsLabel': false,
              });
              const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
              node.anchorPoints = node.Inputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.05, anchorHeight / maxHeight]
                }).concat(node.Outputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.95, anchorHeight / maxHeight]
                })).concat([[0, 0]]);
              CreatInputs(node.Inputs[node.Inputs.length - 1],node.Inputs.length - 1,IdTemp);
              ChangeDatas(data);
              }
            });

            RefreshEdge();
          };
        //等比例扩大addNode

        // 确定插入位置并将AddNode插入到inputColumn中
        const nextElement = inputLabel.nextSibling; // 获取inputLabel之后的元素
        if (nextElement) {
            // 如果inputLabel后面有其他元素，则在这个元素之前插入addNode
            inputColumn.insertBefore(addNode, nextElement);
        } else {
            // 如果inputLabel是最后一个元素或inputColumn没有其他子元素，则直接追加
            inputColumn.appendChild(addNode);
        }

      promptContainer.appendChild(promptInput);
      const outputColumn = document.createElement('div');
      outputColumn.className = 'column';
      const addNode1 = document.createElement('div');
      addNode1.className = 'column-AddNode'; // 使用之前定义的样式类
      addNode1.style.left = '60px'; // 设置左边距
      addNode1.style.marginTop = '-35px'; // 设置上边距
      const JsonColumn = document.createElement('div');
      JsonColumn.className = 'column';
      const OriginalTextColumn = document.createElement('div');
      OriginalTextColumn.className = 'column';
      OriginalTextColumn.style.display = 'flex';
      OriginalTextColumn.style.alignItems = 'flex-start'; // 使内容顶部对齐
      OriginalTextColumn.style.flexWrap = 'nowrap'; // 允许子元素换行
      
      JsonColumn.appendChild(addNode1);
      const OutputSelect = document.createElement('select');
      OutputSelect.style.width = '75px'; // 设置固定宽度
      OutputSelect.style.position = 'absolute'; // 设置相对定位
      OutputSelect.style.marginLeft = '-10px'; // 设置左边距
      OutputSelect.style.marginTop = '10px'; // 设置上边距
      
      const optionJson = document.createElement('option');
      optionJson.value = 'Json';
      optionJson.text = 'Json';
      const optionOriginalText = document.createElement('option');
      optionOriginalText.value = 'OriginalText';
      optionOriginalText.text = 'OriginalText';
      OutputSelect.style.left = '100px'; // 设置左边距
      OutputSelect.style.width = '100px'; // 设置固定宽度
      OutputSelect.appendChild(optionJson);
      OutputSelect.appendChild(optionOriginalText);
      OutputSelect.value = OriginalTextSelector;
      
      const outputLabel = document.createElement('div');
      outputLabel.textContent = 'Output'; // 设置文本
      outputLabel.className = 'column-label'; // 设置样式类
      outputColumn.appendChild(outputLabel);
      outputColumn.appendChild(OutputSelect);
      outputColumn.appendChild(JsonColumn);
      outputColumn.appendChild(OriginalTextColumn);
      OutputSelect.addEventListener('change', function() {
        let data = graph.save();
        data.nodes.forEach((node) => {
          if (node.id == id) {
            // 过滤掉与指定 IdTemp 相关的边
            data.edges = data.edges.filter(edge => edge.source !== id);  
          }
        });
        ChangeDatas(data);
        RefreshEdge();
        data = graph.save();
        data.nodes.forEach((node) => {
          if (node.id == id) {
            // 过滤掉与指定 IdTemp 相关的边
            node.OriginalTextSelector = this.value; 
             
          }
        });
        ChangeDatas(data);
        if(this.value=='OriginalText')
        {
          //JsonColumn隐身
          OriginalTextColumn.style.display = 'block';
          JsonColumn.style.display = 'none';
          let data = graph.save();
          data.nodes.forEach((node) => {
            if (node.id == id) {
              node.TempOutPuts=node.Outputs;
              node.Outputs=node.OriginalTextArray;
              const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
              node.anchorPoints = node.Inputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.05, anchorHeight / maxHeight]
                }).concat(node.Outputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.95, anchorHeight / maxHeight]
                })).concat([[0, 0]]); 
                ChangeDatas(data);
            }
          });
        }
        else
        {
          //JsonColumn显示
          OriginalTextColumn.style.display = 'none';
          JsonColumn.style.display = 'block';
          let data = graph.save();
          data.nodes.forEach((node) => {
            if (node.id == id) {
              node.OriginalTextArray=node.Outputs;
              node.Outputs=node.TempOutPuts;
              const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
              node.anchorPoints = node.Inputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.05, anchorHeight / maxHeight]
                }).concat(node.Outputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.95, anchorHeight / maxHeight]
                })).concat([[0, 0]]); 
              ChangeDatas(data);
            }
          });
        }
      });
      // 将输入和输出列添加到节点容器中
      addNode1.onmousedown = function() {
        let data=graph.save();
        data.nodes.forEach((node) => {
          if(node.id == id)
          {
            IdTemp='Output' + (node.Outputs.length + 1).toString()+Date.now();
            let TempName = 'Output' + (node.Inputs.length + 1).toString();
            let counter = 1; // 新增一个计数器
            // 检查是否重名，如果重名则+1继续检查
            while (node.Outputs.some(output => output.name === TempName)) {
                TempName = 'Input' + (node.Outputs.length + 1 + counter).toString(); // 使用计数器调整名称
                counter++; // 每次循环递增计数器
            }
            node.Outputs.push({
              'Num': 0,
              'Kind': 'String',
              'Id': IdTemp,
              'Context': '',
              'Boolean': false,
              'Isnecessary': true,
              'name': TempName,
              'Link': 0,
              'IsLabel': false,
          });
          const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
          node.anchorPoints = node.Inputs.map((node, index) => {
              const anchorHeight = 60 + index * 20;
              return [0.05, anchorHeight / maxHeight]
            }).concat(node.Outputs.map((node, index) => {
              const anchorHeight = 60 + index * 20;
              return [0.95, anchorHeight / maxHeight]
            })).concat([[0, 0]]);
          CreatOutputs(node.Outputs[node.Outputs.length - 1],node.Outputs.length - 1,IdTemp);
          ChangeDatas(data);
          }
        });

        RefreshEdge();
      };
      vessel.appendChild(outputColumn);
      // 添加元素到 DOM
      //#region 
      //创建OriginalTextColumn有关的输入框
      const OriginalTextContainer = document.createElement('div');
      OriginalTextContainer.className = 'output-container';
      OriginalTextContainer.style.display = 'flex';
      OriginalTextContainer.style.alignItems = 'flex-start'; // 使内容顶部对齐
      OriginalTextContainer.style.flexWrap = 'nowrap'; // 允许子元素换行
      const OriginalTextNameLabel = document.createElement('input');
      OriginalTextNameLabel.value = OriginalTextName;
      OriginalTextNameLabel.style.width = '100px'; // 设置宽度
      OriginalTextNameLabel.style.position = 'absolute'; // 设置相对定位
      OriginalTextNameLabel.style.marginLeft = '0px'; // 设置左边距
      OriginalTextNameLabel.style.marginTop = '-10px'; // 设置上边距
      OriginalTextContainer.appendChild(OriginalTextNameLabel);
      OriginalTextColumn.appendChild(OriginalTextContainer);
      outputColumn.appendChild(OriginalTextColumn);
      OriginalTextNameLabel.addEventListener('input', function() {
        ChangeAnchorLabel(id, OriginalTextNameLabel.value,'OriginalText',IdTemp,false);
      });

      if(OriginalTextSelector=='OriginalText')
      {
        OriginalTextColumn.style.display = 'block';
        JsonColumn.style.display = 'none';
      }
      else
      {
        OriginalTextColumn.style.display = 'none';
        JsonColumn.style.display = 'block';
      }

      function CreatOutputs(output, index,IdTemp) {
        const outputContainer = document.createElement('div');
        outputContainer.className = 'output-container';
        outputContainer.style.display = 'flex';
        outputContainer.style.alignItems = 'flex-start'; // 使内容顶部对齐
        outputContainer.style.flexWrap = 'nowrap'; // 允许子元素换行

        // Create an input box to display the output name
        const outputName = document.createElement('input');
        outputName.value = output.name;
        outputName.style.width = '100px'; // Allow it to grow
        outputContainer.appendChild(outputName);

        // Create type selection box
        const Select1 = document.createElement('select');
        Select1.style.width = '75px'; // Set a fixed width
        const optionContext = document.createElement('option');
        optionContext.value = 'String';
        optionContext.text = 'String';
        const optionNum = document.createElement('option');
        optionNum.value = 'Num';
        optionNum.text = 'Num';
        const optionBool = document.createElement('option');
        optionBool.value = 'Boolean';
        optionBool.text = 'Boolean';
        Select1.appendChild(optionContext);
        Select1.appendChild(optionNum);
        Select1.appendChild(optionBool);
        Select1.value = output.Kind;
        outputContainer.appendChild(Select1);
        Select1.addEventListener('change', function() {
          let data = graph.save();
          data.nodes.forEach((node) => {
            if (node.id == id) {
              //切断跟它output有关的边
              node.Outputs.forEach((output,index) => {
                if (output.Id == IdTemp) {
                  output.Kind = this.value;
                }
              }
              );
            }
          }
          );
          ChangeDatas(data);
        });
        // Add description label
        const DescriptionLabel = document.createElement('label');
        DescriptionLabel.textContent = '描述'; // 'Description' in Chinese
        DescriptionLabel.style.flex = '0 0 auto'; // 不允许标签伸缩，保持内容大小
        //字体颜色
        DescriptionLabel.style.color = '#FFFFFF'; // 设置字体颜色以突出显示
        outputContainer.appendChild(DescriptionLabel);

        // 创建描述输入框
        const Description = document.createElement('textarea');
        Description.className = 'Description-textarea'; // Apply the CSS class for styling
        Description.value = output.Description; // Set the value
        

        adjustHeightBasedOnContent(Description);
        Description.oninput = function() {
          adjustHeight(this);
        };
        outputContainer.appendChild(Description);

        // 添加删除按钮
        const SubNode = document.createElement('div');
        SubNode.className = 'column-SubNode'; // 使用之前定义的样式类
        SubNode.style.right = '30px'; // 设置与 Description 之间的间距
        outputContainer.appendChild(SubNode);
        SubNode.onmousedown = function() {//删除这个矛点
          let data=graph.save();
          data.nodes.forEach((node) => {
            if(node.id == id)
            {
              //通过IdTemp删除这个矛点
              node.Outputs.forEach((output,index) => {
                  if(output.Id == IdTemp)
                  {
                    node.Outputs.splice(index,1);
                  }
                }
              );
              const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
              node.anchorPoints = node.Inputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.05, anchorHeight / maxHeight]
                }).concat(node.Outputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.95, anchorHeight / maxHeight]
                })).concat([[0, 0]]);
              ChangeDatas(data);
              //移除outputContainer
              outputContainer.parentNode.removeChild(outputContainer);
            }
          });
          RefreshEdge();
        }
        // Function to resize the textarea according to its content
        Description.addEventListener('input', function() {
          // 重置高度以计算新的高度
          this.style.height = 'auto';
        
          // 设置新的高度
          this.style.height = `${this.scrollHeight}px`;
        });
        outputName.addEventListener('input', function() {
          ChangeAnchorLabel(id, outputName.value, index,output.Id,false); // 假定 id 和 ChangeNodeLabel 已定义
      });

        // suggestions.js
      class SuggestionBox {
        constructor() {
            this.createSuggestionBox();
            this.suggestions = [
                '<@find:"">',
                //'<@extract:"">',
                //'<@match:"">',
                //'<@filter:"">',
                //'<@parse:"">',
                // 添加更多提示选项...
            ];
            this.selectedIndex = -1;
        }

        createSuggestionBox() {
            this.element = document.createElement('div');
            this.element.className = 'suggestion-box';
            document.body.appendChild(this.element);
        }

        show(inputElement, cursorPosition) {
            const rect = inputElement.getBoundingClientRect();
            const coords = this.getCaretCoordinates(inputElement, cursorPosition);
            
            this.element.style.left = `${rect.left + coords.left}px`;
            this.element.style.top = `${rect.top + coords.top + 20}px`;
            this.renderSuggestions();
            this.element.style.display = 'block';
        }

        hide() {
            this.element.style.display = 'none';
            this.selectedIndex = -1;
        }

        renderSuggestions() {
            this.element.innerHTML = this.suggestions
                .map((suggestion, index) => `
                    <div class="suggestion-item ${index === this.selectedIndex ? 'selected' : ''}"
                        data-index="${index}">
                        ${suggestion}
                    </div>
                `).join('');
        }

        attachEvents(inputElement, callback) {
            // 点击选择提示
            this.element.addEventListener('click', (e) => {
                const item = e.target.closest('.suggestion-item');
                if (item) {
                    const suggestion = this.suggestions[item.dataset.index];
                    callback(suggestion);
                    this.hide();
                }
            });

            // 键盘导航
            inputElement.addEventListener('keydown', (e) => {
                if (!this.element.style.display || this.element.style.display === 'none') {
                    return;
                }

                switch(e.key) {
                    case 'ArrowDown':
                        e.preventDefault();
                        this.selectedIndex = Math.min(this.selectedIndex + 1, this.suggestions.length - 1);
                        this.renderSuggestions();
                        break;
                    case 'ArrowUp':
                        e.preventDefault();
                        this.selectedIndex = Math.max(this.selectedIndex - 1, 0);
                        this.renderSuggestions();
                        break;
                    case 'Enter':
                        e.preventDefault();
                        if (this.selectedIndex >= 0) {
                            callback(this.suggestions[this.selectedIndex]);
                            this.hide();
                        }
                        break;
                    case 'Escape':
                        this.hide();
                        break;
                }
            });

            // 点击其他地方关闭提示框
            document.addEventListener('click', (e) => {
                if (!this.element.contains(e.target) && e.target !== inputElement) {
                    this.hide();
                }
            });
        }

        getCaretCoordinates(element, position) {
            const div = document.createElement('div');
            const style = getComputedStyle(element);
            const properties = [
                'direction', 'boxSizing', 'width', 'height', 'overflowX', 'overflowY',
                'borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth',
                'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft',
                'fontStyle', 'fontVariant', 'fontWeight', 'fontStretch', 'fontSize',
                'fontSizeAdjust', 'lineHeight', 'fontFamily', 'textAlign', 'textTransform',
                'textIndent', 'textDecoration', 'letterSpacing', 'wordSpacing'
            ];

            div.style.position = 'absolute';
            div.style.visibility = 'hidden';
            properties.forEach(prop => div.style[prop] = style[prop]);

            div.textContent = element.value.substring(0, position);
            const span = document.createElement('span');
            span.textContent = element.value.substring(position) || '.';
            div.appendChild(span);
            document.body.appendChild(div);

            const coordinates = {
                top: span.offsetTop,
                left: span.offsetLeft
            };

            document.body.removeChild(div);
            return coordinates;
        }
      }

      // 使用示例
      const suggestionBox = new SuggestionBox();

      Description.addEventListener('input', function(e) {
        const cursorPosition = this.selectionStart;
        const textBeforeCursor = this.value.substring(0, cursorPosition);
        let data = graph.save();
          data.nodes.forEach((node) => {
            if (node.id == id) {
              if(node.name.includes('Contextadd'))
              {
                Description.value
              }
              let Temp='' ;
              Temp+='Please ensure the output is in JSON format\n';
                  Temp+='{\n';
              node.Outputs.forEach((output,index) => {
                  if(output.Id == IdTemp)
                    output.Description = Description.value;
                  let Kind='';
                  if(output.Kind.includes('String'))
                    Kind='String';
                  else if(output.Kind=='Num')
                    Kind='Num';
                  else if(output.Kind=='Boolean')
                    Kind='Boolean';
                  Temp+='"'+output.Id+'"' + ':' + '"'+output.Description+'"' +'(you need output type:'+Kind+')'+ '\n';

              });
             Temp+='}\n';
              node.ExprotAfterPrompt = Temp;
              ChangeDatas(data);
            }
          });
        if (textBeforeCursor.endsWith('<@')) {
            suggestionBox.show(this, cursorPosition);
        } else if (!textBeforeCursor.endsWith('<')) {
            suggestionBox.hide();
        }
      });

      suggestionBox.attachEvents(Description, (selectedSuggestion) => {
        const cursorPosition = Description.selectionStart;
        const newValue = Description.value.substring(0, cursorPosition - 2) + 
                        selectedSuggestion + 
                        Description.value.substring(cursorPosition);
        Description.value = newValue;
        
        // 触发原有的数据处理逻辑
        let data = graph.save();
          data.nodes.forEach((node) => {
            if (node.id == id) {
              if(node.name.includes('Contextadd'))
              {
                Description.value
              }
              let Temp='' ;
              Temp+='Please ensure the output is in JSON format\n';
                  Temp+='{\n';
              node.Outputs.forEach((output,index) => {
                  if(output.Id == IdTemp)
                    output.Description = Description.value;
                  let Kind='';
                  if(output.Kind.includes('String'))
                    Kind='String';
                  else if(output.Kind=='Num')
                    Kind='Num';
                  else if(output.Kind=='Boolean')
                    Kind='Boolean';
                  Temp+='"'+output.Id+'"' + ':' + '"'+output.Description+'"' +'(you need output type:'+Kind+')'+ '\n';

              });
             Temp+='}\n';
              node.ExprotAfterPrompt = Temp;
              ChangeDatas(data);
            }
          });
      });
        JsonColumn.appendChild(outputContainer);
        outputColumn.appendChild(JsonColumn);
      }

      function CreatInputs(input,index,IdTemp)
      {
        const inputContainer = document.createElement('div');
        inputContainer.className = 'input-container';

        // 创建显示输入名称的输入框
        const inputName = document.createElement('input');
        inputName.value = input.name;
        inputContainer.appendChild(inputName);

        // 创建选择框
        const selectBox = document.createElement('select');
        const optionLink = document.createElement('option');
        optionLink.value = 'link';
        optionLink.text = 'Link';
        const optionLabel = document.createElement('option');
        optionLabel.value = 'Input';
        optionLabel.text = 'Input';
        selectBox.appendChild(optionLink);
        selectBox.appendChild(optionLabel);
        inputContainer.appendChild(selectBox);

        const Select1=document.createElement('select');
        const optionContext = document.createElement('option');
        optionContext.value = 'String';
        optionContext.text = 'String';
        const optionNum = document.createElement('option');
        optionNum.value = 'Num';
        optionNum.text = 'Num';
        const optionBool = document.createElement('option');
        optionBool.value = 'Boolean';
        optionBool.text = 'Boolean';
        const optionFilePath = document.createElement('option');
        optionFilePath.value = 'String_FilePath';
        optionFilePath.text = 'FilePath';
        Select1.appendChild(optionContext);
        Select1.appendChild(optionNum);
        Select1.appendChild(optionBool);
        Select1.appendChild(optionFilePath);
        let pathButton;
        //Select1选择input.Kind的值匹配
        Select1.selectedIndex = 2;
        inputContainer.appendChild(Select1);
        Select1.addEventListener('change', function() {
          let data = graph.save();
          data.nodes.forEach((node) => {
            if (node.id == id) {
              node.Inputs.forEach((input,index) => {
                if (input.Id == IdTemp) {
                  input.Kind = this.value;
                  if(this.value=='String_FilePath' && input.IsLabel==true)
                    {
                      // 创建路径按钮
                      pathButton = document.createElement('button');
                      pathButton.textContent = 'Selecte Path';
                      // 文件选择逻辑
                      pathButton.addEventListener('click', function () {
                        CreatFilePath(input.Id,id);

                      });
                      inputContainer.appendChild(pathButton);
                    }
                    else
                    {
                      if (pathButton && inputContainer.contains(pathButton)) {
                        inputContainer.removeChild(pathButton);
                        pathButton = null;
                      }                    
                    }
                }
                
              }
              );
            }
          }
          );
          ChangeDatas(data);
        });
        const SubNode = document.createElement('div');
        SubNode.className = 'column-SubNode'; // 使用之前定义的样式类
        SubNode.style.left = '310px'; // 设置与标签之间的间距
        inputContainer.appendChild(SubNode);
        SubNode.onmousedown = function() {//删除这个矛点
          let data=graph.save();
          data.nodes.forEach((node) => {
            if(node.id == id)
            {
              //通过IdTemp删除这个矛点
              node.Inputs.forEach((input,index) => {
                  if(input.Id == IdTemp)
                  {
                    node.Inputs.splice(index,1);
                  }
                });
              const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
              node.anchorPoints = node.Inputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.05, anchorHeight / maxHeight]
                }).concat(node.Outputs.map((node, index) => {
                  const anchorHeight = 60 + index * 20;
                  return [0.95, anchorHeight / maxHeight]
                })).concat([[0, 0]]);
              ChangeDatas(data);

              //移除inputContainer
              inputContainer.parentNode.removeChild(inputContainer);
            }
          });
          RefreshEdge();

        }

        Select1.value = input.Kind;
        let labelTextarea = document.createElement('textarea'); // Declare variable externally for access in different scope
        // Append the textarea to the desired parent element
        document.body.appendChild(labelTextarea); // You can change the parent element to where you want to append the textarea
        if(input.IsLabel==true)
        {
          selectBox.value = 'Input';
          handleChange('Input');
        }
        // 处理选择框变化
        function handleChange(value) {
            // 如果之前添加了文本区域且现在选择是“Link”，则移除文本区域
            let data = graph.save();
            data.edges.forEach(edge => {
              if (edge.target==id && edge.targetAnchor==index) {
                const item = graph.findById(edge.id);
                const targetNode = graph.findById(edge.target);
                const targetAnchor = targetNode.getContainer().find(ele => ele.get('anchorPointIdx') === edge.targetAnchor);
                targetAnchor.set('links', targetAnchor.get('links') + 1);
                ChangeLink(targetAnchor);
                graph.remove(item);
              }
            });
            if (labelTextarea && value === 'link') {
                inputContainer.removeChild(labelTextarea);
                if (pathButton && inputContainer.contains(pathButton)) {
                  inputContainer.removeChild(pathButton);
                  labelTextarea = null; // 确保引用被清除
                }
                ChangeAnchorValue(id, '', 'link',input.Id);
            } else if (value === 'Input') {
                // 如果当前选择是“Input”，则添加文本区域
                labelTextarea = document.createElement('textarea');
                if(input.Kind == 'Num')
                labelTextarea.value = input.Num;
                else if(input.Kind .includes('String'))
                labelTextarea.value = input.Context;
                if(input.Kind.includes('FilePath'))
                {
                  labelTextarea.style.width = '490px'; // 设置固定宽度
                }
                else
                {
                  labelTextarea.style.width = '550px'; // 设置固定宽度
                }
                labelTextarea.style.height = '50px'; // 初始高度
                let uniqueClass = `unique-textarea-${id}-${input.Id}`;
                labelTextarea.className = 'normalInput-textarea ' + uniqueClass; // 同时设置两个类名
                labelTextarea.classList.add(uniqueClass); // Add the unique class name to the textarea
                //labelTextarea.style.resize = 'none'; // 禁止用户手动调整大小
                ChangeAnchorValue(id, labelTextarea.value, 'Input',input.Id);
                labelTextarea.addEventListener('input', function() {
                let isOk = true; // 假定输入无效
                if(input.Kind == 'Num') {
                  if(labelTextarea.value.match(/^[0-9]+$/))
                  {
                    isOk = true; // 如果是，将isOk设置为true，表示输入有
                  }
                  else {
                    // 如果上述条件都不满足，则弹出提示窗口告知用户输入格式不正确
                    isOk = false;
                    alert("类型不符，您应该输入数字！");
                  }
                }
                if (labelTextarea.value.trim() === '') {
                    isOk = false; // 如果输入为空，则将isOk设置为false，表示输入无效
                    alert("输入不能为空！");
                }
                  if (isOk) {
                    ChangeAnchorValue(id, labelTextarea.value, 'Input',input.Id); // 假定 id 和 ChangeNodeLabel 已定义
                  }

              });
                labelTextarea.addEventListener('input', function() {
                  // 重置高度以计算新的高度
                  this.style.height = 'auto';
                
                  // 设置新的高度
                  this.style.height = `${this.scrollHeight}px`;
                });
                inputContainer.appendChild(labelTextarea);
                if(input.Kind.includes('FilePath'))
                {
                  // 创建路径按钮
                  pathButton = document.createElement('button');
                  pathButton.textContent = 'Selecte Path';
                  // 文件选择逻辑
                  
                  pathButton.addEventListener('click', function () {
                    CreatFilePath(input.Id,id);

                  });
                  inputContainer.appendChild(pathButton);
                }
            }
        }
        selectBox.addEventListener('change', function() {
          handleChange(this.value);
        });
        Select1.addEventListener('change', function() {

        });
        // 为输入框添加 blur 监听器
        inputName.addEventListener('input', function() {
            ChangeAnchorLabel(id, inputName.value, index,input.Id,true); // 假定 id 和 ChangeNodeLabel 已定义
        });

        inputColumn.appendChild(inputContainer);
        RefreshEdge();
      }
      // 假设Inputs是已定义的
    Inputs.forEach((input, index) => {
        CreatInputs(input,index,input.Id);
    });
    Outputs.forEach((output, index) => {
        CreatOutputs(output,index,output.Id);
    });

    }
    else if(NodeKind=='IfNode')
    {
        const inputColumn = document.createElement('div');
          inputColumn.className = 'column';
          const inputLabel = document.createElement('div');
          inputLabel.textContent = 'Input'; // 设置文本
          inputLabel.className = 'column-label'; // 设置样式类
          inputColumn.appendChild(inputLabel);
          const addNode = document.createElement('div');
          addNode.className = 'column-AddNode'; // 使用之前定义的样式类
          vessel.appendChild(inputColumn);
          // 调整textarea高度以适应内容

          // 输入框空格键增长逻辑
          let IdTemp='';
          addNode.onmousedown = function() {
              let data=graph.save();
              data.nodes.forEach((node) => {
                if(node.id == id)
                {
                    IdTemp='Input' + (node.Inputs.length + 1).toString()+Date.now();
                    let TempName = 'Input' + (node.Inputs.length + 1).toString();
                    let counter = 1; // 新增一个计数器
                    // 检查是否重名，如果重名则+1继续检查
                    while (node.Inputs.some(input => input.name === TempName)) {
                        TempName = 'Input' + (node.Inputs.length + 1 + counter).toString(); // 使用计数器调整名称
                        counter++; // 每次循环递增计数器
                    }
                    node.Inputs.push({
                      'Num': null,
                      'Kind': 'String',
                      'Id': IdTemp,
                      'Context': null,
                      'Isnecessary': false,
                      'name': TempName,
                      'Link': 0,
                      'IsLabel': false,
                  });
                  const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
                  node.anchorPoints = node.Inputs.map((node, index) => {
                      const anchorHeight = 60 + index * 20;
                      return [0.05, anchorHeight / maxHeight]
                    }).concat(node.Outputs.map((node, index) => {
                      const anchorHeight = 60 + index * 20;
                      return [0.95, anchorHeight / maxHeight]
                    })).concat([[0, 0]]);
                  CreatInputs(node.Inputs[node.Inputs.length - 1],node.Inputs.length - 1,IdTemp);
                  ChangeDatas(data);
                }
              });

              RefreshEdge();

            };
          //等比例扩大addNode

          // 确定插入位置并将AddNode插入到inputColumn中
          const nextElement = inputLabel.nextSibling; // 获取inputLabel之后的元素
          if (nextElement) {
              // 如果inputLabel后面有其他元素，则在这个元素之前插入addNode
              inputColumn.insertBefore(addNode, nextElement);
          } else {
              // 如果inputLabel是最后一个元素或inputColumn没有其他子元素，则直接追加
              inputColumn.appendChild(addNode);
          }
        const outputColumn = document.createElement('div');
        outputColumn.className = 'column';
        const addNode1 = document.createElement('div');
        addNode1.className = 'column-AddNode'; // 使用之前定义的样式类
        addNode1.style.left = '60px'; // 设置左边距
        outputColumn.appendChild(addNode1);
        const outputLabel = document.createElement('div');
        outputLabel.textContent = 'Output'; // 设置文本
        outputLabel.className = 'column-label'; // 设置样式类
        outputColumn.appendChild(outputLabel);
        // 将输入和输出列添加到节点容器中
        addNode1.onmousedown = function() {
          let data=graph.save();
          data.nodes.forEach((node) => {
            if(node.id == id)
            {
              IdTemp='Output' + (node.Outputs.length + 1).toString()+Date.now();
              let TempName = 'Output' + (node.Outputs.length + 1).toString();
              let counter = 1; // 新增一个计数器
              // 检查是否重名，如果重名则+1继续检查
              while (node.Outputs.some(output => output.name === TempName)) {
                  TempName = 'Output' + (node.Outputs.length + 1 + counter).toString(); // 使用计数器调整名称
                  counter++; // 每次循环递增计数器
              }
              node.Outputs.push({
                'Num': 0,
                'Kind': 'Trigger',
                'Id': IdTemp,
                'Context': '',
                'Boolean': false,
                'Isnecessary': true,
                'name': TempName,
                'Link': 0,
                'IsLabel': false,
            });
            const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
            node.anchorPoints = node.Inputs.map((node, index) => {
                const anchorHeight = 60 + index * 20;
                return [0.05, anchorHeight / maxHeight]
              }).concat(node.Outputs.map((node, index) => {
                const anchorHeight = 60 + index * 20;
                return [0.95, anchorHeight / maxHeight]
              })).concat([[0, 0]]);
            CreatOutputs(node.Outputs[node.Outputs.length - 1],node.Outputs.length - 1,IdTemp);
            ChangeDatas(data);
            }
          });

          RefreshEdge();
        };
        vessel.appendChild(outputColumn);
        // 添加元素到 DOM
        function CreatOutputs(output, index,IdTemp) {
          const outputContainer = document.createElement('div');
          outputContainer.className = 'output-container';
          outputContainer.style.display = 'flex';
          outputContainer.style.alignItems = 'flex-start'; // 内容顶部对齐
          outputContainer.style.flexWrap = 'wrap'; // 允许子元素换行

          // Create an input box to display the output name
          const outputName = document.createElement('input');
          outputName.value = output.name;
          outputName.style.width = '100px'; // 设置固定宽度
          outputName.style.marginBottom = '5px'; // 增加10px的下边距，增加行距
          outputContainer.appendChild(outputName);

          // 添加一个宽度为100%的透明div来强制换行
          const newLineDiv = document.createElement('div');
          newLineDiv.style.width = '100%'; // 设置宽度为100%
          newLineDiv.style.height = '0'; // 高度设置为0，使其不影响视觉效果
          outputContainer.appendChild(newLineDiv);

          // Create type selection box
          const Label1 = document.createElement('label');
          Label1.textContent = '变量值'; // 'Description' in Chinese
          Label1.style.flex = '0 0 auto'; // 不允许标签伸缩，保持内容大小
          //字体颜色
          Label1.style.color = '#FFFFFF'; // 设置字体颜色以突出显示
          outputContainer.appendChild(Label1);
          const Select1 = document.createElement('select');
          Select1.style.width = '75px'; // 设置固定宽度
          outputContainer.appendChild(Select1);
          Inputs.forEach((input,index) => {
            const option = document.createElement('option');
            option.value = input.name;
            option.text = input.name;
            Select1.appendChild(option);
          });
          Select1.value = null;
          creatSubNode();
          if(output.selectBox1!=null)
            {
              Select1.value = output.selectBox1;
              CreatCondition(output);
            }
          function creatSubNode()
          {
            const SubNode = document.createElement('div');
            SubNode.className = 'column-SubNode'; // 使用之前定义的样式类
            SubNode.style.left = '120px'; // 设置与 Description 之间的间距
            outputContainer.appendChild(SubNode);
            SubNode.onmousedown = function() {//删除这个矛点
              let data=graph.save();
              data.nodes.forEach((node) => {
                if(node.id == id)
                {
                  //通过IdTemp删除这个矛点
                  node.Outputs.forEach((output,index) => {
                      if(output.Id == IdTemp)
                      {
                        node.Outputs.splice(index,1);
                      }
                    }
                  );
                  const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
                  node.anchorPoints = node.Inputs.map((node, index) => {
                      const anchorHeight = 60 + index * 20;
                      return [0.05, anchorHeight / maxHeight]
                    }).concat(node.Outputs.map((node, index) => {
                      const anchorHeight = 60 + index * 20;
                      return [0.95, anchorHeight / maxHeight]
                    })).concat([[0, 0]]);
                  ChangeDatas(data);
                  //移除outputContainer
                  outputContainer.parentNode.removeChild(outputContainer);
                }
              });
              RefreshEdge();
            }
          }

          if(output.selectBox1!=null)
          {
            Inputs.forEach((input,index) => {
              if(input.name==output.selectBox1)
              {
                Select1.value = input.name;
                CreatCondition(input);
              }
            });
          }

          Select1.addEventListener('click', function() {
            //清除所有的option
            const Templabel = Select1.value;
            while(Select1.options.length>0)
            {
              Select1.options.remove(0);
            }
            Inputs.forEach((input,index) => {
              const option = document.createElement('option');
              option.value = input.name;
              option.text = input.name;
              Select1.appendChild(option);
            });
            Select1.value = Templabel;
          });
          function CreatCondition(input)
          {
            const Tempdata1=graph.save();
            let NodeNum=-1;
            Tempdata1.nodes.forEach((node) => {
              if(node.id == id)
              {
                NodeNum=node.Inputs.findIndex(input => input.name == Select1.value);
              }
            });
            output.selectNum=NodeNum;
            if(input.Kind == 'Boolean')
            {
              const DescriptionLabel = document.createElement('label');
              DescriptionLabel.textContent = '条件'; // 'Description' in Chinese
              DescriptionLabel.style.flex = '0 0 auto'; // 不允许标签伸缩，保持内容大小
              DescriptionLabel.style.color = '#FFFFFF'; // 设置字体颜色以突出显示
              outputContainer.appendChild(DescriptionLabel);
              output.selectBox1=input.name;

              const selectBox = document.createElement('select');
              const option1 = document.createElement('option');
              option1.value = 'true';
              option1.text = 'true';
              const option2 = document.createElement('option');
              option2.value = 'false';
              option2.text = 'false';
              selectBox.appendChild(option1);
              selectBox.appendChild(option2);
              outputContainer.appendChild(selectBox);
              selectBox.value = output.selectBox2;
              creatSubNode();
              selectBox.addEventListener('change', function() {
                let data = graph.save();
                data.nodes.forEach((node) => {
                  if (node.id == id) {
                    node.Outputs.forEach((output,index) => {
                      if (output.Id == IdTemp) {
                        output.selectBox2=selectBox.value;
                        output.selectKind='Boolean';
                      }
                    }
                    );
                  }
                }
                );
                ChangeDatas(data);
              });
              outputName.addEventListener('input', function() {
                ChangeAnchorLabel(id, outputName.value, index,output.Id,false); // 假定 id 和 ChangeNodeLabel 已定义
              });
            }
            if(input.Kind == 'Num')
            {
              const DescriptionLabel = document.createElement('label');
              DescriptionLabel.textContent = '条件'; // 'Description' in Chinese
              DescriptionLabel.style.flex = '0 0 auto'; // 不允许标签伸缩，保持内容大小
              //字体颜色
              DescriptionLabel.style.color = '#FFFFFF'; // 设置字体颜色以突出显示
              outputContainer.appendChild(DescriptionLabel);
              output.selectBox1=input.name;
              // 创建选择框
              const selectBox = document.createElement('select');
              const option1 = document.createElement('option');
              option1.value = '>';
              option1.text = '>';
              const option2 = document.createElement('option');
              option2.value = '<';
              option2.text = '<';
              const option3 = document.createElement('option');
              option3.value = '==';
              option3.text = '==';
              const option4 = document.createElement('option');
              option4.value = '>=';
              option4.text = '>=';
              const option5 = document.createElement('option');
              option5.value = '<=';
              option5.text = '<=';
              const option6 = document.createElement('option');
              option5.value = '!=';
              option5.text = '!=';
              selectBox.appendChild(option1);
              selectBox.appendChild(option2);
              selectBox.appendChild(option3);
              selectBox.appendChild(option4);
              selectBox.appendChild(option5);
              selectBox.appendChild(option6);
              outputContainer.appendChild(selectBox);
              selectBox.value = output.selectBox2;
              creatSubNode();
              selectBox.addEventListener('change', function() {
                let data = graph.save();
                data.nodes.forEach((node) => {
                  if (node.id == id) {
                    node.Outputs.forEach((output,index) => {
                      if (output.Id == IdTemp) {
                        output.selectBox2=selectBox.value;
                        output.selectKind='Num';
                      }
                    }
                    );
                  }
                }
                );
                ChangeDatas(data);
              });
              // 创建描述输入框
              const Description = document.createElement('textarea');
              Description.style.minWidth = '150px'; // 设置最小宽度，确保有足够的输入空间
              Description.style.height = '20px'; // 初始高度
              Description.style.marginLeft = '10px'; // 设置与前一个元素之间的间距
              Description.style.overflow = 'hidden'; // 防止滚动条出现
              Description.style.verticalAlign = 'top'; // 输入行字符居上
              Description.style.lineHeight = '20px'; // 设置行高以匹配初始高度
              //Description.style.resize = 'none'; // 禁止用户手动调整大小
              Description.style.resize = 'vertical';
              Description.value = output.Description; // 假设 output.Description 是你想设置的值
              adjustHeightBasedOnContent(Description);
              Description.oninput = function() {
                adjustHeight(this);
              };
              outputContainer.appendChild(Description);
              if(output.selectBox3!=null)
              {
                Description.value = output.selectBox3;
              }
              // 添加删除按钮
              outputName.addEventListener('input', function() {
                ChangeAnchorLabel(id, outputName.value, index,output.Id,false); // 假定 id 和 ChangeNodeLabel 已定义
              });
              Description.addEventListener('input', function() {
                let data = graph.save();
                data.nodes.forEach((node) => {
                  if (node.id == id) {
                    node.Outputs.forEach((output,index) => {
                      if (output.Id == IdTemp) {
                        //判定是否为阿拉伯数字
                        if(Description.value.match(/^[0-9]+$/))
                        {
                          output.selectBox3=Description.value;
                        }
                        else
                        {
                          alert("类型不符，您应该输入数字！");
                        }
                      }
                    });
                  }
                });
                ChangeDatas(data);
              });
            }
            if(input.Kind .includes('String'))
            {
                const DescriptionLabel = document.createElement('label');
                DescriptionLabel.textContent = '条件'; // 'Description' in Chinese
                DescriptionLabel.style.flex = '0 0 auto'; // 不允许标签伸缩，保持内容大小
                //字体颜色
                DescriptionLabel.style.color = '#FFFFFF'; // 设置字体颜色以突出显示
                outputContainer.appendChild(DescriptionLabel);
                output.selectBox1=input.name;
                // 创建选择框
                const selectBox = document.createElement('select');
                const option1 = document.createElement('option');
                option1.value = 'exclude';
                option1.text = 'Exclude';
                const option2 = document.createElement('option');
                option2.value = 'include';
                option2.text = 'Include';
                const option3 = document.createElement('option');
                option3.value = 'empty';
                option3.text = 'Empty';
                const option4 = document.createElement('option');
                option4.value = 'no empty';
                option4.text = 'No Empty';
                selectBox.appendChild(option1);
                selectBox.appendChild(option2);
                selectBox.appendChild(option3);
                selectBox.appendChild(option4);
                outputContainer.appendChild(selectBox);
                selectBox.value = output.selectBox2;
                creatSubNode();
                selectBox.addEventListener('change', function() {
                  let data = graph.save();
                  data.nodes.forEach((node) => {
                    if (node.id == id) {
                      node.Outputs.forEach((output,index) => {
                        if (output.Id == IdTemp) {
                          output.selectBox2=selectBox.value;
                          output.selectKind='String';
                        }
                      }
                      );
                    }
                  }
                  );
                  ChangeDatas(data);
                });
                // 创建描述输入框
                const Description = document.createElement('textarea');
                Description.style.minWidth = '150px'; // 设置最小宽度，确保有足够的输入空间
                Description.style.height = '20px'; // 初始高度
                Description.style.marginLeft = '10px'; // 设置与前一个元素之间的间距
                Description.style.overflow = 'hidden'; // 防止滚动条出现
                Description.style.verticalAlign = 'top'; // 输入行字符居上
                Description.style.lineHeight = '20px'; // 设置行高以匹配初始高度
                //Description.style.resize = 'none'; // 禁止用户手动调整大小
                Description.style.resize = 'vertical';
                Description.value = output.Description; // 假设 output.Description 是你想设置的值

                adjustHeightBasedOnContent(Description);
                Description.oninput = function() {
                  adjustHeight(this);
                };
                outputContainer.appendChild(Description);
                if(output.selectBox3!=null)
                {
                  Description.value = output.selectBox3;
                }
                // 添加删除按钮
                // Function to resize the textarea according to its content
                outputName.addEventListener('input', function() {
                  ChangeAnchorLabel(id, outputName.value, index,output.Id,false); // 假定 id 和 ChangeNodeLabel 已定义
              });


                Description.addEventListener('input', function() {

                  let data = graph.save();
                  data.nodes.forEach((node) => {
                    if (node.id == id) {
                      node.Outputs.forEach((output,index) => {
                          if(output.Id == IdTemp)
                            output.selectBox3 = Description.value;
                      });
                      ChangeDatas(data);
                    }
                  });
                });
              }
          }
          Select1.addEventListener('change', function() {
            let data = graph.save();
            //清除outputContainer除Select1与Label1以外的所有的子元素
            let child = outputContainer.lastElementChild;
            while (child) {
                // 在进入下一个循环前保存上一个元素
                const prev = child.previousElementSibling;

                // 检查当前元素是否不是 Select1 和 Label1
                if (child !== Select1 && child !== Label1 && child !== outputName && child !== newLineDiv) {
                    outputContainer.removeChild(child);
                }

                // 更新 child 为之前的元素
                child = prev;
            }
            data.nodes.forEach((node) => {
              if (node.id == id) {
                node.Outputs.forEach((output,index) => {
                  if (output.Id == IdTemp) {
                    output.selectBox1 = this.value;
                    node.Inputs.forEach((input,index) => {
                      if(input.name == Select1.value)
                      {
                        CreatCondition(input);
                      }
                    });


                  }
                }
                );
              }
            }
            );
            ChangeDatas(data);
          });
          // Add description label


          outputColumn.appendChild(outputContainer);
        }

        function CreatInputs(input,index,IdTemp)
        {
          const inputContainer = document.createElement('div');
          inputContainer.className = 'input-container';

          // 创建显示输入名称的输入框
          const inputName = document.createElement('input');
          inputName.value = input.name;
          inputContainer.appendChild(inputName);

          // 创建选择框
          const selectBox = document.createElement('select');
          const optionLink = document.createElement('option');
          optionLink.value = 'link';
          optionLink.text = 'Link';
          const optionLabel = document.createElement('option');
          optionLabel.value = 'Input';
          optionLabel.text = 'Input';
          selectBox.appendChild(optionLink);
          selectBox.appendChild(optionLabel);
          inputContainer.appendChild(selectBox);

          const Select1=document.createElement('select');
          const optionContext = document.createElement('option');
          optionContext.value = 'String';
          optionContext.text = 'String';
          const optionNum = document.createElement('option');
          optionNum.value = 'Num';
          optionNum.text = 'Num';
          const optionBool = document.createElement('option');
          optionBool.value = 'Boolean';
          optionBool.text = 'Boolean';
          Select1.appendChild(optionContext);
          Select1.appendChild(optionNum);
          Select1.appendChild(optionBool);
          //Select1选择input.Kind的值匹配
          Select1.selectedIndex = 2;
          inputContainer.appendChild(Select1);
          function RefreshOutput() {
            // 确保outputColumn是已定义的，并且开始清理操作
            if (outputColumn) {
                // 获取所有子元素
                let children = outputColumn.children;
                // 从后往前遍历子元素，以便安全删除元素
                for (let i = children.length - 1; i >= 0; i--) {
                    // 假设我们用className来识别是否是addNode1
                    if (children[i].className !== 'column-AddNode' && children[i].className !== 'column-label') {
                        outputColumn.removeChild(children[i]); // 删除不是addNode1的元素
                    }
                }
            }

            // 这里添加Outputs中的addNode1元素，或其他处理逻辑
            Outputs.forEach((output, index) => {
                // 检查是否是我们需要添加的特定节点addNode1
                  CreatOutputs(output, index, output.Id);
            });
        }


        // 假设Outputs是全局变量，如果不是，需要确保它在这个函数中是可访问的

          Select1.addEventListener('change', function() {
            let data = graph.save();
            data.nodes.forEach((node) => {
              if (node.id == id) {
                node.Inputs.forEach((input,index) => {
                  if (input.Id == IdTemp) {
                    input.Kind = this.value;
                    RefreshOutput();
                  }
                }
                );
              }
            }
            );
            ChangeDatas(data);
          }
          );
          const SubNode = document.createElement('div');
          SubNode.className = 'column-SubNode'; // 使用之前定义的样式类
          SubNode.style.left = '310px'; // 设置与标签之间的间距
          inputContainer.appendChild(SubNode);
          SubNode.onmousedown = function() {//删除这个矛点
            let data=graph.save();
            data.nodes.forEach((node) => {
              if(node.id == id)
              {
                //通过IdTemp删除这个矛点
                node.Inputs.forEach((input,index) => {
                    if(input.Id == IdTemp)
                    {
                      node.Inputs.splice(index,1);
                      RefreshOutput();
                    }
                  }
                );
                const maxHeight = Math.max(node.Inputs.length, node.Outputs.length) * 20 + 60
                node.anchorPoints = node.Inputs.map((node, index) => {
                    const anchorHeight = 60 + index * 20;
                    return [0.05, anchorHeight / maxHeight]
                  }).concat(node.Outputs.map((node, index) => {
                    const anchorHeight = 60 + index * 20;
                    return [0.95, anchorHeight / maxHeight]
                  })).concat([[0, 0]]);
                ChangeDatas(data);
                //移除inputContainer
                inputContainer.parentNode.removeChild(inputContainer);
              }
            });
            RefreshEdge();
          }

          Select1.value = input.Kind;
          let labelTextarea = document.createElement('textarea'); // 在外部声明变量以便在不同的作用域中访问
          labelTextarea.className = 'normalInput-textarea';
          if(input.IsLabel==true)
          {
            selectBox.value = 'Input';
            handleChange('Input');
          }
          // 处理选择框变化
          function handleChange(value) {
              // 如果之前添加了文本区域且现在选择是“Link”，则移除文本区域
              let data = graph.save();
              data.edges.forEach(edge => {
                if (edge.target==id && edge.targetAnchor==index) {
                  const item = graph.findById(edge.id);
                  const targetNode = graph.findById(edge.target);
                  const targetAnchor = targetNode.getContainer().find(ele => ele.get('anchorPointIdx') === anchorIndex);
                  targetAnchor.set('links', targetAnchor.get('links') + 1);
                  ChangeLink(targetAnchor);
                  graph.remove(item);
                }
              });
              if (labelTextarea && value === 'link') {
                  inputContainer.removeChild(labelTextarea);
                  labelTextarea = null; // 确保引用被清除
                  ChangeAnchorValue(id, '', 'link',input.Id);
              } else if (value === 'Input') {
                  // 如果当前选择是“Input”，则添加文本区域
                  labelTextarea = document.createElement('textarea'); // 在外部声明变量以便在不同的作用域中访问
                  labelTextarea.className = 'normalInput-textarea';
                  if(input.Kind == 'Num')
                  labelTextarea.value = input.Num;
                  else if(input.Kind .includes('String'))
                  labelTextarea.value = input.Context;
                  labelTextarea.style.width = '550px'; // 设置固定宽度
                  labelTextarea.style.height = '50px'; // 初始高度
                  let uniqueClass = `unique-textarea-${id}-${input.Id}`;
                  labelTextarea.className = 'normalInput-textarea ' + uniqueClass; // 同时设置两个类名
                  labelTextarea.id = uniqueClass;
                  labelTextarea.classList.add(uniqueClass); // 为文本区域添加唯一类名
                  //labelTextarea.style.resize = 'none'; // 禁止用户手动调整大小
                  labelTextarea.addEventListener('input', function() {
                  let isOk = true; // 假定输入无效
                  if(input.Kind == 'Num') {
                    if(labelTextarea.value.match(/^[0-9]+$/))
                    {
                      isOk = true; // 如果是，将isOk设置为true，表示输入有
                    }
                    else {
                      // 如果上述条件都不满足，则弹出提示窗口告知用户输入格式不正确
                      isOk = false;
                      alert("类型不符，您应该输入数字！");
                    }
                  }
                  if (labelTextarea.value.trim() === '') {
                      isOk = false; // 如果输入为空，则将isOk设置为false，表示输入无效
                      alert("输入不能为空！");
                  }
                    if (isOk) {
                      ChangeAnchorValue(id, labelTextarea.value, 'Input',input.Id); // 假定 id 和 ChangeNodeLabel 已定义
                    }

                });
                  labelTextarea.addEventListener('input', function() {
                    // 重置高度以计算新的高度
                    this.style.height = 'auto';
                  
                    // 设置新的高度
                    this.style.height = `${this.scrollHeight}px`;
                  });
                  inputContainer.appendChild(labelTextarea);
              }
          }
          selectBox.addEventListener('change', function() {
            handleChange(this.value);
          });
          Select1.addEventListener('change', function() {

          });
          // 为输入框添加 blur 监听器
          inputName.addEventListener('input', function() {
              ChangeAnchorLabel(id, inputName.value, index,input.Id,true); // 假定 id 和 ChangeNodeLabel 已定义
          });
          RefreshEdge();
          inputColumn.appendChild(inputContainer);
        }
        // 假设Inputs是已定义的
      Inputs.forEach((input, index) => {
          CreatInputs(input,index,input.Id);
      });
      Outputs.forEach((output, index) => {
          CreatOutputs(output,index,output.Id);
      });
    }

    document.getElementById('graph-container').appendChild(domElement);
    domBlocks.push({ id: `dom-${id}`, element: domElement, Item });
  }
  initializeDragAndResize(domElement,300,400);
  // 更新 DOM 元素的内容和位置（不包括已经移除的元素）
  //if (domElement && domElement.parentNode) {
    //domElement.innerHTML += id; // 显示元素的 id，注意不要覆盖 closeButton
    //domElement.style.left = `${x}px`;
    //domElement.style.top = `${y+200}px`;
  //}
  }
  function autoResizeTextarea(textarea) {
    textarea.style.height = 'auto';  // 重置高度，允许它根据内容缩小
    textarea.style.height = textarea.scrollHeight + 'px';  // 设置高度等于滚动高度，以适应所有内容
}
function resizeTextarea(textarea) {
  textarea.style.height = 'auto';
  textarea.style.height = textarea.scrollHeight + 'px';
}

function generateIOHtml(items, isInput = true) {
  const title = isInput ? 'Inputs' : 'Outputs';
  let html = `<h3 class="io-title">${title}</h3>`;
  
  items.forEach((item, index) => {
      let value = '';
      if (item.Kind === 'Num') {
          value = item.Num;
      } else if (item.Kind.includes('String')) {
          value = item.Context;
      } else if (item.Kind === 'Boolean' || item.Kind === 'Trigger') {
          value = item[item.Kind] ? 'true' : 'false';
      }
      
      const readOnly = !isInput ? 'readonly' : '';
      const dataAttrs = isInput ? `data-index="${index}" data-kind="${item.Kind}"` : '';
      const className = isInput ? 'input-textarea' : 'output-textarea';
      
      html += `
          <div class="io-container">
              <label class="io-label">${item.name}:</label>
              <textarea 
                  class="${className}"
                  ${readOnly}
                  ${dataAttrs}
                  oninput="resizeTextarea(this)"
              >${value}</textarea>
          </div>`;
  });
  return html;
}

// 全局变量，跟踪全屏状态
let isFullScreen = false;

// 创建侧边窗口函数
function createSideWindow(item, isCheckMode = false) {
  // 获取节点数据
  const node = isCheckMode
      ? TempMessageNode.nodes.find(n => n.id === item.id)
      : graph.save().nodes.find(n => n.id === item.id);

  const tempNode = (!isCheckMode && TempMessageNode?.nodes)
      ? TempMessageNode.nodes.find(n => n.id === item.id)
      : node;

  if (!node) {
      console.error('未找到节点数据');
      return;
  }

  const contentArea = document.getElementById('content-area');
  if (!contentArea) return;
  contentArea.innerHTML = '';

  // 生成 Token 信息（如果有）
  let tokenInfo = '';
  if (tempNode.Outputs?.[0]) {
      const output = tempNode.Outputs[0];
      if (
          typeof output.prompt_tokens !== 'undefined' &&
          typeof output.completion_tokens !== 'undefined' &&
          typeof output.total_tokens !== 'undefined'
      ) {
          tokenInfo = `
              <div class="token-info">
                  <div class="token-item">
                      <span>Prompt Tokens:</span> ${output.prompt_tokens}
                  </div>
                  <div class="token-item">
                      <span>Completion Tokens:</span> ${output.completion_tokens}
                  </div>
                  <div class="token-item">
                      <span>Total Tokens:</span> ${output.total_tokens}
                  </div>
              </div>
          `;
      }
  }

  // 生成输入区域 HTML
  let inputsHtml = `
  <div class="section-container">
      <h3>Inputs</h3>
  `;
  node.Inputs.forEach((input, index) => {
  let value = '';
  if (input.Kind === 'Num') {
      value = input.Num ?? '';
  } else if (input.Kind.includes('String')) {
      value = input.Context ?? '';
  } else if (input.Kind === 'Boolean') {
      value = input.Boolean ? 'true' : 'false';
  }

  inputsHtml += `
      <div class="input-item">
          <label><strong>${input.name}:</strong></label>
          <textarea 
              class="side-window-input-textarea"
              data-index="${index}"
              data-kind="${input.Kind}"
              ${isCheckMode ? 'readonly' : ''}
          >${value}</textarea>
      </div>
  `;
  });
  inputsHtml += '</div>';

  // 生成 Prompt 区域（如果是 LLM 节点）
  let promptHtml = '';
  if (node.NodeKind && node.NodeKind.includes('LLm')) {
      const promptValue = node.prompt ?? '';
      promptHtml = `
          <div class="section-container">
              <h3>Prompt</h3>
              <div class="prompt-wrapper">
                  <textarea 
                      id="prompt"
                      class="side-window-textarea"
                      ${isCheckMode ? 'readonly' : ''}
                  >${promptValue}</textarea>
              </div>
          </div>
      `;
  }

  // 生成输出区域 HTML
  let outputsHtml = `
      <div class="section-container">
          <h3>Outputs</h3>
  `;
  tempNode.Outputs.forEach((output, index) => {
      let value = '';
      if (output.Kind === 'Num') {
          value = output.Num ?? '';
      } else if (output.Kind.includes('String')) {
          value = output.Context ?? '';
      } else if (output.Kind === 'Boolean' || output.Kind === 'Trigger') {
          value = output.Boolean ? 'true' : 'false';
      }

      outputsHtml += `
          <div class="output-item">
              <label><strong>${output.name}:</strong></label>
              <textarea class="side-window-textarea" readonly>${value}</textarea>
          </div>
      `;
  });
  outputsHtml += '</div>';

  // 组合所有 HTML 内容
  contentArea.innerHTML = tokenInfo + inputsHtml + promptHtml + outputsHtml;

  // 显示侧边窗口
  const sideWindow = document.getElementById('side-window');
  sideWindow.style.display = 'block';

  // 调整所有 textarea 的高度
  document.querySelectorAll('#content-area textarea').forEach(resizeTextarea);

  // 设置按钮和状态显示
  const runButton = document.getElementById('run-button');
  runButton.style.display = isCheckMode ? 'none' : 'block';

  const resultIndicator = document.getElementById('result-indicator');
  const resultMessage = document.getElementById('result-message');

  if (isCheckMode) {
      const isError = node.ErrorContext && node.ErrorContext !== '';
      resultMessage.textContent = isError ? node.ErrorContext : '已完成';
      resultMessage.style.color = isError ? 'red' : 'green';
      resultIndicator.style.display = 'block';
  } else {
      resultIndicator.style.display = 'none';
      setupRunButton(node);
  }

  // 设置关闭按钮
  document.getElementById('close-button').onclick = () => {
      sideWindow.style.display = 'none';
      if (!isCheckMode && runButton._clickHandler) {
          runButton.removeEventListener('click', runButton._clickHandler);
      }
  };

  // 设置放大按钮的动画效果
  const maximizeButton = document.getElementById('maximize-button');
  let isFullScreen = false;
  maximizeButton.onclick = () => {
      const sideWindowElement = document.querySelector('.side-window');
      if (!isFullScreen) {
          sideWindowElement.style.transition = 'all 0.3s ease-in-out';
          sideWindowElement.classList.add('fullscreen');
          isFullScreen = true;
          maximizeButton.textContent = '⛶'; // 切换图标
      } else {
          sideWindowElement.classList.remove('fullscreen');
          isFullScreen = false;
          maximizeButton.textContent = '⛶'; // 切换图标
      }
  };
}
// 设置运行按钮函数
function setupRunButton(node) {
  const runButton = document.getElementById('run-button');

  // 移除先前的事件监听器
  if (runButton._clickHandler) {
      runButton.removeEventListener('click', runButton._clickHandler);
  }

  const handler = async () => {
      try {
          // 显示加载指示器
          const loadingIndicator = document.getElementById('loading-indicator');
          const resultIndicator = document.getElementById('result-indicator');
          const resultMessage = document.getElementById('result-message');
          loadingIndicator.style.display = 'block';
          resultIndicator.style.display = 'none';

          // 收集输入数据并更新 node.Inputs
          document.querySelectorAll('.side-window-input-textarea').forEach(textarea => {
              const index = parseInt(textarea.dataset.index, 10);
              const value = textarea.value.trim();
              const input = node.Inputs[index];

              if (input.Kind === 'Num') {
                  const numValue = parseFloat(value);
                  input.Num = numValue;
              } else if (input.Kind.includes('String')) {
                  input.Context = value;
              } else if (input.Kind === 'Boolean') {
                  input.Boolean = value.toLowerCase() === 'true';
              }
          });

          // 创建 inputs 对象，用于发送到后端
          const inputs = node.Inputs.reduce((acc, input, index) => {
              if (input.Kind === 'Num') {
                  acc[index] = input.Num;
              } else if (input.Kind.includes('String')) {
                  acc[index] = input.Context;
              } else if (input.Kind === 'Boolean') {
                  acc[index] = input.Boolean;
              }
              return acc;
          }, {});

          // 如果是 LLM 节点，处理 prompt
          if (node.NodeKind.includes('LLm')) {
              const promptElement = document.getElementById('prompt');
              if (promptElement) {
                  node.prompt = promptElement.value;

                  // 处理 prompt，替换占位符
                  node.ExprotPrompt = processLLmPrompt(node);
              }
          }

          // 发送请求到后端
          const response = await fetch('/run-node', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                  name: node.name,
                  node: node,
                  prompt: node.ExprotPrompt,
                  inputs: inputs, // 确保这里的 inputs 已经定义
                  outputs: node.Outputs
              })
          });

          // 解析响应数据
          const data = await response.json();
          if (!response.ok) {
              console.log('后端服务响应错误:', data.trace);
              resultMessage.textContent = '后端服务响应错误: ' + (data.trace || '未知错误');
              resultMessage.style.color = 'red';
              resultIndicator.style.display = 'block';
              throw new Error('后端服务响应错误', data);
          }

          // 更新输出显示，包括 Token 信息
          updateOutputs(data.output,node.id);

          // 显示成功消息
          resultMessage.textContent = '已完成';
          resultMessage.style.color = 'green';
          resultIndicator.style.display = 'block';

      } catch (error) {
          console.error('运行错误:', error);
          const resultMessage = document.getElementById('result-message');
          resultMessage.textContent = error.message;
          resultMessage.style.color = 'red';
          const resultIndicator = document.getElementById('result-indicator');
          resultIndicator.style.display = 'block';
      } finally {
          // 隐藏加载指示器
          const loadingIndicator = document.getElementById('loading-indicator');
          loadingIndicator.style.display = 'none';
      }
  };

  // 绑定事件处理器
  runButton._clickHandler = handler;
  runButton.addEventListener('click', handler);
}


// 处理 LLM 节点的 Prompt
function processLLmPrompt(node) {
  // 构建 ExprotAfterPrompt
  let ExprotAfterPrompt = 'Please ensure the output is in JSON format\n{\n';
  node.Outputs.forEach((output) => {
      let outputKind = '';
      if (output.Kind.includes('String')) {
          outputKind = 'String';
      } else if (output.Kind === 'Num') {
          outputKind = 'Num';
      } else if (output.Kind === 'Boolean') {
          outputKind = 'Boolean';
      }
      ExprotAfterPrompt +=
          '"' + output.Id + '": "' + output.Description +
          '" (you need output type:' + outputKind + ')\n';
  });
  ExprotAfterPrompt += '}\n';

  node.ExprotAfterPrompt = ExprotAfterPrompt;

  // 替换 prompt 中的占位符
  const matches = retrieveContentWithinBraces(node.prompt);
  let ExprotPrompt = node.prompt;

  matches.forEach(match => {
      node.Inputs.forEach((input) => {
          if (input.name === match) {
              let replacement;
              if (input.Kind === 'Num') {
                  replacement = input.Num;
              } else if (input.Kind.includes('String')) {
                  replacement = input.Context;
              } else if (input.Kind === 'Boolean') {
                  replacement = input.Boolean;
              }
              // 替换占位符，去除花括号
              ExprotPrompt = ExprotPrompt.replace('{{' + match + '}}', replacement);
          }
      });
  });

  // 合并 prompt 和 ExprotAfterPrompt
  node.ExprotPrompt = ExprotPrompt + '\n' + node.ExprotAfterPrompt;

  console.log('ExprotPrompt测试:', node.ExprotPrompt);

  return node.ExprotPrompt;
}

// 从文本中提取花括号内的内容
function retrieveContentWithinBraces(text) {
  const regex = /{{(.*?)}}/g;
  const matches = [];
  let match;
  while ((match = regex.exec(text)) !== null) {
      matches.push(match[1].trim());
  }
  return matches;
}

// 更新输出显示，包括 Token 信息
function updateOutputs(outputs,Id) {
  const outputElements = document.querySelectorAll('.output-item textarea');
  let dataTemp =graph.save();
  let nodeTemp;
  dataTemp.nodes.forEach(node => {
      if(node.id == Id)
      {
        nodeTemp = node;
      }
  });
  outputs.forEach((output, index) => {
      if (index < outputElements.length) {
          const element = outputElements[index];
          let value = '';
          if (output.Kind === 'Num') {
              value = output.Num ?? '';
              nodeTemp.Outputs[index].Num = output.Num;
          } else if (output.Kind.includes('String')) {
              value = output.Context ?? '';
              nodeTemp.Outputs[index].Context = output.Context;
          } else if (output.Kind === 'Boolean') {
              value = output.Boolean ? 'true' : 'false';
              nodeTemp.Outputs[index].Boolean = output.Boolean;
          }
          element.value = value;
      }
  });
  ChangeDatas(dataTemp);
  // 更新 Token 信息（如果有）
  let tokenInfo = '';
  
  if (outputs[0]) {
      const output = outputs[0];
      if (
          typeof output.prompt_tokens !== 'undefined' &&
          typeof output.completion_tokens !== 'undefined' &&
          typeof output.total_tokens !== 'undefined'
      ) {
          tokenInfo = `
              <div class="token-info">
                  <div class="token-item">
                      <span>Prompt Tokens:</span> ${output.prompt_tokens}
                  </div>
                  <div class="token-item">
                      <span>Completion Tokens:</span> ${output.completion_tokens}
                  </div>
                  <div class="token-item">
                      <span>Total Tokens:</span> ${output.total_tokens}
                  </div>
              </div>
          `;
      }
  }

  // 更新 contentArea 的 token 信息
  const contentArea = document.getElementById('content-area');
  const existingTokenInfo = contentArea.querySelector('.token-info');
  if (existingTokenInfo) {
      existingTokenInfo.outerHTML = tokenInfo; // 更新现有的 token 信息
  } else {
      contentArea.insertAdjacentHTML('afterbegin', tokenInfo); // 插入新的 token 信息
  }
}

// 调整 textarea 高度的函数（假设已经定义）
function resizeTextarea(textarea) {
  textarea.style.height = 'auto';
  textarea.style.height = textarea.scrollHeight + 'px';
}



// 辅助函数，提取双花括号中的内容
function retrieveContentWithinBraces(text) {
    const regex = /{{(.*?)}}/g;
    const matches = [];
    let match;
    while ((match = regex.exec(text)) !== null) {
        matches.push(match[1]);
    }
    return matches;
}


  // 关闭按钮事件监听器


  function retrieveContentWithinBraces(text) {
    // 使用正则表达式匹配所有{{}}包裹的内容
    const regex = /{{(.*?)}}/g;
    let matches = [];
    let match;

    // 循环获取所有匹配项
    while ((match = regex.exec(text)) !== null) {
        // 将匹配的内容（不包括{{和}}）添加到matches数组中
        matches.push(match[1]);
    }

    return matches;
}
//做一个update函数，定时每过一秒钟console.log('阿斯顿大苏打');
// 更新函数，每隔3秒执行一次
setInterval(() => {
  const { nodes, edges } = graph.save();

  // 更新节点加载状态
  nodes.forEach(node => {
    const n = node.name.split('.py')[0];
    requestNodeInfo(n).then((nodeInfo) => {
      if (node.IsLoadSuccess != nodeInfo.IsLoadSuccess) {
        node.IsLoadSuccess = nodeInfo.IsLoadSuccess;
        ChangeDatas(nodes);
      }
    });
  });

  if (document.getElementById('runButton').textContent === '运行中...' && IsTriggerNode === true) {
    let DataTemp = graph.save();
    let hasPassivityTrigger = DataTemp.nodes.some(node => node.NodeKind.includes('passivityTrigger'));
    let hasArrayTrigger = DataTemp.nodes.some(node => node.NodeKind.includes('ArrayTrigger'));

    // 如果没有正在运行的函数
    if (IsRunningFunction === false ) {
      if (passivityTriggerArray.length > 0 && ArrayTriggerArray.length == 0) {
        // 有待处理的 passivityTrigger 数据
        IsRunningFunction = true;
        // 处理下一个 passivityTrigger 数据
        let passivityData = passivityTriggerArray.shift();
        // 使用 passivityData 加载 ArrayTriggerArray
        loadArrayTriggerArray(passivityData);
        // 处理 ArrayTriggerArray
        processNextArrayTrigger(nodes, edges);
      } 
      else if (hasPassivityTrigger && ArrayTriggerArray.length == 0) {
        // 没有待处理的 passivityTrigger 数据，但存在 passivityTrigger 节点
        runPassivityTriggerNodes();
      } 
      else if (ArrayTriggerArray.length > 0) {
        // 没有 passivityTrigger，直接处理 ArrayTriggerArray
        IsRunningFunction = true;
        processNextArrayTrigger(nodes, edges);
      } else if (hasArrayTrigger) {
        // 没有待处理的 ArrayTrigger 数据，但存在 ArrayTrigger 节点
        runArrayTriggerNodes();
      } 
    }

    // 更新文件名
    updateFileName(FileName, Callsign);
  }
}, 3000);

// 运行 passivityTrigger 节点
async function runPassivityTriggerNodes() {
  let DataTemp = graph.save();
  let count = 0;
  for (const node of DataTemp.nodes) {
    if (node.NodeKind.includes('passivityTrigger')) {
      try {
        const inputs = getNodeInputs(node);
        const response = await fetch('/run-node', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            name: node.name,
            prompt: node.ExprotPrompt,
            node: node,
            count: count,
            inputs: inputs,
            outputs: node.Outputs,
          })
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        } else {
          let jsonResponse = await response.json();
          console.log('PassivityTrigger节点执行中:', jsonResponse, node.name);
          let result = jsonResponse;
          if (result.output != null) {
            LoadInPassivityTriggerArray(result, node);
          }
        }
      } catch (error) {
        console.error('处理PassivityTrigger节点时出错:', error);
      }
    }
  }
}

// 获取节点输入
function getNodeInputs(node) {
  return node.Inputs.reduce((acc, input, index) => {
    if (input.Kind === 'Num') {
      if (input.Num == null && input.Isnecessary === true) {
        throw new Error(`节点 ${node.label} 的输入点 ${input.Id} 缺失，请检查`);
      }
      acc[index] = input.Num;
    } else if (input.Kind.includes('String')) {
      if (input.Context == null && input.Isnecessary === true) {
        throw new Error(`节点 ${node.label} 的输入点 ${input.Id} 缺失，请检查`);
      }
      acc[index] = input.Context;
    } else if (input.Kind === 'Boolean') {
      if (input.Boolean == null && input.Isnecessary === true) {
        throw new Error(`节点 ${node.label} 的输入点 ${input.Id} 缺失，请检查`);
      }
      acc[index] = input.Boolean;
    }
    return acc;
  }, {});
}

// 共用的更新节点和连接处理函数
function processNodeConnections(DataTemp, triggerNode, outputData) {
  console.log('outputDatace测试:', outputData);
  UpdateNodeOutputs(triggerNode, outputData);
  let TempLink = 0;
  DataTemp.nodes.forEach(nodez => {
      TempLink= 0;
      let IsConnected = false;
      nodez.Inputs.forEach(input => {
        if(input.IsLabel == true) {
            TempLink++;
        }
      });
      DataTemp.edges.forEach(edge => {
          
          if (edge.source === triggerNode.id && edge.target === nodez.id) {
              TempLink++;
              IsConnected = true;
              let offset = edge.sourceAnchor - triggerNode.Inputs.length;
              let output = triggerNode.Outputs[offset];
              
              // 根据输入类型设置值
              if (nodez.Inputs[edge.targetAnchor].Kind === 'Num') {
                  nodez.Inputs[edge.targetAnchor].Num = output.Num;
              } else if (nodez.Inputs[edge.targetAnchor].Kind.includes('String')) {
                  nodez.Inputs[edge.targetAnchor].Context = output.Context;
              } else if (nodez.Inputs[edge.targetAnchor].Kind === 'Boolean') {
                  nodez.Inputs[edge.targetAnchor].Boolean = output.Boolean;
              }
          }
      });
      if (TempLink === nodez.Inputs.length && IsConnected === true) {
          nodez.IsStartNode = true;
      }
  });
  return DataTemp;
}

// 重构后的 ArrayTrigger 函数
async function runArrayTriggerNodesInPassivityTriggerArray(DataTemp) {
  let count = 0;
  // 识别 ArrayTrigger 节点
  let ArrayTriggernodesToProcess = DataTemp.nodes.filter(node => node.NodeKind.includes('ArrayTrigger'));

  // 识别连接到 ArrayTrigger 节点的所有上游节点
  let ConnectArrayTriggernodesToProcessEdges = DataTemp.edges.filter(edge => 
      ArrayTriggernodesToProcess.some(node => node.id === edge.target)
  );
  let ConnectArrayTriggernodesToProcessNodes = ConnectArrayTriggernodesToProcessEdges.map(edge => 
      DataTemp.nodes.find(node => node.id === edge.source)
  );

  console.log('上游节点列表:', ConnectArrayTriggernodesToProcessNodes);

  // 第一阶段：处理所有连接的上游节点
  for (const node of ConnectArrayTriggernodesToProcessNodes) {
      node.IsRunning = true;
      let ExprotPrompt = node.prompt;
      if (node.ExprotAfterPrompt == '') {
        let Temp = 'Please ensure the output is in JSON format\n{\n';
        node.Outputs.forEach(output => {
          let Kind = output.Kind;
          Temp += `"${output.Id}": "${output.Description}" (you need output type: ${Kind})\n`;
        });
        Temp += '}\n';
        node.ExprotAfterPrompt = Temp;
      }
      ExprotPrompt = node.prompt;
      let matches = retrieveContentWithinBraces(node.prompt);
      matches.forEach(match => {
        node.Inputs.forEach(input => {
          if (input.name == match) {
            if (input.Kind == 'Num') {
              ExprotPrompt = ExprotPrompt.replace(match, input.Num);
            } else if (input.Kind .includes('String')) {
              ExprotPrompt = ExprotPrompt.replace(match, input.Context);
            } else if (input.Kind == 'Boolean') {
              ExprotPrompt = ExprotPrompt.replace(match, input.Boolean);
            }
            ExprotPrompt = ExprotPrompt.replace(/{{/g, '').replace(/}}/g, '');
          }
        });
      });
      node.ExprotPrompt = ExprotPrompt + '\n' + node.ExprotAfterPrompt;
      try {
          const inputs = getNodeInputs(node);
          const response = await fetch('/run-node', {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                  name: node.name,
                  prompt: node.ExprotPrompt,
                  node: node,
                  count: count,
                  inputs: inputs,
                  outputs: node.Outputs,
              })
          });

          if (!response.ok) {
              throw new Error(`HTTP error! status: ${response.status}`);
          } else {
              let jsonResponse = await response.json();
              console.log('正在执行上游节点:', jsonResponse, node.name);
              let result = jsonResponse;

              if (result.output != null) {
                  DataTemp=JSON.parse(JSON.stringify(processNodeConnections(DataTemp, node, result.output)));
              }
          }
      } catch (error) {
          console.error('处理上游节点时出错:', error);
      }
  }
  ArrayTriggernodesToProcess=[];
  ArrayTriggernodesToProcess=DataTemp.nodes.filter(node => node.NodeKind.includes('ArrayTrigger'));
  console.log('ArrayTriggernodesToProcess测试:', ArrayTriggernodesToProcess);
  // 第二阶段：处理 ArrayTrigger 节点
  for (const node of ArrayTriggernodesToProcess) {
      try {
          const inputs = getNodeInputs(node);
          const response = await fetch('/run-node', {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                  name: node.name,
                  prompt: node.ExprotPrompt,
                  node: node,
                  count: count,
                  inputs: inputs,
                  outputs: node.Outputs,
              })
          });

          if (!response.ok) {
              throw new Error(`HTTP error! status: ${response.status}`);
          } else {
              let jsonResponse = await response.json();
              console.log('ArrayTrigger节点执行中:', jsonResponse, node.name);
              let result = jsonResponse;

              if (result.output != null) {
                  result.output.forEach((outputData) => {
                      const processedData = processNodeConnections(DataTemp, node, outputData);
                      ArrayTriggerArray.push(JSON.parse(JSON.stringify(processedData)));
                  });
              }
          }
      } catch (error) {
          console.error('处理ArrayTrigger节点时出错:', error);
      }
  }
  updateFileName(FileName, Callsign);
}

async function runArrayTriggerNodes(){
  let DataTemp = graph.save();
  let count = 0;
  let nodesToProcess = DataTemp.nodes.filter(node => node.NodeKind.includes('ArrayTrigger'));

  for (const node of nodesToProcess) {
      try {
          const inputs = getNodeInputs(node);
          const response = await fetch('/run-node', {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                  name: node.name,
                  prompt: node.ExprotPrompt,
                  node: node,
                  count: count,
                  inputs: inputs,
                  outputs: node.Outputs,
              })
          });

          if (!response.ok) {
              throw new Error(`HTTP error! status: ${response.status}`);
          } else {
              let jsonResponse = await response.json();
              console.log('ArrayTrigger节点执行中:', jsonResponse, node.name);
              let result = jsonResponse;

              if (result.output != null) {
                  result.output.forEach((outputData) => {
                      const processedData = processNodeConnections(DataTemp, node, outputData);
                      ArrayTriggerArray.push(JSON.parse(JSON.stringify(processedData)));
                  });
              }
          }
      } catch (error) {
          console.error('处理ArrayTrigger节点时出错:', error);
      }
  }
  updateFileName(FileName, Callsign);
}
// 重构后的 LoadInPassivityTrigger 函数
function LoadInPassivityTriggerArray(data, triggerNode) {
  let DataTemp = JSON.parse(JSON.stringify(graph.save()));
  let TriggerNode = DataTemp.nodes.find(node => node.id === triggerNode.id);

  data.output.forEach((outputData) => {
      const processedData = processNodeConnections(DataTemp, TriggerNode, outputData);
      passivityTriggerArray.push(JSON.parse(JSON.stringify(processedData)));
  });

  updateFileName(FileName, Callsign);
}
// 使用 passivityData 加载 ArrayTriggerArray
function loadArrayTriggerArray(passivityData) {
  // 克隆数据
  let DataTemp = JSON.parse(JSON.stringify(passivityData));
  let hasArrayTrigger = DataTemp.nodes.some(node => node.NodeKind.includes('ArrayTrigger'));
  if (hasArrayTrigger) {
    runArrayTriggerNodesInPassivityTriggerArray(DataTemp);
  } else {
    // 没有 ArrayTrigger 节点，直接将 DataTemp 放入 ArrayTriggerArray
    ArrayTriggerArray.push(DataTemp);
    updateFileName(FileName, Callsign);
  }
}
// 更新节点的 Outputs
function UpdateNodeOutputs(node, outputData) {
  node.Outputs.forEach((output, index) => {
    console.log('output测试:', output,index, outputData[index]);
    if (output.Kind === 'Num') {
      output.Num = outputData[index].Num;
    } else if (output.Kind.includes('String')) {
      output.Context = outputData[index].Context;
    } else if (output.Kind === 'Boolean') {
      output.Boolean = outputData[index].Boolean;
    }
  });
}
// 更新节点的 Inputs
function UpdateNodeInputs(node, targetAnchor, output) {
  if (node.Inputs[targetAnchor].Kind === 'Num') {
    node.Inputs[targetAnchor].Num = output.Num;
  } else if (node.Inputs[targetAnchor].Kind.includes('String')) {
    node.Inputs[targetAnchor].Context = output.Context;
  } else if (node.Inputs[targetAnchor].Kind === 'Boolean') {
    node.Inputs[targetAnchor].Boolean = output.Boolean;
  }
  //更新ExprotPrompt
  
}
// 处理下一个 ArrayTrigger 数据
function processNextArrayTrigger(nodes, edges) {
  if (ArrayTriggerArray.length > 0) {
    let arrayData = ArrayTriggerArray.shift();
    processNodes(nodes, edges, arrayData);
  } else {
    IsRunningFunction = false;
    updateFileName(FileName, Callsign);
  }
}
// 运行节点流程
function processNodes(nodes, edges, data) {
  let DataTemp;
  if (data) {
    data.nodes.forEach(nodez => {
      nodez.IsBlock = true;
      nodez.IsRunning = false;
      nodez.IsError = false;
      nodez.isFinish = false;
      nodez.firstRun =true;
    });
    DataTemp = data;
    ChangeDatas(data);
    TempMessageNode = JSON.parse(JSON.stringify(data));
  }
  else {
    DataTemp = graph.save();
    DataTemp.nodes.forEach(nodez => {
      nodez.IsBlock = true;
      nodez.IsRunning = false;
      nodez.IsError = false;
      nodez.isFinish = false;
    });

    ChangeDatas(DataTemp);
    TempMessageNode = JSON.parse(JSON.stringify(DataTemp));
  }
  
  
  
  // 假设 runAllNodes 是一个异步函数，我们在其完成后将 IsRunningFunction 设置为 false，并继续处理下一个数据
  runAllNodes(DataTemp, nodes, edges).then(() => {
     updateFileName(FileName, Callsign);
  }).catch((error) => {
    console.error('运行节点流程时出错:', error);
    IsRunningFunction = false;
  });
}
// 更新文件名
function updateFileName(FileName, Callsign) {
  FileName = FileName.replace(".json", "");
  FileName = FileName.substring(FileName.lastIndexOf(':') + 1);
  
  if (Callsign != null) {
      FileName = Callsign + ':' + FileName;
  }
  
  // 启动标题动画
  if (!window.titleInterval) {
      window.titleInterval = animateTitle(FileName);
  }
}

function pasteFunction() {
  // 获取鼠标位置
  document.addEventListener('mousemove', function(event) {
      let target = graph.getPointByClient(event.clientX, event.clientY);
      
      // 确保复制的节点存在
      if (CopyNodeTemp) {
          // 获取鼠标位置的 canvas 坐标
          let canvasX = target.x;
          let canvasY = target.y;

          // 粘贴节点到鼠标位置
          copyNode(CopyNodeTemp, canvasX, canvasY, CopyNodeTemp.hash);
      } else {
          alert("No node to paste!");
      }
  }, { once: true });
}
function copyFunction() {
  //遍历所有的node找到ishovor==true的node
  let DataTemp=graph.save();
  DataTemp.nodes.forEach(node => {
    if (node.IsHovor) {
      CopyNodeTemp = node;
      console.log('CopyNodeTemp:',CopyNodeTemp);
    }
  });
}
function ChangeDatas(data) {
  let TempData = JSON.parse(JSON.stringify(graph.save()));
  // 检查 TempData 是否与 SaveGraph 的最新数据相同
  if (MemoryIndex === -1 || JSON.stringify(TempData) !== JSON.stringify(SaveGraph[MemoryIndex])) {
    // 清除 MemoryIndex 后面的记录
    if (MemoryIndex < SaveGraph.length - 1) {
      SaveGraph = SaveGraph.slice(0, MemoryIndex + 1);
    }
    SaveGraph.push(TempData);
    MemoryIndex++;
    //console.log('储存SaveGraph:', SaveGraph);
  }
  graph.changeData(data);
}

document.addEventListener('keydown', function(event) {
  if (event.ctrlKey && event.key === 'z') {
    // 撤销 (Ctrl+Z)
    if (MemoryIndex > 0) {
      MemoryIndex--;
      graph.changeData(SaveGraph[MemoryIndex]);
      //console.log('撤销到:', SaveGraph[MemoryIndex]);
      //console.log('MemoryIndex:', SaveGraph);
    } else if (MemoryIndex === 0) {
      // 确保在撤销到初始状态时正确更新图形
      graph.changeData(SaveGraph[MemoryIndex]);
      //console.log('撤销到初始状态:', SaveGraph[MemoryIndex]);
    }
  } else if (event.ctrlKey && event.key === 'y') {
    // 重做 (Ctrl+Y)
    if (MemoryIndex < SaveGraph.length - 1) {
      MemoryIndex++;
      graph.changeData(SaveGraph[MemoryIndex]);
      //console.log('重做到:', SaveGraph[MemoryIndex]);
      //console.log('MemoryIndex:', SaveGraph);
    }
  }
  else if (event.ctrlKey && event.key === 's') {//抑制浏览器保存
    event.preventDefault();
    saveFunction();
  }
  const isInput = event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA' || event.target.isContentEditable;

  if (!isInput && event.ctrlKey && event.key === 'c') { // 抑制浏览器保存
    event.preventDefault();
    copyFunction();
  } else if (!isInput && event.ctrlKey && event.key === 'v') {
    event.preventDefault();
    pasteFunction();
  }
  else if(event.ctrlKey && event.key === 'r') {
    event.preventDefault();
    runFunction();
  }
  //为运行
  if(document.getElementById('runButton').textContent == '运行')
  {
    //按delete
    if (event.key === 'Delete') {
      let DataTemp=graph.save();
      DataTemp.nodes.forEach(node => {
        if (node.IsHovor) {
          // 删除节点
          console.log('删除节点:',node.id);
          const item = graph.findById(node.id);
          console.log('item:',item);
          removeNode(item);
        }
      });
    }
    
  }
});
function runFunction() {
  if(document.getElementById('runButton').textContent == '运行中...' && IsTriggerNode==true)
  {
    IsTriggerNode=false;
    document.getElementById('runButton').textContent = '运行';
    let DataTemp=graph.save();
    DataTemp.nodes.forEach(nodez => {
      nodez.IsBlock = false;
    })
    ChangeDatas(DataTemp);
    ArrayTriggerArray = [];
    passivityTriggerArray = [];
    updateFileName(FileName, Callsign);
  }
  else if(document.getElementById('runButton').textContent == '运行')
  {
    IsTriggerNode = false;
    TempNodeArray = [];
    const { nodes, edges } = graph.save();
    TempMessageNode=JSON.parse(JSON.stringify(graph.save()));
    // 检查每个节点的每个输入矛点是否都被连接
    let isContinue = true;
    nodes.forEach(node => {
        node.Inputs.forEach((input, index) => {
            if (input.Isnecessary == true &&input.Link==0 && input.IsLabel == false) {
                isContinue = false;
                let DataTemp=graph.save();
                DataTemp.nodes.forEach(nodez => {
                  if(nodez.id == node.id)
                  {
                    nodez.IsError = true;
                    nodez.ErrorContext = '存在未连接的必要输入矛点';
                  }
                })
                ChangeDatas(DataTemp);
            }
        });
        if(node.NodeKind.includes('Trigger'))
        {
          IsTriggerNode = true;
        }
    });

    if (!isContinue) {
        showMessage('存在未连接的必要输入矛点，程序终止','#ff0000');
        return;
    }
    document.getElementById('runButton').textContent = '运行中...';
    let DataTemp=graph.save();
    //console.log('DataTemp:',DataTemp);
    DataTemp.nodes.forEach(nodez => {
      nodez.IsBlock = true;
      nodez.IsRunning = false;
      nodez.IsError = false;
      nodez.isFinish = false;
      nodez.IsStartNode = false;
    })
    if(IsTriggerNode==false)
    {
      IsRunningFunction=true;
      runAllNodes(DataTemp, nodes, edges);
    }
    }
    else if(document.getElementById('runButton').textContent == '返回编辑模式' || document.getElementById('runButton').textContent == '运行中...')
    {
      document.getElementById('runButton').textContent = '运行';
      let DataTemp=graph.save();
      DataTemp.nodes.forEach(nodez => {
        nodez.IsBlock = false;
        let Tempnode=TempMessageNode.nodes.find(node => node.id === nodez.id);
        nodez.Inputs=Tempnode.Inputs;
      })
      ChangeDatas(DataTemp);
      
    }

}
async function runAllNodes(DataTemp, nodesT, edges) {
  // 运行函数程序初始化
  DataTemp.nodes.forEach(nodez => {
    nodez.IsBlock = true;
    nodez.IsRunning = false;
    nodez.IsError = false;
    nodez.isFinish = false;
  });
  ChangeDatas(DataTemp);
  let nodes=JSON.parse(JSON.stringify(nodesT));//BUg修复！！！！！，nodes无法再函数中更改
  // 为所有节点初始化一个输入状态对象
  nodes.forEach(node => {
    if (node.NodeKind.includes('Trigger')==false) {
      node.inputStatus = node.Inputs.map(() => false);  // 初始时，所有输入状态都设置为 false

      edges.forEach(edge => {
        if (edge.target === node.id) {
          let sourceNodez = nodes.find(nodez => nodez.id === edge.source);
          if (sourceNodez && sourceNodez.NodeKind.includes('Trigger')) {
            node.inputStatus[edge.targetAnchor] = true;
          } else {
            node.inputStatus[edge.targetAnchor] = false;
          }
        }
      });
      
      node.firstRun = true;  // 标记节点为第一次运行
      node.IsTrigger = false;
      if (node.TriggerLink > 0) {
        node.IsTrigger = true;
      }
      node.Outputs.forEach(output => {
        output.Boolean = false;  // 初始化输入
        output.Num = 0;  // 初始化输出
        output.Context = '';  // 初始化输出
      });
    }
  });
  // 找到没有输入的节点作为起始节点并执行
  const startNodes = nodes.filter(node =>
    (node.IsStartNode || node.Inputs.length === 0 || node.Inputs.every(input => input.IsLabel == true)) &&
    node.NodeKind.includes('Trigger')==false && node.IsTrigger == false
  );
  
  let promises = startNodes.map(node => prepareAndExecuteNode(node, DataTemp, nodes, edges));

  // 等待所有的异步操作完成
  Promise.all(promises).then(() => {
    IsRunningFunction = false;
    if(IsTriggerNode==false)
    document.getElementById('runButton').textContent = '返回编辑模式';
  }).catch(error => {
    console.error('执行节点时出错：', error);
    IsRunningFunction = false;
  });
}

function prepareAndExecuteNode(node, DataTemp, nodes, edges) {
  let ExprotPrompt = node.prompt;
  if (node.ExprotAfterPrompt == '') {
    let Temp = 'Please ensure the output is in JSON format\n{\n';
    node.Outputs.forEach(output => {
      let Kind = output.Kind;
      Temp += `"${output.Id}": "${output.Description}" (you need output type: ${Kind})\n`;
    });
    Temp += '}\n';
    node.ExprotAfterPrompt = Temp;
  }
  ExprotPrompt = node.prompt;
  let matches = retrieveContentWithinBraces(node.prompt);
  matches.forEach(match => {
    node.Inputs.forEach(input => {
      if (input.name == match) {
        if (input.Kind == 'Num') {
          ExprotPrompt = ExprotPrompt.replace(match, input.Num);
        } else if (input.Kind .includes('String')) {
          ExprotPrompt = ExprotPrompt.replace(match, input.Context);
        } else if (input.Kind == 'Boolean') {
          ExprotPrompt = ExprotPrompt.replace(match, input.Boolean);
        }
        ExprotPrompt = ExprotPrompt.replace(/{{/g, '').replace(/}}/g, '');
      }
    });
  });
  node.ExprotPrompt = ExprotPrompt + '\n' + node.ExprotAfterPrompt;
  addHistory('Start');
  if (!node.IsTrigger) {
    return executeNode(node, 0, DataTemp, nodes, edges);
  }
  return Promise.resolve();
}
async function executeNode(node, count, DataTemp, nodes, edges) {
  count++;
  if (document.getElementById('runButton').textContent != '运行' &&IsRunningFunction==true&&!node.IsTrigger && node.NodeKind.includes('Trigger')==false && node.firstRun && node.Inputs.every((input, index) => {
    return (!input.Isnecessary && input.Link == 0) || (node.inputStatus[index] && input.Link > 0) || (input.IsLabel == true);
  })) {
    let linkedLines = [];
    let linkedLines1 = [];
    DataTemp.nodes.forEach(nodez => {
      if (nodez.id == node.id) {
        nodez.IsRunning = true;
        if (nodez.NodeKind.includes('Trigger')) {
          DataTemp.nodes.forEach(nodezz => {
            nodezz.IsBlock = true;
            nodezz.IsRunning = false;
            nodezz.IsError = false;
            //nodezz.isFinish = false;
          });
        }
        let edgesTemp = edges.filter(edge => edge.source === node.id);
        let edgesTemp1 = edges.filter(edge => edge.target === node.id);
        edgesTemp1.forEach(edge => {
          linkedLines1.push(edge.id);
        });
        edgesTemp.forEach(edge => {
          linkedLines.push(edge.id);
        });
      }
    });
    // 保存原始 node 状态,!!!无解bug
    const tempNode = JSON.parse(JSON.stringify(node));
    // 执行可能会改变 node 的操作
    ChangeDatas(DataTemp);
    // 恢复原始状态
    node = JSON.parse(JSON.stringify(tempNode));
    graph.refresh();
    node.firstRun = false;
    nodes.forEach(nodez => {
      if (nodez.id == node.id) {
        nodez.firstRun = false;
      }
    });

    const Temp = node.Inputs.reduce((acc, input, index) => {
      if (input.Kind == 'Num') {
        if (input.Num == null && input.Isnecessary) {
          throw new Error(`节点 ${node.label} 的输入点 ${input.Id} 输出错误，请重试${count}节点${input}`);
        }
        acc[index] = input.Num;
      } else if (input.Kind .includes('String')) {
        if (input.Context == null && input.Isnecessary) {
          throw new Error(`节点 ${node.label} 的输入点 ${input.Id} 输出错误，请重试${count}节点${input}`);
        }
        acc[index] = input.Context;
      } else if (input.Kind == 'Boolean') {
        if (input.Boolean == null && input.Isnecessary) {
          throw new Error(`节点 ${node.label} 的输入点 ${input.Id} 输出错误，请重试${count}节点${input}`);
        }
        acc[index] = input.Boolean;
      }
      return acc;
    }, {});
    linkedLines.forEach(e => {
      const eg = graph.findById(e);
      eg.setState('linked', true);
      eg.setState('linkBlue', true);
    });
    linkedLines1.forEach(e => {
      const eg = graph.findById(e);
      eg.setState('linked', false);
      //eg.setState('linkGreen', true);
    });
    let RetryNum = node.ReTryNum !== null && node.ReTryNum !== undefined ? node.ReTryNum : 0;
    let success = false;
    let data;
    async function fetchData() {
      const response = await fetch('/run-node', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: node.name,
          prompt: node.ExprotPrompt,
          node: node,
          count: count,
          inputs: Temp,
          outputs: node.Outputs,
        })
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || '请求失败');
      }
      return response.json();
    }

    do {
      try {
        data = await fetchData();
        function isReadable(str) {
            return typeof str === 'string' && /^[\x20-\x7E]*$/.test(str); // 确保是字符串并且是可读的
        }
        
        for (let i = 0; i < data.output.length; i++) {
            let context = data.output[i].Context;
        
            try {
                // 首先确保 context 是字符串，如果不是，转换成字符串格式
                if (typeof context !== 'string') {
                    context = JSON.stringify(context, null, 2);
                }  
                // 检查是否包含 "Error"
                if (context.includes('Error')) {
                    // 确保 context 是可读的，如果不可读，转换成 JSON 格式
                    if (!isReadable(context)) {
                        context = JSON.stringify(context, null, 2);
                    }
                    // 修改 data 数据为你想要的格式
                    data.output[i].Context = context; // 修改 data 中的 context 为可读字符串
        
                    // 抛出错误信息
                    throw new Error(context);
                } else {
                    // 如果没有 "Error" 字符串，也可以对 context 进行其他修改
                    data.output[i].Context = context; // 修改 data 的内容
                }
        
            } catch (err) {
                console.error('Error processing context:', err);
                // 继续执行循环，避免程序崩溃
            }
        }
        
      
        success = true;
        DataTemp.nodes.forEach(nodez => {
          if (nodez.id == node.id) {
            nodez.IsRunning = false;
            nodez.isFinish = true;
            nodez.ErrorContext = '';
          }
        });
        ChangeDatas(DataTemp);
        RefreshEdge();
        console.log('执行成功:', data,count);
        const sourceTempNode = TempMessageNode.nodes.find(n => n.id === node.id);
        console.log('sourceTempNode:', data,sourceTempNode.label,sourceTempNode.Inputs);
        sourceTempNode.Outputs.forEach((output, index) => {
          if (data.output && data.output[index]) {
            output.Num = data.output[index].Num;
            output.Context = data.output[index].Context;
          
            output.Boolean = data.output[index].Boolean;
          }
        });
        addHistory(sourceTempNode);
        
        const childPromises = edges.filter(edge => edge.source === node.id).map(async edge => {
          const targetNode = nodes.find(n => n.id === edge.target);
          if (targetNode && targetNode.NodeKind.includes('Trigger') == false) {
            const sourceNode = nodes.find(n => n.id === edge.source);
            const targetTempNode = TempMessageNode.nodes.find(n => n.id === edge.target);
            const sourceTempNode = TempMessageNode.nodes.find(n => n.id === edge.source);
            if (sourceNode && sourceNode.Outputs.length > edge.sourceAnchor - sourceNode.Inputs.length) {
              const outputIndex = edge.sourceAnchor - sourceNode.Inputs.length;
              sourceNode.Outputs[outputIndex].Num = data.output[outputIndex].Num;
              sourceNode.Outputs[outputIndex].Context = data.output[outputIndex].Context;
              sourceNode.Outputs[outputIndex].Boolean = data.output[outputIndex].Boolean;

              sourceTempNode.Outputs[outputIndex].Num = data.output[outputIndex].Num;
              sourceTempNode.Outputs[outputIndex].Context = data.output[outputIndex].Context;
              sourceTempNode.Outputs[outputIndex].Boolean = data.output[outputIndex].Boolean;
            }
            
            if (sourceNode && targetNode && edge.targetAnchor == targetNode.Inputs.length + targetNode.Outputs.length) {
              if (sourceNode.Outputs[edge.sourceAnchor - sourceNode.Inputs.length].Boolean == true) {
                targetNode.IsTrigger = false;
              }
            }

            if (targetNode && targetNode.Inputs.length > edge.targetAnchor) {
              targetNode.Inputs[edge.targetAnchor].Num = data.output[edge.sourceAnchor - sourceNode.Inputs.length].Num;
              targetNode.Inputs[edge.targetAnchor].Context = data.output[edge.sourceAnchor - sourceNode.Inputs.length].Context;
              targetNode.Inputs[edge.targetAnchor].Boolean = data.output[edge.sourceAnchor - sourceNode.Inputs.length].Boolean;

              targetTempNode.Inputs[edge.targetAnchor].Num = data.output[edge.sourceAnchor - sourceNode.Inputs.length].Num;
              targetTempNode.Inputs[edge.targetAnchor].Context = data.output[edge.sourceAnchor - sourceNode.Inputs.length].Context;
              targetTempNode.Inputs[edge.targetAnchor].Boolean = data.output[edge.sourceAnchor - sourceNode.Inputs.length].Boolean;

              targetNode.inputStatus[edge.targetAnchor] = true;
            }

            if (!targetNode.IsTrigger) {
              let ExprotPrompt = targetNode.prompt;
              let Temp = 'Please ensure the output is in JSON format\n{\n';
              targetNode.Outputs.forEach(output => {
                let Kind = output.Kind;
                Temp += `"${output.Id}": "${output.Description}" (you need output type: ${Kind})\n`;
              });
              Temp += '}\n';
              targetNode.ExprotAfterPrompt = Temp;

              let matches = retrieveContentWithinBraces(targetNode.prompt);
              matches.forEach(match => {
                targetNode.Inputs.forEach((input, index) => {
                  if (input.name == match) {
                    if (input.Kind == 'Num') {
                      ExprotPrompt = ExprotPrompt.replace(match, input.Num);
                    } else if (input.Kind .includes('String')) {
                      ExprotPrompt = ExprotPrompt.replace(match, input.Context);
                    } else if (input.Kind == 'Boolean') {
                      ExprotPrompt = ExprotPrompt.replace(match, input.Boolean);
                    }
                    ExprotPrompt = ExprotPrompt.replace(/{{/g, '').replace(/}}/g, '');
                  }
                });
              });

              targetNode.ExprotPrompt = ExprotPrompt + '\n' + targetNode.ExprotAfterPrompt;;
              targetNode.inputStatus[edge.targetAnchor] = true;
              await executeNode(targetNode, count, DataTemp, nodes, edges);
            }
          }
        });

        await Promise.all(childPromises);

      } catch (error) {
        RetryNum--;
        if (RetryNum > 0) {
          console.error(`节点 ${node.name} 执行失败，剩余重试次数 ${RetryNum} 次:`, error.message);
          showMessage(`节点 ${node.name} 执行失败，剩余重试次数 ${RetryNum} 次:`, 'orange');
        } else {
          DataTemp.nodes.forEach(nodez => {
            if (nodez.id == node.id) {
              nodez.IsError = true;
              nodez.ErrorContext = '节点运行有Bug:' + '\n' + error.message;
              TempMessageNode.nodes.forEach(nodezz => {
                if (nodezz.id == node.id) {
                  nodezz.IsError = true;
                  nodezz.ErrorContext = '节点运行有Bug:' + '\n' + error.message;
                }
              });
            }
          });
          ChangeDatas(DataTemp);
          console.error(`节点 ${node.name} 执行失败:`, {
            message: error.message,
            stack: error.stack,
            line: error.lineNumber || (error.stack?.split('\n')[1]?.match(/:\d+:\d+/)?.[0] || '未知行号')
        });
        
        }
      }
      
    } while (!success && RetryNum > 0);
    
  }
}


function RefreshEdge() {
  const { nodes, edges } = graph.save();

  // Reset all links to zero for each node's inputs and outputs
  nodes.forEach(node => {
    node.Inputs.forEach(input => input.Link = 0);
    node.Outputs.forEach(output => output.Link = 0);
    node.TriggerLink = 0;
  });

  // Filter out edges where source or target nodes or anchors are not found
  const validEdges = edges.filter(edge => {
    const sourceNode = nodes.find(node => node.id === edge.source);
    const targetNode = nodes.find(node => node.id === edge.target);
    const sourceOutput = sourceNode?.Outputs.find(output => output.Id === edge.sourceAnchorID);
    const targetInput = targetNode?.Inputs.find(input => input.Id === edge.targetAnchorID);

    if ((!sourceNode || !targetNode || !sourceOutput || !targetInput) && sourceNode.NodeKind != 'IfNode') {
      console.log('找不到对应的矛点:', edge);
      return false;
    }
    if(sourceNode.NodeKind == 'IfNode' && (!sourceNode || !targetNode || !sourceOutput))
    {
      console.log('找不到对应的矛点:', edge,sourceNode,targetNode,sourceOutput);
      return false;
    }

    // Update link status for valid anchors
    if(sourceNode.NodeKind == 'IfNode')
    {
      console.log('找到对应的矛点:', edge,sourceNode,targetNode,sourceOutput);
      targetNode.TriggerLink = 1;
      sourceOutput.Link = 1;
      edge.sourceAnchor = sourceNode.Outputs.indexOf(sourceOutput) + sourceNode.Inputs.length;
      edge.targetAnchor = targetNode.Inputs.length + targetNode.Outputs.length;
    }
    else
    {
      sourceOutput.Link = 1;
      targetInput.Link = 1;
      edge.sourceAnchor = sourceNode.Outputs.indexOf(sourceOutput) + sourceNode.Inputs.length;
      edge.targetAnchor = targetNode.Inputs.indexOf(targetInput);
    }
    return true;
  });

  // Update graph data with valid edges only
  ChangeDatas({ nodes, edges: validEdges });
  if(document.getElementById('runButton').textContent == '运行中...')
    {
      edges.forEach(edge => {
        //检查node是否在运行
        const sourceNode = nodes.find(node => node.id === edge.source);
        
        //if头跟尾是isfinish==true的node,或者尾isfinish==true头的node.NodeKind.includes('Trigger')
        if((sourceNode.NodeKind.includes('Trigger')==true) || sourceNode.isFinish==true)
        {
          const eg = graph.findById(edge.id);
          eg.setState('linked', false);
          //eg.setState('linkGreen', true);
        }
        else if(sourceNode.IsRunning==false)
        {
          const eg = graph.findById(edge.id);
          eg.setState('linked', false);
          eg.setState('linkBlue', false);
        }
        
      });
      nodes.forEach(node => {
        if (node.IsRunning) {
          let linkedLines = [];
          edges.forEach(edge => {
            if (edge.source === node.id) {
              linkedLines.push(edge.id);
            }
          });
          linkedLines.forEach(e => {
            const eg = graph.findById(e);
            eg.setState('linked', true);
            eg.setState('linkBlue', true);
          });
        }
      });
    }
  //console.log('Updated nodes and edges:', graph.save());
  
}
function addHistory(data) { // 
  //console.log('addHistory大苏打:', data);
  let Temp;
  if(data!='Start')
  {
    // 过滤后的对象只保留 name、Kind，以及根据 Kind 值选择 Context, Boolean 或 Num
    let filteredData = {
      NodeKind: data.NodeKind,
      label: data.label,
      Outputs: data.Outputs.map(item => {
          // 根据 Kind 字段的内容选择性保留 Context, Boolean, 或 Num
          let selectedField;
          if (item.Kind.includes("String")) {
              selectedField = { Context: item.Context };
          } else if (item.Kind.includes("Boolean")) {
              selectedField = { Boolean: item.Boolean };
          } else if (item.Kind.includes("Num")) {
              selectedField = { Num: item.Num };
          }
          
          // 仅保留 name, Kind，以及选择的字段
          return {
              name: item.name,
              Kind: item.Kind,
              ...selectedField
          };
      }),
      Inputs: data.Inputs.map(item => {
          // 根据 Kind 字段的内容选择性保留 Context, Boolean, 或 Num
          let selectedField;
          if (item.Kind.includes("String")) {
              selectedField = { Context: item.Context };
          } else if (item.Kind.includes("Boolean")) {
              selectedField = { Boolean: item.Boolean };
          } else if (item.Kind.includes("Num")) {
              selectedField = { Num: item.Num };
          }

          // 仅保留 name, Kind，以及选择的字段
          return {
              name: item.name,
              Kind: item.Kind,
              ...selectedField
          };
      })
    };

    // 将过滤后的对象转回 JSON 字符串
    Temp = JSON.stringify(filteredData);
    //console.log('过滤后的对象:', filteredData);

    
  }
  else
  {
    //让赋值Temp =['message': 'New conversation started']
    Temp = JSON.stringify({name: 'New started'});
    
  }
  fetch(`/addHistory?ProjectName=${ProjectName}`, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: Temp,
    })
    .then(response => response.json())
    .then(data => {
        console.log('Success:', data);
        loadHistory();
    })
    .catch((error) => {
        console.log('Error:', error);
    });
}
function loadHistory() {
  fetch(`/getHistory?ProjectName=${ProjectName}`)
  .then(response => response.json())
  .then(data => {
      //console.log('Success:', data);
  })
  .catch((error) => {
      //console.log('Error:', error);
  });
}
function saveFunction() {
  // 设置默认文件名
  let defaultFileName = FileName === '' ? 'New WorkFlow' : FileName;
  //去掉defaultFileName前面的所有字符包括:
  defaultFileName = defaultFileName.replace(/^.*:/, '');
  
  // 创建自定义对话框
  let saveDialog = document.createElement('div');
  saveDialog.innerHTML = `
    <div style="background-color: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 10px rgba(0,0,0,0.2);">
      <h3>Save WorkFlow</h3>
      <input type="text" id="saveFileName" value="${defaultFileName}" style="width: 100%; margin-bottom: 10px; padding: 5px;">
      <button id="confirmSave">Save</button>
      <button id="cancelSave">Cancel</button>
    </div>
  `;
  saveDialog.style.cssText = 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000;';
  document.body.appendChild(saveDialog);

  // 获取对话框元素
  let fileNameInput = document.getElementById('saveFileName');
  let confirmButton = document.getElementById('confirmSave');
  let cancelButton = document.getElementById('cancelSave');

  // 确认保存
  confirmButton.onclick = function() {
    let saveName = fileNameInput.value.trim();
    if (saveName) {
      let dataToSave = {
        nodes: graph.save()
      };

      // 编码 Unicode 字符
      function encodeUnicode(str) {
        return str.split('').map(function(char) {
          let charCode = char.charCodeAt(0);
          return charCode > 127 ? "\\u" + ("0000" + charCode.toString(16)).slice(-4) : char;
        }).join('');
      }

      // 编码数据中的字符串
      for (let key in dataToSave) {
        if (typeof dataToSave[key] === 'string') {
          dataToSave[key] = encodeUnicode(dataToSave[key]);
        }
      }

      let jsonDataToSave = JSON.stringify(dataToSave);

      // 发送保存请求
      let xhr = new XMLHttpRequest();
      xhr.open("POST", "/save", true);
      xhr.setRequestHeader("Content-Type", "application/json");
      xhr.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
          alert("Saved successfully!");
          FileName = saveName;
        }
      };
      xhr.send(JSON.stringify({ name: saveName, data: jsonDataToSave, path: FilePath }));

      // 关闭对话框
      document.body.removeChild(saveDialog);
    } else {
      alert("Please enter a valid file name.");
    }
  };

  // 取消保存
  cancelButton.onclick = function() {
    document.body.removeChild(saveDialog);
  };

  // 聚焦到输入框
  fileNameInput.focus();
}
function AddWorkflowNode(nodes, position) {
  let floder = nodes.folder || 'WorkFlow';
  
  fetch('/get-project-files', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json'
      },
      body: JSON.stringify({ json_name: nodes.name+'.json', json_path: floder})
  })
  .then(response => response.json())
  .then(data => {
    // 1. 获取当前图数据
    let NowData = graph.save();
    let Nownodes = NowData.nodes;
    let Nowedges = NowData.edges;
    let AddNodes = data.nodes.nodes;
    let AddEdges = data.nodes.edges;

    // 2. 获取当前最大时间戳
    const getCurrentMaxTimestamp = (nodes) => {
        return nodes.reduce((maxTimestamp, node) => {
            const match = node.id.match(/\d+$/);
            if (match) {
                const timestamp = parseInt(match[0]);
                return Math.max(maxTimestamp, timestamp);
            }
            return maxTimestamp;
        }, 0);
    };

    const currentMaxTimestamp = getCurrentMaxTimestamp(Nownodes);
    console.log('Current max timestamp:', currentMaxTimestamp);

    // 3. 更新新节点的ID
    AddNodes = AddNodes.map((node, index) => {
        const newTimestamp = currentMaxTimestamp + index + 1;
        const baseName = node.id.replace(/\d+$/, '');
        const newId = `${baseName}${newTimestamp}`;
        
        // 更新节点ID
        const updatedNode = {
            ...node,
            id: newId,
            IsRunning:false,
            IsBlock:false,
            x: position.x + (node.x || 0),  // 保持节点之间的相对位置关系
            y: position.y + (node.y || 0)   // 保持节点之间的相对位置关系
        };

        // 同时更新相关边的引用
        AddEdges = AddEdges.map(edge => {
            if (edge.source === node.id) {
                return { ...edge, source: newId };
            }
            if (edge.target === node.id) {
                return { ...edge, target: newId };
            }
            return edge;
        });
        console.log('Updated node测试:', updatedNode);
        return updatedNode;
    });

    // 4. 合并节点和边
    const mergedNodes = [...Nownodes, ...AddNodes];
    const mergedEdges = [...Nowedges, ...AddEdges];

    // 5. 验证没有重复ID
    const nodeIds = new Set();
    const hasDuplicates = mergedNodes.some(node => {
        if (nodeIds.has(node.id)) {
            console.error('Duplicate node ID found:', node.id);
            return true;
        }
        nodeIds.add(node.id);
        return false;
    });

    if (hasDuplicates) {
        console.error('Duplicate node IDs detected!');
        return;
    }

    // 7. 更新数据状态
    ChangeDatas({
      nodes: mergedNodes,
      edges: mergedEdges
  });
    console.log('Graph updated successfully', {
        totalNodes: mergedNodes.length,
        totalEdges: mergedEdges.length
    });
  });

}

document.body.addEventListener('dragover', (event) => {
  event.preventDefault(); // 阻止默认行为
});
function adjustHeightBasedOnContent(textarea) {
  console.log("Adjusting height...");

  // 清除之前的高度设置
  textarea.style.height = 'auto';

  // 直接使用 textarea 的 scrollHeight 来计算高度
  const computedHeight = textarea.scrollHeight;
  console.log(`Computed height: ${computedHeight}px`);

  // 设置textarea的高度，限制高度在60px到400px之间
  const newHeight = Math.max(Math.min(computedHeight, 400), 60);
  textarea.style.height = `${newHeight}px`;
  console.log(`Textarea height set to: ${newHeight}px`);
}


function InitFunction() {
  fetch('/get-python-files')
      .then(response => response.json())
      .then(data => {
          data.forEach(function(file_info) {
              fileInfoArray.push({
                  filename: file_info.filename,
                  hash: file_info.hash
              });
          });
      })
      .catch(error => console.error('Error:', error));
}


document.body.addEventListener('drop', (event) => {
  event.preventDefault(); // 阻止默认的拖放事件行为，这是必须的以避免浏览器默认打开文件

  const files = event.dataTransfer.files; // 获取拖放的文件列表
  if (files.length > 0) {
      const file = files[0]; // 取第一个文件
      if (file.type === "application/json") { // 检查文件类型是否为JSON
          // 弹出确认框询问用户是否确认导入新的项目
          if (confirm("你确定要导入新的项目吗？他会清除其他所有的Nodes。")) {
              graph.clear(); // 清除图表中的所有节点

              const reader = new FileReader(); // 创建一个用于读取文件的 FileReader
              reader.onload = (e) => { // 文件读取完成时触发的事件
                let dates = JSON.parse(e.target.result);
                  LoadWorkFlow(dates,file.name,'',''); // 读取文件内容并加载到图表中
              };
              reader.readAsText(file); // 以文本形式读取文件
          }
      } else {
          console.log("Please drop a JSON file."); // 如果文件类型不是JSON，提示用户
      }
  }
});
function LoadWorkFlow(dates,fileName,HostPost,Callsign) {
    isDropingFile = true; // 设置标志位，表示正在处理拖放文件
    const edges = dates.nodes.edges;
    dates.nodes.nodes.forEach((node) => {
      node.IsBlock = false; // 重置节点状态
      node.IsRunning = false;
      node.IsError = false;
      node.isFinish = false;
      const n = node.name.split('.py')[0];

      requestNodeInfo(n).then((nodeInfo) => {
        if(node.IsLoadSuccess != nodeInfo.IsLoadSuccess)
        {
          node.IsLoadSuccess = nodeInfo.IsLoadSuccess;
          ChangeDatas(dates.nodes);
        }
        
      });
    });
    //将文件名赋值给FileName
    FileName=fileName;
    //去除FileName的后缀
    FileName=FileName.replace(".json","");
    document.title
    FileName = FileName.substring(FileName.lastIndexOf(':') + 1);
    if(Callsign!=null)
      FileName=Callsign+':'+FileName;
    document.title = FileName;
    if(HostPost!='')
    {
      dates.nodes.nodes.forEach((node) => {
        if(node.NodeKind.includes('passivityTrigger'))
        {
          node.Inputs[0].Context = HostPost;
          node.Inputs[0].IsLabel = true;
        }
        if(node.NodeKind.includes('TeamWork'))
        {
          node.Inputs[0].Context = HostPost;
          node.Inputs[0].IsLabel = true;
          node.Inputs[1].Context = Callsign;
          node.Inputs[1].IsLabel = true;
        }
      });
    }
    if(Callsign!='')
    {
      dates.nodes.nodes.forEach((node) => {
        if(node.NodeKind.includes('passivityTrigger'))
        {
          node.Inputs[1].Context = Callsign;
          node.Inputs[1].IsLabel = true;
        }
      });
    }
    ChangeDatas(dates.nodes); // 更新图表数据
    // 更新边的属性
    graph.getEdges().forEach((edge, i) => {
      const sourceNode = edge.getSource();
      const targetNode = edge.getTarget();
      const sourceAnchor = sourceNode.getContainer().find(ele => ele.get('anchorPointIdx') === edges[i].startPoint.anchorIndex);
      const targetAnchor = targetNode.getContainer().find(ele => ele.get('anchorPointIdx') === edges[i].endPoint.anchorIndex);

      sourceAnchor.set('links', sourceAnchor.get('links') + 1);
      targetAnchor.set('links', targetAnchor.get('links') + 1);

      ChangeLink(sourceAnchor);
      ChangeLink(targetAnchor);

      RefreshEdge();
    });
    isDropingFile = false; // 重置标志位
}
function ReCreactNodes(NodeList) {
  const parsedJson = JSON.parse(NodeList);
  //console.log(parsedJson,parsedJson.nodes[0].position.x,parsedJson.nodes[0].position.y);
  // 清除 newArray
  parsedJson.nodes.nodes.forEach(function(newItem) {
    var matchFound = false;
    fileInfoArray.forEach(function(fileInfoItem) {
        if (newItem.hash === fileInfoItem.hash) {
            addNode(fileInfoItem.filename.replace(".py", ""), newItem.x, newItem.y, newItem.hash,fileInfoArray.NodeKind);
            matchFound = true;
        }
    });
    if (!matchFound) {
        console.log('No match found for hash:', newItem.hash);
    }
  });
  //console.log('解析',graph.save());
  let data = graph.save()
  data.edges = parsedJson.nodes.edges;
  //console.log(parsedJson,parsedJson.nodes[0].position.x,parsedJson.nodes[0].position.y);
  // 清除 newArray
  ChangeDatas(data);
  //Moving(parsedJson.viewCenter.x,parsedJson.viewCenter.y);
}
